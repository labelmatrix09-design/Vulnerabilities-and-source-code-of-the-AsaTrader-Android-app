package u2;

import android.view.MotionEvent;
import android.view.View;

/* JADX INFO: compiled from: R8$$SyntheticClass */
/* JADX INFO: loaded from: /home/kali/Desktop/bunt/agah/dex_files/classes2.dex */
public final /* synthetic */ class f implements View.OnTouchListener {
    public final /* synthetic */ j o;

    @Override // android.view.View.OnTouchListener
    public final boolean onTouch(View view, MotionEvent motionEvent) {
        return j.s2(this.o, view, motionEvent);
    }
}
