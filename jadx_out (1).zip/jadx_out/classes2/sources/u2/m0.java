package u2;

import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

/* JADX INFO: compiled from: R8$$SyntheticClass */
/* JADX INFO: loaded from: /home/kali/Desktop/bunt/agah/dex_files/classes2.dex */
public final /* synthetic */ class m0 implements SwipeRefreshLayout.j {
    public final /* synthetic */ o0 a;

    public final void a() {
        o0.x2(this.a);
    }
}
