package u2;

import android.widget.CompoundButton;
import androidx.appcompat.widget.SwitchCompat;
import com.google.android.material.bottomsheet.a;

/* JADX INFO: compiled from: R8$$SyntheticClass */
/* JADX INFO: loaded from: /home/kali/Desktop/bunt/agah/dex_files/classes2.dex */
public final /* synthetic */ class s implements CompoundButton.OnCheckedChangeListener {
    public final /* synthetic */ e0 a;
    public final /* synthetic */ SwitchCompat b;
    public final /* synthetic */ a c;

    public /* synthetic */ s(e0 e0Var, SwitchCompat switchCompat, a aVar) {
        this.a = e0Var;
        this.b = switchCompat;
        this.c = aVar;
    }

    @Override // android.widget.CompoundButton.OnCheckedChangeListener
    public final void onCheckedChanged(CompoundButton compoundButton, boolean z) {
        e0.F2(this.a, this.b, this.c, compoundButton, z);
    }
}
