package u2;

import android.view.View;
import v4.b2;

/* JADX INFO: compiled from: R8$$SyntheticClass */
/* JADX INFO: loaded from: /home/kali/Desktop/bunt/agah/dex_files/classes2.dex */
public final /* synthetic */ class k0 implements View.OnClickListener {
    public final /* synthetic */ b2 o;
    public final /* synthetic */ o0 p;
    public final /* synthetic */ boolean q;

    public /* synthetic */ k0(b2 b2Var, o0 o0Var, boolean z) {
        this.o = b2Var;
        this.p = o0Var;
        this.q = z;
    }

    @Override // android.view.View.OnClickListener
    public final void onClick(View view) {
        o0.r2(this.o, this.p, this.q, view);
    }
}
