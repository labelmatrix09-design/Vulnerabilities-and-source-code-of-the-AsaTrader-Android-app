package u2;

/* JADX INFO: compiled from: R8$$SyntheticClass */
/* JADX INFO: loaded from: /home/kali/Desktop/bunt/agah/dex_files/classes2.dex */
public final /* synthetic */ class w0 implements Runnable {
    public final /* synthetic */ u0 o;

    @Override // java.lang.Runnable
    public final void run() {
        u0.o.a.b.a(this.o);
    }
}
