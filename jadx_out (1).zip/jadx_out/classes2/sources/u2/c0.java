package u2;

import android.view.View;
import android.widget.TextView;
import com.google.android.material.bottomsheet.a;

/* JADX INFO: compiled from: R8$$SyntheticClass */
/* JADX INFO: loaded from: /home/kali/Desktop/bunt/agah/dex_files/classes2.dex */
public final /* synthetic */ class c0 implements View.OnClickListener {
    public final /* synthetic */ e0 o;
    public final /* synthetic */ TextView p;
    public final /* synthetic */ String[] q;
    public final /* synthetic */ a r;

    public /* synthetic */ c0(e0 e0Var, TextView textView, String[] strArr, a aVar) {
        this.o = e0Var;
        this.p = textView;
        this.q = strArr;
        this.r = aVar;
    }

    @Override // android.view.View.OnClickListener
    public final void onClick(View view) {
        e0.w2(this.o, this.p, this.q, this.r, view);
    }
}
