package u2;

import android.app.Dialog;
import android.view.View;

/* JADX INFO: compiled from: R8$$SyntheticClass */
/* JADX INFO: loaded from: /home/kali/Desktop/bunt/agah/dex_files/classes2.dex */
public final /* synthetic */ class x implements View.OnClickListener {
    public final /* synthetic */ Dialog o;
    public final /* synthetic */ e0 p;

    public /* synthetic */ x(Dialog dialog, e0 e0Var) {
        this.o = dialog;
        this.p = e0Var;
    }

    @Override // android.view.View.OnClickListener
    public final void onClick(View view) {
        e0.H2(this.o, this.p, view);
    }
}
