package u2;

import android.view.View;

/* JADX INFO: compiled from: R8$$SyntheticClass */
/* JADX INFO: loaded from: /home/kali/Desktop/bunt/agah/dex_files/classes2.dex */
public final /* synthetic */ class e implements View.OnClickListener {
    public final /* synthetic */ j o;

    @Override // android.view.View.OnClickListener
    public final void onClick(View view) {
        j.x2(this.o, view);
    }
}
