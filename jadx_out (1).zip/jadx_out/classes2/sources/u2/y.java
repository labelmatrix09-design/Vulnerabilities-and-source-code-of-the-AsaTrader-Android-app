package u2;

import android.view.View;

/* JADX INFO: compiled from: R8$$SyntheticClass */
/* JADX INFO: loaded from: /home/kali/Desktop/bunt/agah/dex_files/classes2.dex */
public final /* synthetic */ class y implements View.OnClickListener {
    public final /* synthetic */ e0 o;

    @Override // android.view.View.OnClickListener
    public final void onClick(View view) {
        e0.r2(this.o, view);
    }
}
