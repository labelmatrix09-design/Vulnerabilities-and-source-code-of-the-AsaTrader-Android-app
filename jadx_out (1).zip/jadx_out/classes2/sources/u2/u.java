package u2;

/* JADX INFO: compiled from: R8$$SyntheticClass */
/* JADX INFO: loaded from: /home/kali/Desktop/bunt/agah/dex_files/classes2.dex */
public final /* synthetic */ class u implements Runnable {
    public final /* synthetic */ e0 o;

    @Override // java.lang.Runnable
    public final void run() {
        e0.z2(this.o);
    }
}
