package u2;

import android.view.View;

/* JADX INFO: compiled from: R8$$SyntheticClass */
/* JADX INFO: loaded from: /home/kali/Desktop/bunt/agah/dex_files/classes2.dex */
public final /* synthetic */ class i0 implements View.OnClickListener {
    public final /* synthetic */ o0 o;
    public final /* synthetic */ o0.b p;

    public /* synthetic */ i0(o0 o0Var, o0.b bVar) {
        this.o = o0Var;
        this.p = bVar;
    }

    @Override // android.view.View.OnClickListener
    public final void onClick(View view) {
        o0.s2(this.o, this.p, view);
    }
}
