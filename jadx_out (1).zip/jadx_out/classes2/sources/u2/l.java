package u2;

import android.content.DialogInterface;

/* JADX INFO: compiled from: R8$$SyntheticClass */
/* JADX INFO: loaded from: /home/kali/Desktop/bunt/agah/dex_files/classes2.dex */
public final /* synthetic */ class l implements DialogInterface.OnCancelListener {
    public final /* synthetic */ e0 o;

    @Override // android.content.DialogInterface.OnCancelListener
    public final void onCancel(DialogInterface dialogInterface) {
        e0.v2(this.o, dialogInterface);
    }
}
