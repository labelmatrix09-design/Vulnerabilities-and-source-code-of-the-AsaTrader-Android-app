package u2;

import android.view.View;

/* JADX INFO: compiled from: R8$$SyntheticClass */
/* JADX INFO: loaded from: /home/kali/Desktop/bunt/agah/dex_files/classes2.dex */
public final /* synthetic */ class f0 implements View.OnClickListener {
    public final /* synthetic */ androidx.fragment.app.h o;
    public final /* synthetic */ o0 p;

    public /* synthetic */ f0(androidx.fragment.app.h hVar, o0 o0Var) {
        this.o = hVar;
        this.p = o0Var;
    }

    @Override // android.view.View.OnClickListener
    public final void onClick(View view) {
        o0.y2(this.o, this.p, view);
    }
}
