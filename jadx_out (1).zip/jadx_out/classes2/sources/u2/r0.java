package u2;

import android.widget.CompoundButton;
import java.util.ArrayList;

/* JADX INFO: compiled from: R8$$SyntheticClass */
/* JADX INFO: loaded from: /home/kali/Desktop/bunt/agah/dex_files/classes2.dex */
public final /* synthetic */ class r0 implements CompoundButton.OnCheckedChangeListener {
    public final /* synthetic */ u0 a;
    public final /* synthetic */ jl.z b;
    public final /* synthetic */ ArrayList c;

    public /* synthetic */ r0(u0 u0Var, jl.z zVar, ArrayList arrayList) {
        this.a = u0Var;
        this.b = zVar;
        this.c = arrayList;
    }

    @Override // android.widget.CompoundButton.OnCheckedChangeListener
    public final void onCheckedChanged(CompoundButton compoundButton, boolean z) {
        u0.t2(this.a, this.b, this.c, compoundButton, z);
    }
}
