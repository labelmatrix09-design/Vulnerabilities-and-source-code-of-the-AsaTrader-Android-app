package u2;

import android.view.View;
import com.google.android.material.bottomsheet.a;

/* JADX INFO: compiled from: R8$$SyntheticClass */
/* JADX INFO: loaded from: /home/kali/Desktop/bunt/agah/dex_files/classes2.dex */
public final /* synthetic */ class p implements View.OnClickListener {
    public final /* synthetic */ e0 o;
    public final /* synthetic */ a p;

    public /* synthetic */ p(e0 e0Var, a aVar) {
        this.o = e0Var;
        this.p = aVar;
    }

    @Override // android.view.View.OnClickListener
    public final void onClick(View view) {
        e0.E2(this.o, this.p, view);
    }
}
