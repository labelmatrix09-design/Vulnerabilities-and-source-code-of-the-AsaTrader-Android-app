package u2;

import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

/* JADX INFO: compiled from: R8$$SyntheticClass */
/* JADX INFO: loaded from: /home/kali/Desktop/bunt/agah/dex_files/classes2.dex */
public final /* synthetic */ class y0 implements SwipeRefreshLayout.j {
    public final /* synthetic */ z0 a;

    public final void a() {
        z0.r2(this.a);
    }
}
