package u2;

import android.view.View;

/* JADX INFO: compiled from: R8$$SyntheticClass */
/* JADX INFO: loaded from: /home/kali/Desktop/bunt/agah/dex_files/classes2.dex */
public final /* synthetic */ class x0 implements View.OnClickListener {
    public final /* synthetic */ View o;

    @Override // android.view.View.OnClickListener
    public final void onClick(View view) {
        z0.q2(this.o, view);
    }
}
