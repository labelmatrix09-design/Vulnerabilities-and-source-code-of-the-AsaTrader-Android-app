package u2;

import android.view.View;

/* JADX INFO: compiled from: R8$$SyntheticClass */
/* JADX INFO: loaded from: /home/kali/Desktop/bunt/agah/dex_files/classes2.dex */
public final /* synthetic */ class c1 implements View.OnClickListener {
    public final /* synthetic */ f1 o;

    @Override // android.view.View.OnClickListener
    public final void onClick(View view) {
        f1.u2(this.o, view);
    }
}
