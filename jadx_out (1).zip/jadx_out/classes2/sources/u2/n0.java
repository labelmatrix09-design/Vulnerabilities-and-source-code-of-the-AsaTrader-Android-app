package u2;

import android.view.View;

/* JADX INFO: compiled from: R8$$SyntheticClass */
/* JADX INFO: loaded from: /home/kali/Desktop/bunt/agah/dex_files/classes2.dex */
public final /* synthetic */ class n0 implements Runnable {
    public final /* synthetic */ int o;
    public final /* synthetic */ boolean p;
    public final /* synthetic */ View q;
    public final /* synthetic */ o0 r;

    public /* synthetic */ n0(int i, boolean z, View view, o0 o0Var) {
        this.o = i;
        this.p = z;
        this.q = view;
        this.r = o0Var;
    }

    @Override // java.lang.Runnable
    public final void run() {
        o0.v2(this.o, this.p, this.q, this.r);
    }
}
