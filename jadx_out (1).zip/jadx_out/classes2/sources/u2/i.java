package u2;

/* JADX INFO: compiled from: R8$$SyntheticClass */
/* JADX INFO: loaded from: /home/kali/Desktop/bunt/agah/dex_files/classes2.dex */
public final /* synthetic */ class i implements Runnable {
    public final /* synthetic */ j o;

    @Override // java.lang.Runnable
    public final void run() {
        j.y2(this.o);
    }
}
