package y2;

import android.view.View;
import com.agah.trader.controller.feedback.FeedbackPage;

/* JADX INFO: compiled from: R8$$SyntheticClass */
/* JADX INFO: loaded from: /home/kali/Desktop/bunt/agah/dex_files/classes2.dex */
public final /* synthetic */ class c implements View.OnClickListener {
    public final /* synthetic */ FeedbackPage o;

    @Override // android.view.View.OnClickListener
    public final void onClick(View view) {
        FeedbackPage.L0(this.o, view);
    }
}
