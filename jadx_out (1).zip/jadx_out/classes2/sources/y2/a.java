package y2;

import android.view.View;
import com.agah.trader.controller.feedback.CategoriesPage;
import v4.h0;

/* JADX INFO: compiled from: R8$$SyntheticClass */
/* JADX INFO: loaded from: /home/kali/Desktop/bunt/agah/dex_files/classes2.dex */
public final /* synthetic */ class a implements View.OnClickListener {
    public final /* synthetic */ CategoriesPage o;
    public final /* synthetic */ h0 p;

    public /* synthetic */ a(CategoriesPage categoriesPage, h0 h0Var) {
        this.o = categoriesPage;
        this.p = h0Var;
    }

    @Override // android.view.View.OnClickListener
    public final void onClick(View view) {
        CategoriesPage.K0(this.o, this.p, view);
    }
}
