package y2;

import android.app.Dialog;
import android.view.View;
import com.agah.trader.controller.feedback.FeedbackPage;

/* JADX INFO: compiled from: R8$$SyntheticClass */
/* JADX INFO: loaded from: /home/kali/Desktop/bunt/agah/dex_files/classes2.dex */
public final /* synthetic */ class e implements View.OnClickListener {
    public final /* synthetic */ FeedbackPage o;
    public final /* synthetic */ Dialog p;

    public /* synthetic */ e(FeedbackPage feedbackPage, Dialog dialog) {
        this.o = feedbackPage;
        this.p = dialog;
    }

    @Override // android.view.View.OnClickListener
    public final void onClick(View view) {
        FeedbackPage.N0(this.o, this.p, view);
    }
}
