package y2;

import android.app.Dialog;
import android.view.View;
import com.agah.trader.controller.feedback.FeedbackPage;

/* JADX INFO: compiled from: R8$$SyntheticClass */
/* JADX INFO: loaded from: /home/kali/Desktop/bunt/agah/dex_files/classes2.dex */
public final /* synthetic */ class d implements View.OnClickListener {
    public final /* synthetic */ FeedbackPage o;
    public final /* synthetic */ Dialog p;

    public /* synthetic */ d(FeedbackPage feedbackPage, Dialog dialog) {
        this.o = feedbackPage;
        this.p = dialog;
    }

    @Override // android.view.View.OnClickListener
    public final void onClick(View view) {
        FeedbackPage.M0(this.o, this.p, view);
    }
}
