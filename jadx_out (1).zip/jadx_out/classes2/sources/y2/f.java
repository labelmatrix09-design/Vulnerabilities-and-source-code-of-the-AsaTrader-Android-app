package y2;

import android.content.DialogInterface;
import com.agah.trader.controller.feedback.FeedbackPage;

/* JADX INFO: compiled from: R8$$SyntheticClass */
/* JADX INFO: loaded from: /home/kali/Desktop/bunt/agah/dex_files/classes2.dex */
public final /* synthetic */ class f implements DialogInterface.OnDismissListener {
    public final /* synthetic */ FeedbackPage o;

    @Override // android.content.DialogInterface.OnDismissListener
    public final void onDismiss(DialogInterface dialogInterface) {
        FeedbackPage.i.a(this.o, dialogInterface);
    }
}
