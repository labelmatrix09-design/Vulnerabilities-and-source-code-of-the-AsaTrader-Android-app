package r2;

import androidx.lifecycle.c0;
import com.agah.trader.controller.agreement.AgreementsPage;

/* JADX INFO: compiled from: R8$$SyntheticClass */
/* JADX INFO: loaded from: /home/kali/Desktop/bunt/agah/dex_files/classes2.dex */
public final /* synthetic */ class h implements c0 {
    public final /* synthetic */ AgreementsPage a;

    public final void a(Object obj) {
        AgreementsPage.L0(this.a, (Boolean) obj);
    }
}
