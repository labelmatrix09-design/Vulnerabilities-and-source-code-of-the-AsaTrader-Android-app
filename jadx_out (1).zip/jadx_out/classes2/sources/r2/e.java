package r2;

import android.view.View;
import com.agah.trader.controller.agreement.AgreementsPage;

/* JADX INFO: compiled from: R8$$SyntheticClass */
/* JADX INFO: loaded from: /home/kali/Desktop/bunt/agah/dex_files/classes2.dex */
public final /* synthetic */ class e implements View.OnClickListener {
    public final /* synthetic */ AgreementsPage o;

    @Override // android.view.View.OnClickListener
    public final void onClick(View view) {
        AgreementsPage.N0(this.o, view);
    }
}
