package r2;

import android.widget.CompoundButton;
import com.agah.trader.controller.agreement.AgreementContentPage;

/* JADX INFO: compiled from: R8$$SyntheticClass */
/* JADX INFO: loaded from: /home/kali/Desktop/bunt/agah/dex_files/classes2.dex */
public final /* synthetic */ class c implements CompoundButton.OnCheckedChangeListener {
    public final /* synthetic */ AgreementContentPage a;
    public final /* synthetic */ int b;

    public /* synthetic */ c(AgreementContentPage agreementContentPage, int i) {
        this.a = agreementContentPage;
        this.b = i;
    }

    @Override // android.widget.CompoundButton.OnCheckedChangeListener
    public final void onCheckedChanged(CompoundButton compoundButton, boolean z) {
        AgreementContentPage.K0(this.a, this.b, compoundButton, z);
    }
}
