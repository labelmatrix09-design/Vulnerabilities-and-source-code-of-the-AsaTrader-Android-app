package r2;

import com.agah.trader.controller.agreement.AgreementsPage;

/* JADX INFO: compiled from: R8$$SyntheticClass */
/* JADX INFO: loaded from: /home/kali/Desktop/bunt/agah/dex_files/classes2.dex */
public final /* synthetic */ class j implements Runnable {
    public final /* synthetic */ AgreementsPage o;

    @Override // java.lang.Runnable
    public final void run() {
        AgreementsPage.O0(this.o);
    }
}
