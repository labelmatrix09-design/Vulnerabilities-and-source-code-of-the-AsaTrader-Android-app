package r2;

import android.view.View;
import com.agah.trader.controller.agreement.AgreementsPage;

/* JADX INFO: compiled from: R8$$SyntheticClass */
/* JADX INFO: loaded from: /home/kali/Desktop/bunt/agah/dex_files/classes2.dex */
public final /* synthetic */ class f implements View.OnClickListener {
    public final /* synthetic */ AgreementsPage o;
    public final /* synthetic */ v4.j p;

    public /* synthetic */ f(AgreementsPage agreementsPage, v4.j jVar) {
        this.o = agreementsPage;
        this.p = jVar;
    }

    @Override // android.view.View.OnClickListener
    public final void onClick(View view) {
        AgreementsPage.P0(this.o, this.p, view);
    }
}
