package r2;

import android.view.View;
import com.agah.trader.controller.agreement.AgreementContentPage;

/* JADX INFO: compiled from: R8$$SyntheticClass */
/* JADX INFO: loaded from: /home/kali/Desktop/bunt/agah/dex_files/classes2.dex */
public final /* synthetic */ class b implements View.OnClickListener {
    public final /* synthetic */ AgreementContentPage o;

    @Override // android.view.View.OnClickListener
    public final void onClick(View view) {
        AgreementContentPage.M0(this.o, view);
    }
}
