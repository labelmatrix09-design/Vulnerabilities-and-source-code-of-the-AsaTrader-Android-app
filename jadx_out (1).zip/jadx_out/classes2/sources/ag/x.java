package ag;

import android.annotation.SuppressLint;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Build;
import android.os.PowerManager;
import android.util.Log;
import java.io.IOException;
import rf.c0;

/* JADX INFO: compiled from: com.google.firebase:firebase-messaging@@20.2.3 */
/* JADX INFO: loaded from: /home/kali/Desktop/bunt/agah/dex_files/classes2.dex */
public class x implements Runnable {
    public static final Object t = new Object();
    public static Boolean u;
    public static Boolean v;
    public final Context o;
    public final c0 p;
    public final PowerManager.WakeLock q;
    public final w r;
    public final long s;

    /* JADX INFO: compiled from: com.google.firebase:firebase-messaging@@20.2.3 */
    public class a extends BroadcastReceiver {
        public x a;

        public a(x xVar) {
            this.a = xVar;
        }

        public void a() {
            x.j();
            x.this.o.registerReceiver(this, new IntentFilter("android.net.conn.CONNECTIVITY_CHANGE"));
        }

        @Override // android.content.BroadcastReceiver
        public synchronized void onReceive(Context context, Intent intent) {
            x xVar = this.a;
            if (xVar == null) {
                return;
            }
            if (xVar.i()) {
                x.j();
                this.a.r.l(this.a, 0L);
                context.unregisterReceiver(this);
                this.a = null;
            }
        }
    }

    public x(w wVar, Context context, c0 c0Var, long j) {
        this.r = wVar;
        this.o = context;
        this.s = j;
        this.p = c0Var;
        this.q = ((PowerManager) context.getSystemService("power")).newWakeLock(1, "wake:com.google.firebase.messaging");
    }

    public static String e(String str) {
        StringBuilder sb = new StringBuilder(String.valueOf(str).length() + 142);
        sb.append("Missing Permission: ");
        sb.append(str);
        sb.append(". This permission should normally be included by the manifest merger, but may needed to be manually added to your manifest");
        return sb.toString();
    }

    public static boolean f(Context context) {
        boolean zBooleanValue;
        synchronized (t) {
            Boolean bool = v;
            Boolean boolValueOf = Boolean.valueOf(bool == null ? g(context, "android.permission.ACCESS_NETWORK_STATE", bool) : bool.booleanValue());
            v = boolValueOf;
            zBooleanValue = boolValueOf.booleanValue();
        }
        return zBooleanValue;
    }

    public static boolean g(Context context, String str, Boolean bool) {
        if (bool != null) {
            return bool.booleanValue();
        }
        boolean z = context.checkCallingOrSelfPermission(str) == 0;
        if (!z && Log.isLoggable("FirebaseMessaging", 3)) {
            e(str);
        }
        return z;
    }

    public static boolean h(Context context) {
        boolean zBooleanValue;
        synchronized (t) {
            Boolean bool = u;
            Boolean boolValueOf = Boolean.valueOf(bool == null ? g(context, "android.permission.WAKE_LOCK", bool) : bool.booleanValue());
            u = boolValueOf;
            zBooleanValue = boolValueOf.booleanValue();
        }
        return zBooleanValue;
    }

    public static boolean j() {
        if (Log.isLoggable("FirebaseMessaging", 3)) {
            return true;
        }
        return Build.VERSION.SDK_INT == 23 && Log.isLoggable("FirebaseMessaging", 3);
    }

    public final synchronized boolean i() {
        NetworkInfo activeNetworkInfo;
        ConnectivityManager connectivityManager = (ConnectivityManager) this.o.getSystemService("connectivity");
        activeNetworkInfo = connectivityManager != null ? connectivityManager.getActiveNetworkInfo() : null;
        return activeNetworkInfo != null && activeNetworkInfo.isConnected();
    }

    @Override // java.lang.Runnable
    @SuppressLint({"Wakelock"})
    public void run() {
        if (h(this.o)) {
            this.q.acquire(b.a);
        }
        try {
            this.r.m(true);
            if (!this.p.g()) {
                this.r.m(false);
            } else if (f(this.o) && !i()) {
                new a(this).a();
            } else {
                if (this.r.p()) {
                    this.r.m(false);
                } else {
                    this.r.q(this.s);
                }
            }
        } catch (IOException e) {
            String strValueOf = String.valueOf(e.getMessage());
            if (strValueOf.length() != 0) {
                "Failed to sync topics. Won't retry sync. ".concat(strValueOf);
            }
            this.r.m(false);
        } finally {
            if (h(this.o)) {
                try {
                    this.q.release();
                } catch (RuntimeException unused) {
                }
            }
        }
    }
}
