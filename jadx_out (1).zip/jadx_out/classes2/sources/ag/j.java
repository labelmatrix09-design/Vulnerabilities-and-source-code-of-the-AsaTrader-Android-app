package ag;

import com.google.firebase.messaging.FirebaseMessagingRegistrar;

/* JADX INFO: compiled from: com.google.firebase:firebase-messaging@@20.2.3 */
/* JADX INFO: loaded from: /home/kali/Desktop/bunt/agah/dex_files/classes2.dex */
public final /* synthetic */ class j implements kf.h {
    public static final kf.h a = new j();

    @Override // kf.h
    public final Object a(kf.e eVar) {
        return FirebaseMessagingRegistrar.lambda$getComponents$0$FirebaseMessagingRegistrar(eVar);
    }
}
