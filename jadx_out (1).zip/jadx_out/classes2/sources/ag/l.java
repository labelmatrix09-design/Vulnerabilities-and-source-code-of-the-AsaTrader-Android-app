package ag;

import android.content.Intent;

/* JADX INFO: compiled from: com.google.firebase:firebase-messaging@@20.2.3 */
/* JADX INFO: loaded from: /home/kali/Desktop/bunt/agah/dex_files/classes2.dex */
public final class l {
    public final String a;
    public final Intent b;

    /* JADX INFO: compiled from: com.google.firebase:firebase-messaging@@20.2.3 */
    public static class a implements nf.c<l> {
        @Override // nf.b
        /* JADX INFO: renamed from: b, reason: merged with bridge method [inline-methods] */
        public void a(l lVar, nf.d dVar) {
            Intent intentB = lVar.b();
            dVar.b("ttl", o.q(intentB));
            dVar.e("event", lVar.a());
            dVar.e("instanceId", o.e());
            dVar.b("priority", o.n(intentB));
            dVar.e("packageName", o.m());
            dVar.e("sdkPlatform", "ANDROID");
            dVar.e("messageType", o.k(intentB));
            String strG = o.g(intentB);
            if (strG != null) {
                dVar.e("messageId", strG);
            }
            String strP = o.p(intentB);
            if (strP != null) {
                dVar.e("topic", strP);
            }
            String strB = o.b(intentB);
            if (strB != null) {
                dVar.e("collapseKey", strB);
            }
            if (o.h(intentB) != null) {
                dVar.e("analyticsLabel", o.h(intentB));
            }
            if (o.d(intentB) != null) {
                dVar.e("composerLabel", o.d(intentB));
            }
            String strO = o.o();
            if (strO != null) {
                dVar.e("projectNumber", strO);
            }
        }
    }

    /* JADX INFO: compiled from: com.google.firebase:firebase-messaging@@20.2.3 */
    public static final class b {
        public final l a;

        public b(l lVar) {
            this.a = (l) fd.o.j(lVar);
        }

        public final l a() {
            return this.a;
        }
    }

    /* JADX INFO: compiled from: com.google.firebase:firebase-messaging@@20.2.3 */
    public static final class c implements nf.c<b> {
        @Override // nf.b
        /* JADX INFO: renamed from: b, reason: merged with bridge method [inline-methods] */
        public final void a(b bVar, nf.d dVar) {
            dVar.e("messaging_client_event", bVar.a());
        }
    }

    public l(String str, Intent intent) {
        this.a = fd.o.g(str, "evenType must be non-null");
        this.b = (Intent) fd.o.k(intent, "intent must be non-null");
    }

    public final String a() {
        return this.a;
    }

    public final Intent b() {
        return this.b;
    }
}
