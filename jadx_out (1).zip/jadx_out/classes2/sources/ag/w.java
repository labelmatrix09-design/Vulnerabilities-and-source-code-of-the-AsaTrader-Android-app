package ag;

import android.content.Context;
import android.os.Build;
import android.util.Log;
import com.google.firebase.iid.FirebaseInstanceId;
import java.io.IOException;
import java.util.ArrayDeque;
import java.util.Map;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;
import rf.c0;

/* JADX INFO: compiled from: com.google.firebase:firebase-messaging@@20.2.3 */
/* JADX INFO: loaded from: /home/kali/Desktop/bunt/agah/dex_files/classes2.dex */
public class w {
    public static final long i = TimeUnit.HOURS.toSeconds(8);
    public final FirebaseInstanceId a;
    public final Context b;
    public final c0 c;
    public final rf.r d;
    public final ScheduledExecutorService f;
    public final u h;
    public final Map<String, ArrayDeque<ce.h<Void>>> e = new p.a();
    public boolean g = false;

    public w(FirebaseInstanceId firebaseInstanceId, c0 c0Var, u uVar, rf.r rVar, Context context, ScheduledExecutorService scheduledExecutorService) {
        this.a = firebaseInstanceId;
        this.c = c0Var;
        this.h = uVar;
        this.d = rVar;
        this.b = context;
        this.f = scheduledExecutorService;
    }

    public static <T> T a(ce.g<T> gVar) throws IOException {
        try {
            return (T) ce.j.b(gVar, 30L, TimeUnit.SECONDS);
        } catch (InterruptedException e) {
            e = e;
            throw new IOException("SERVICE_NOT_AVAILABLE", e);
        } catch (ExecutionException e2) {
            Throwable cause = e2.getCause();
            if (cause instanceof IOException) {
                throw ((IOException) cause);
            }
            if (cause instanceof RuntimeException) {
                throw ((RuntimeException) cause);
            }
            throw new IOException(e2);
        } catch (TimeoutException e5) {
            e = e5;
            throw new IOException("SERVICE_NOT_AVAILABLE", e);
        }
    }

    public static ce.g<w> d(final FirebaseInstanceId firebaseInstanceId, final c0 c0Var, final rf.r rVar, final Context context, final ScheduledExecutorService scheduledExecutorService) {
        return ce.j.c(scheduledExecutorService, new Callable(context, scheduledExecutorService, firebaseInstanceId, c0Var, rVar) { // from class: ag.v
            public final Context a;
            public final ScheduledExecutorService b;
            public final FirebaseInstanceId c;
            public final c0 d;
            public final rf.r e;

            {
                this.a = context;
                this.b = scheduledExecutorService;
                this.c = firebaseInstanceId;
                this.d = c0Var;
                this.e = rVar;
            }

            @Override // java.util.concurrent.Callable
            public final Object call() {
                return w.i(this.a, this.b, this.c, this.d, this.e);
            }
        });
    }

    public static ce.g<w> e(gf.c cVar, FirebaseInstanceId firebaseInstanceId, c0 c0Var, bg.i iVar, qf.f fVar, uf.f fVar2, Context context, ScheduledExecutorService scheduledExecutorService) {
        return d(firebaseInstanceId, c0Var, new rf.r(cVar, c0Var, iVar, fVar, fVar2), context, scheduledExecutorService);
    }

    public static boolean g() {
        if (Log.isLoggable("FirebaseMessaging", 3)) {
            return true;
        }
        return Build.VERSION.SDK_INT == 23 && Log.isLoggable("FirebaseMessaging", 3);
    }

    public static final /* synthetic */ w i(Context context, ScheduledExecutorService scheduledExecutorService, FirebaseInstanceId firebaseInstanceId, c0 c0Var, rf.r rVar) {
        return new w(firebaseInstanceId, c0Var, u.a(context, scheduledExecutorService), rVar, context, scheduledExecutorService);
    }

    public final void b(String str) throws IOException {
        rf.u uVar = (rf.u) a(this.a.m());
        a(this.d.j(uVar.getId(), uVar.a(), str));
    }

    public final void c(String str) throws IOException {
        rf.u uVar = (rf.u) a(this.a.m());
        a(this.d.k(uVar.getId(), uVar.a(), str));
    }

    public boolean f() {
        return this.h.b() != null;
    }

    public synchronized boolean h() {
        return this.g;
    }

    public final void j(t tVar) {
        synchronized (this.e) {
            String strE = tVar.e();
            if (this.e.containsKey(strE)) {
                ArrayDeque<ce.h<Void>> arrayDeque = this.e.get(strE);
                ce.h<Void> hVarPoll = arrayDeque.poll();
                if (hVarPoll != null) {
                    hVarPoll.c((Object) null);
                }
                if (arrayDeque.isEmpty()) {
                    this.e.remove(strE);
                }
            }
        }
    }

    public boolean k(t tVar) throws IOException {
        try {
            String strB = tVar.b();
            byte b = -1;
            int iHashCode = strB.hashCode();
            if (iHashCode != 83) {
                if (iHashCode == 85 && strB.equals("U")) {
                    b = 1;
                }
            } else if (strB.equals("S")) {
                b = 0;
            }
            if (b == 0) {
                b(tVar.c());
                if (g()) {
                    String strC = tVar.c();
                    StringBuilder sb = new StringBuilder(String.valueOf(strC).length() + 31);
                    sb.append("Subscribe to topic: ");
                    sb.append(strC);
                    sb.append(" succeeded.");
                }
            } else if (b == 1) {
                c(tVar.c());
                if (g()) {
                    String strC2 = tVar.c();
                    StringBuilder sb2 = new StringBuilder(String.valueOf(strC2).length() + 35);
                    sb2.append("Unsubscribe from topic: ");
                    sb2.append(strC2);
                    sb2.append(" succeeded.");
                }
            } else if (g()) {
                String strValueOf = String.valueOf(tVar);
                StringBuilder sb3 = new StringBuilder(strValueOf.length() + 24);
                sb3.append("Unknown topic operation");
                sb3.append(strValueOf);
                sb3.append(".");
            }
            return true;
        } catch (IOException e) {
            if (!"SERVICE_NOT_AVAILABLE".equals(e.getMessage()) && !"INTERNAL_SERVER_ERROR".equals(e.getMessage())) {
                if (e.getMessage() == null) {
                    return false;
                }
                throw e;
            }
            String message = e.getMessage();
            StringBuilder sb4 = new StringBuilder(String.valueOf(message).length() + 53);
            sb4.append("Topic operation failed: ");
            sb4.append(message);
            sb4.append(". Will retry Topic operation.");
            return false;
        }
    }

    public void l(Runnable runnable, long j) {
        this.f.schedule(runnable, j, TimeUnit.SECONDS);
    }

    public synchronized void m(boolean z) {
        this.g = z;
    }

    public final void n() {
        if (h()) {
            return;
        }
        q(0L);
    }

    public void o() {
        if (f()) {
            n();
        }
    }

    public boolean p() {
        while (true) {
            synchronized (this) {
                t tVarB = this.h.b();
                if (tVarB == null) {
                    g();
                    return true;
                }
                if (!k(tVarB)) {
                    return false;
                }
                this.h.d(tVarB);
                j(tVarB);
            }
        }
    }

    public void q(long j) {
        l(new x(this, this.b, this.c, Math.min(Math.max(30L, j << 1), i)), j);
        m(true);
    }
}
