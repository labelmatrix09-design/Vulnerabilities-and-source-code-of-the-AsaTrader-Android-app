package ag;

/* JADX INFO: compiled from: com.google.firebase:firebase-messaging@@20.2.3 */
/* JADX INFO: loaded from: /home/kali/Desktop/bunt/agah/dex_files/classes2.dex */
public final /* synthetic */ class k implements ka.e {
    public static final ka.e a = new k();

    public final Object apply(Object obj) {
        return ((String) obj).getBytes();
    }
}
