package ag;

import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable;
import com.google.android.gms.common.internal.safeparcel.SafeParcelReader;
import com.google.firebase.messaging.RemoteMessage;

/* JADX INFO: compiled from: com.google.firebase:firebase-messaging@@20.2.3 */
/* JADX INFO: loaded from: /home/kali/Desktop/bunt/agah/dex_files/classes2.dex */
public class q implements Parcelable.Creator<RemoteMessage> {
    public static void c(RemoteMessage remoteMessage, Parcel parcel, int i) {
        int iA = gd.a.a(parcel);
        gd.a.e(parcel, 2, remoteMessage.o, false);
        gd.a.b(parcel, iA);
    }

    @Override // android.os.Parcelable.Creator
    /* JADX INFO: renamed from: a, reason: merged with bridge method [inline-methods] */
    public RemoteMessage createFromParcel(Parcel parcel) {
        int iJ = SafeParcelReader.J(parcel);
        Bundle bundleF = null;
        while (parcel.dataPosition() < iJ) {
            int iB = SafeParcelReader.B(parcel);
            if (SafeParcelReader.u(iB) != 2) {
                SafeParcelReader.I(parcel, iB);
            } else {
                bundleF = SafeParcelReader.f(parcel, iB);
            }
        }
        SafeParcelReader.t(parcel, iJ);
        return new RemoteMessage(bundleF);
    }

    @Override // android.os.Parcelable.Creator
    /* JADX INFO: renamed from: b, reason: merged with bridge method [inline-methods] */
    public RemoteMessage[] newArray(int i) {
        return new RemoteMessage[i];
    }
}
