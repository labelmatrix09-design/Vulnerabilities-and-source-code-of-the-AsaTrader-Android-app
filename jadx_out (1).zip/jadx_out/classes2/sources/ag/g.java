package ag;

import android.annotation.SuppressLint;
import android.app.Service;
import android.content.Intent;
import android.os.Binder;
import android.os.IBinder;
import android.util.Log;
import java.util.concurrent.ExecutorService;
import rf.m0;
import rf.o0;

/* JADX INFO: compiled from: com.google.firebase:firebase-messaging@@20.2.3 */
/* JADX INFO: loaded from: /home/kali/Desktop/bunt/agah/dex_files/classes2.dex */
@SuppressLint({"UnwrappedWakefulBroadcastReceiver"})
public abstract class g extends Service {
    public Binder p;
    public int r;
    public final ExecutorService o = h.b();
    public final Object q = new Object();
    public int s = 0;

    /* JADX INFO: compiled from: com.google.firebase:firebase-messaging@@20.2.3 */
    public class a implements o0.a {
        public a() {
        }

        @Override // rf.o0.a
        public ce.g<Void> a(Intent intent) {
            return g.this.h(intent);
        }
    }

    public final void b(Intent intent) {
        if (intent != null) {
            m0.b(intent);
        }
        synchronized (this.q) {
            int i = this.s - 1;
            this.s = i;
            if (i == 0) {
                i(this.r);
            }
        }
    }

    public Intent c(Intent intent) {
        return intent;
    }

    public abstract void d(Intent intent);

    public boolean e(Intent intent) {
        return false;
    }

    public final /* synthetic */ void f(Intent intent, ce.g gVar) {
        b(intent);
    }

    public final /* synthetic */ void g(Intent intent, ce.h hVar) {
        try {
            d(intent);
        } finally {
            hVar.c((Object) null);
        }
    }

    public final ce.g<Void> h(final Intent intent) {
        if (e(intent)) {
            return ce.j.e((Object) null);
        }
        final ce.h hVar = new ce.h();
        this.o.execute(new Runnable(this, intent, hVar) { // from class: ag.d
            public final g o;
            public final Intent p;
            public final ce.h q;

            {
                this.o = this;
                this.p = intent;
                this.q = hVar;
            }

            @Override // java.lang.Runnable
            public final void run() {
                this.o.g(this.p, this.q);
            }
        });
        return hVar.a();
    }

    public boolean i(int i) {
        return stopSelfResult(i);
    }

    @Override // android.app.Service
    public final synchronized IBinder onBind(Intent intent) {
        Log.isLoggable("EnhancedIntentService", 3);
        if (this.p == null) {
            this.p = new o0(new a());
        }
        return this.p;
    }

    @Override // android.app.Service
    public void onDestroy() {
        this.o.shutdown();
        super.onDestroy();
    }

    @Override // android.app.Service
    public final int onStartCommand(final Intent intent, int i, int i3) {
        synchronized (this.q) {
            this.r = i3;
            this.s++;
        }
        Intent intentC = c(intent);
        if (intentC == null) {
            b(intent);
            return 2;
        }
        ce.g<Void> gVarH = h(intentC);
        if (gVarH.k()) {
            b(intent);
            return 2;
        }
        gVarH.b(e.o, new ce.c(this, intent) { // from class: ag.f
            public final g a;
            public final Intent b;

            {
                this.a = this;
                this.b = intent;
            }

            public final void a(ce.g gVar) {
                this.a.f(this.b, gVar);
            }
        });
        return 3;
    }
}
