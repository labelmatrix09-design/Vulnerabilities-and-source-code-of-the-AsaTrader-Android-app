package ag;

import android.content.SharedPreferences;
import android.text.TextUtils;
import io.github.inflationx.calligraphy3.BuildConfig;
import java.util.ArrayDeque;
import java.util.Iterator;
import java.util.concurrent.Executor;

/* JADX INFO: compiled from: com.google.firebase:firebase-messaging@@20.2.3 */
/* JADX INFO: loaded from: /home/kali/Desktop/bunt/agah/dex_files/classes2.dex */
public final class s {
    public final SharedPreferences a;
    public final String b;
    public final String c;
    public final Executor e;
    public final ArrayDeque<String> d = new ArrayDeque<>();
    public boolean f = false;

    public s(SharedPreferences sharedPreferences, String str, String str2, Executor executor) {
        this.a = sharedPreferences;
        this.b = str;
        this.c = str2;
        this.e = executor;
    }

    public static s c(SharedPreferences sharedPreferences, String str, String str2, Executor executor) {
        s sVar = new s(sharedPreferences, str, str2, executor);
        sVar.d();
        return sVar;
    }

    public final boolean b(boolean z) {
        if (z && !this.f) {
            i();
        }
        return z;
    }

    public final void d() {
        synchronized (this.d) {
            this.d.clear();
            String string = this.a.getString(this.b, BuildConfig.FLAVOR);
            if (!TextUtils.isEmpty(string) && string.contains(this.c)) {
                String[] strArrSplit = string.split(this.c, -1);
                int length = strArrSplit.length;
                for (String str : strArrSplit) {
                    if (!TextUtils.isEmpty(str)) {
                        this.d.add(str);
                    }
                }
            }
        }
    }

    public final String e() {
        String strPeek;
        synchronized (this.d) {
            strPeek = this.d.peek();
        }
        return strPeek;
    }

    public final boolean f(Object obj) {
        boolean zB;
        synchronized (this.d) {
            zB = b(this.d.remove(obj));
        }
        return zB;
    }

    public final String g() {
        StringBuilder sb = new StringBuilder();
        Iterator<String> it = this.d.iterator();
        while (it.hasNext()) {
            sb.append(it.next());
            sb.append(this.c);
        }
        return sb.toString();
    }

    /* JADX INFO: renamed from: h, reason: merged with bridge method [inline-methods] */
    public final void a() {
        synchronized (this.d) {
            this.a.edit().putString(this.b, g()).commit();
        }
    }

    public final void i() {
        this.e.execute(new Runnable(this) { // from class: ag.r
            public final s o;

            {
                this.o = this;
            }

            @Override // java.lang.Runnable
            public final void run() {
                this.o.a();
            }
        });
    }
}
