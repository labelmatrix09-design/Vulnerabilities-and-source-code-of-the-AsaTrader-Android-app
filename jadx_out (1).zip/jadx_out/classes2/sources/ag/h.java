package ag;

import java.util.concurrent.BlockingQueue;
import java.util.concurrent.Executor;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ScheduledThreadPoolExecutor;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

/* JADX INFO: compiled from: com.google.firebase:firebase-messaging@@20.2.3 */
/* JADX INFO: loaded from: /home/kali/Desktop/bunt/agah/dex_files/classes2.dex */
public class h {
    public static Executor a(String str) {
        return new ThreadPoolExecutor(0, 1, 30L, TimeUnit.SECONDS, (BlockingQueue<Runnable>) new LinkedBlockingQueue(), (ThreadFactory) new nd.b(str));
    }

    public static ExecutorService b() {
        return vd.a.a().a(new nd.b("Firebase-Messaging-Intent-Handle"), vd.f.a);
    }

    public static ExecutorService c() {
        return Executors.newSingleThreadExecutor(new nd.b("Firebase-Messaging-Network-Io"));
    }

    public static ScheduledExecutorService d() {
        return new ScheduledThreadPoolExecutor(1, (ThreadFactory) new nd.b("Firebase-Messaging-Topics-Io"));
    }

    public static Executor e() {
        return a("Firebase-Messaging-Trigger-Topics-Io");
    }
}
