package ag;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.text.TextUtils;
import android.util.Log;
import java.io.Closeable;
import java.io.IOException;
import java.io.InputStream;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;
import java.util.concurrent.Callable;
import java.util.concurrent.Executor;

/* JADX INFO: compiled from: com.google.firebase:firebase-messaging@@20.2.3 */
/* JADX INFO: loaded from: /home/kali/Desktop/bunt/agah/dex_files/classes2.dex */
public class n implements Closeable {
    public final URL o;
    public ce.g<Bitmap> p;
    public volatile InputStream q;

    public n(URL url) {
        this.o = url;
    }

    public static n f(String str) {
        if (TextUtils.isEmpty(str)) {
            return null;
        }
        try {
            return new n(new URL(str));
        } catch (MalformedURLException unused) {
            String strValueOf = String.valueOf(str);
            if (strValueOf.length() != 0) {
                "Not downloading image, bad URL: ".concat(strValueOf);
            }
            return null;
        }
    }

    public Bitmap a() throws IOException {
        String strValueOf = String.valueOf(this.o);
        StringBuilder sb = new StringBuilder(strValueOf.length() + 22);
        sb.append("Starting download of: ");
        sb.append(strValueOf);
        byte[] bArrB = b();
        Bitmap bitmapDecodeByteArray = BitmapFactory.decodeByteArray(bArrB, 0, bArrB.length);
        if (bitmapDecodeByteArray == null) {
            String strValueOf2 = String.valueOf(this.o);
            StringBuilder sb2 = new StringBuilder(strValueOf2.length() + 24);
            sb2.append("Failed to decode image: ");
            sb2.append(strValueOf2);
            throw new IOException(sb2.toString());
        }
        if (Log.isLoggable("FirebaseMessaging", 3)) {
            String strValueOf3 = String.valueOf(this.o);
            StringBuilder sb3 = new StringBuilder(strValueOf3.length() + 31);
            sb3.append("Successfully downloaded image: ");
            sb3.append(strValueOf3);
        }
        return bitmapDecodeByteArray;
    }

    public final byte[] b() throws IOException {
        URLConnection uRLConnectionOpenConnection = this.o.openConnection();
        if (uRLConnectionOpenConnection.getContentLength() > 1048576) {
            throw new IOException("Content-Length exceeds max size of 1048576");
        }
        InputStream inputStream = uRLConnectionOpenConnection.getInputStream();
        try {
            this.q = inputStream;
            byte[] bArrB = vd.h.b(vd.h.a(inputStream, 1048577L));
            if (inputStream != null) {
                inputStream.close();
            }
            if (Log.isLoggable("FirebaseMessaging", 2)) {
                int length = bArrB.length;
                String strValueOf = String.valueOf(this.o);
                StringBuilder sb = new StringBuilder(strValueOf.length() + 34);
                sb.append("Downloaded ");
                sb.append(length);
                sb.append(" bytes from ");
                sb.append(strValueOf);
            }
            if (bArrB.length <= 1048576) {
                return bArrB;
            }
            throw new IOException("Image exceeds max size of 1048576");
        } catch (Throwable th2) {
            if (inputStream != null) {
                try {
                    inputStream.close();
                } catch (Throwable th3) {
                    vd.k.b(th2, th3);
                }
            }
            throw th2;
        }
    }

    @Override // java.io.Closeable, java.lang.AutoCloseable
    public void close() {
        try {
            vd.i.a(this.q);
        } catch (NullPointerException unused) {
        }
    }

    public ce.g<Bitmap> g() {
        return (ce.g) fd.o.j(this.p);
    }

    public void h(Executor executor) {
        this.p = ce.j.c(executor, new Callable(this) { // from class: ag.m
            public final n a;

            {
                this.a = this;
            }

            @Override // java.util.concurrent.Callable
            public final Object call() {
                return this.a.a();
            }
        });
    }
}
