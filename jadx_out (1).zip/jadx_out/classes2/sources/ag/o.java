package ag;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import com.google.firebase.encoders.EncodingException;
import com.google.firebase.iid.FirebaseInstanceId;

/* JADX INFO: compiled from: com.google.firebase:firebase-messaging@@20.2.3 */
/* JADX INFO: loaded from: /home/kali/Desktop/bunt/agah/dex_files/classes2.dex */
public class o {
    public static final nf.a a = new of.c().f(l.b.class, new l.c()).f(l.class, new l.a()).c();

    public static boolean A(Intent intent) {
        if (intent == null || s(intent)) {
            return false;
        }
        return a();
    }

    public static boolean B(Intent intent) {
        if (intent == null || s(intent)) {
            return false;
        }
        return "1".equals(intent.getStringExtra("google.c.a.e"));
    }

    public static boolean a() {
        ApplicationInfo applicationInfo;
        Bundle bundle;
        try {
            gf.c.i();
            Context contextH = gf.c.i().h();
            SharedPreferences sharedPreferences = contextH.getSharedPreferences("com.google.firebase.messaging", 0);
            if (sharedPreferences.contains("export_to_big_query")) {
                return sharedPreferences.getBoolean("export_to_big_query", false);
            }
            PackageManager packageManager = contextH.getPackageManager();
            if (packageManager != null && (applicationInfo = packageManager.getApplicationInfo(contextH.getPackageName(), 128)) != null && (bundle = applicationInfo.metaData) != null && bundle.containsKey("delivery_metrics_exported_to_big_query_enabled")) {
                return applicationInfo.metaData.getBoolean("delivery_metrics_exported_to_big_query_enabled", false);
            }
            return false;
        } catch (PackageManager.NameNotFoundException | IllegalStateException unused) {
        }
    }

    public static String b(Intent intent) {
        return intent.getStringExtra("collapse_key");
    }

    public static String c(Intent intent) {
        return intent.getStringExtra("google.c.a.c_id");
    }

    public static String d(Intent intent) {
        return intent.getStringExtra("google.c.a.c_l");
    }

    public static String e() {
        return FirebaseInstanceId.getInstance(gf.c.i()).j();
    }

    public static String f(Intent intent) {
        return intent.getStringExtra("google.c.a.m_c");
    }

    public static String g(Intent intent) {
        String stringExtra = intent.getStringExtra("google.message_id");
        return stringExtra == null ? intent.getStringExtra("message_id") : stringExtra;
    }

    public static String h(Intent intent) {
        return intent.getStringExtra("google.c.a.m_l");
    }

    public static int i(String str) {
        if ("high".equals(str)) {
            return 1;
        }
        return "normal".equals(str) ? 2 : 0;
    }

    public static String j(Intent intent) {
        return intent.getStringExtra("google.c.a.ts");
    }

    public static String k(Intent intent) {
        return (intent.getExtras() == null || !p.t(intent.getExtras())) ? "DATA_MESSAGE" : "DISPLAY_NOTIFICATION";
    }

    public static String l(Intent intent) {
        return (intent.getExtras() == null || !p.t(intent.getExtras())) ? "data" : "display";
    }

    public static String m() {
        return gf.c.i().h().getPackageName();
    }

    public static int n(Intent intent) {
        String stringExtra = intent.getStringExtra("google.delivered_priority");
        if (stringExtra == null) {
            if ("1".equals(intent.getStringExtra("google.priority_reduced"))) {
                return 2;
            }
            stringExtra = intent.getStringExtra("google.priority");
        }
        return i(stringExtra);
    }

    public static String o() {
        gf.c cVarI = gf.c.i();
        String strD = cVarI.k().d();
        if (strD != null) {
            return strD;
        }
        String strC = cVarI.k().c();
        if (!strC.startsWith("1:")) {
            return strC;
        }
        String[] strArrSplit = strC.split(":");
        if (strArrSplit.length < 2) {
            return null;
        }
        String str = strArrSplit[1];
        if (str.isEmpty()) {
            return null;
        }
        return str;
    }

    public static String p(Intent intent) {
        String stringExtra = intent.getStringExtra("from");
        if (stringExtra == null || !stringExtra.startsWith("/topics/")) {
            return null;
        }
        return stringExtra;
    }

    public static int q(Intent intent) {
        Object obj = intent.getExtras().get("google.ttl");
        if (obj instanceof Integer) {
            return ((Integer) obj).intValue();
        }
        if (!(obj instanceof String)) {
            return 0;
        }
        try {
            return Integer.parseInt((String) obj);
        } catch (NumberFormatException unused) {
            String strValueOf = String.valueOf(obj);
            StringBuilder sb = new StringBuilder(strValueOf.length() + 13);
            sb.append("Invalid TTL: ");
            sb.append(strValueOf);
            return 0;
        }
    }

    public static String r(Intent intent) {
        if (intent.hasExtra("google.c.a.udt")) {
            return intent.getStringExtra("google.c.a.udt");
        }
        return null;
    }

    public static boolean s(Intent intent) {
        return "com.google.firebase.messaging.RECEIVE_DIRECT_BOOT".equals(intent.getAction());
    }

    public static void t(Intent intent) {
        y("_nd", intent);
    }

    public static void u(Intent intent) {
        y("_nf", intent);
    }

    public static void v(Intent intent) {
        z(intent);
        y("_no", intent);
    }

    public static void w(Intent intent, ka.f<String> fVar) {
        y("_nr", intent);
        if (fVar != null) {
            x("MESSAGE_DELIVERED", intent, fVar);
        }
    }

    public static void x(String str, Intent intent, ka.f<String> fVar) {
        try {
            fVar.a(ka.c.d(a.b(new l.b(new l(str, intent)))));
        } catch (EncodingException unused) {
        }
    }

    public static void y(String str, Intent intent) {
        Bundle bundle = new Bundle();
        String strC = c(intent);
        if (strC != null) {
            bundle.putString("_nmid", strC);
        }
        String strD = d(intent);
        if (strD != null) {
            bundle.putString("_nmn", strD);
        }
        String strH = h(intent);
        if (!TextUtils.isEmpty(strH)) {
            bundle.putString("label", strH);
        }
        String strF = f(intent);
        if (!TextUtils.isEmpty(strF)) {
            bundle.putString("message_channel", strF);
        }
        String strP = p(intent);
        if (strP != null) {
            bundle.putString("_nt", strP);
        }
        String strJ = j(intent);
        if (strJ != null) {
            try {
                bundle.putInt("_nmt", Integer.parseInt(strJ));
            } catch (NumberFormatException unused) {
            }
        }
        String strR = r(intent);
        if (strR != null) {
            try {
                bundle.putInt("_ndt", Integer.parseInt(strR));
            } catch (NumberFormatException unused2) {
            }
        }
        String strL = l(intent);
        if ("_nr".equals(str) || "_nf".equals(str)) {
            bundle.putString("_nmc", strL);
        }
        if (Log.isLoggable("FirebaseMessaging", 3)) {
            String strValueOf = String.valueOf(bundle);
            StringBuilder sb = new StringBuilder(String.valueOf(str).length() + 37 + strValueOf.length());
            sb.append("Logging to scion event=");
            sb.append(str);
            sb.append(" scionPayload=");
            sb.append(strValueOf);
        }
        p000if.a aVar = (p000if.a) gf.c.i().g(p000if.a.class);
        if (aVar != null) {
            aVar.a("fcm", str, bundle);
        }
    }

    public static void z(Intent intent) {
        if (intent == null) {
            return;
        }
        if (!"1".equals(intent.getStringExtra("google.c.a.tc"))) {
            Log.isLoggable("FirebaseMessaging", 3);
            return;
        }
        p000if.a aVar = (p000if.a) gf.c.i().g(p000if.a.class);
        Log.isLoggable("FirebaseMessaging", 3);
        if (aVar != null) {
            String stringExtra = intent.getStringExtra("google.c.a.c_id");
            aVar.b("fcm", "_ln", stringExtra);
            Bundle bundle = new Bundle();
            bundle.putString("source", "Firebase");
            bundle.putString("medium", "notification");
            bundle.putString("campaign", stringExtra);
            aVar.a("fcm", "_cmp", bundle);
        }
    }
}
