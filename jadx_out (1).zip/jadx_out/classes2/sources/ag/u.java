package ag;

import android.content.Context;
import android.content.SharedPreferences;
import java.lang.ref.WeakReference;
import java.util.concurrent.Executor;

/* JADX INFO: compiled from: com.google.firebase:firebase-messaging@@20.2.3 */
/* JADX INFO: loaded from: /home/kali/Desktop/bunt/agah/dex_files/classes2.dex */
public final class u {
    public static WeakReference<u> d;
    public final SharedPreferences a;
    public s b;
    public final Executor c;

    public u(SharedPreferences sharedPreferences, Executor executor) {
        this.c = executor;
        this.a = sharedPreferences;
    }

    public static synchronized u a(Context context, Executor executor) {
        u uVar;
        WeakReference<u> weakReference = d;
        uVar = weakReference != null ? weakReference.get() : null;
        if (uVar == null) {
            uVar = new u(context.getSharedPreferences("com.google.android.gms.appid", 0), executor);
            uVar.c();
            d = new WeakReference<>(uVar);
        }
        return uVar;
    }

    public final synchronized t b() {
        return t.a(this.b.e());
    }

    public final synchronized void c() {
        this.b = s.c(this.a, "topic_operation_queue", ",", this.c);
    }

    public final synchronized boolean d(t tVar) {
        return this.b.f(tVar.e());
    }
}
