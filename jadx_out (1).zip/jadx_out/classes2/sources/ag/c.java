package ag;

import android.app.ActivityManager;
import android.app.KeyguardManager;
import android.app.NotificationManager;
import android.content.Context;
import android.graphics.Bitmap;
import android.os.Process;
import android.os.SystemClock;
import android.util.Log;
import java.util.List;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Executor;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;

/* JADX INFO: compiled from: com.google.firebase:firebase-messaging@@20.2.3 */
/* JADX INFO: loaded from: /home/kali/Desktop/bunt/agah/dex_files/classes2.dex */
public class c {
    public final Executor a;
    public final Context b;
    public final p c;

    public c(Context context, p pVar, Executor executor) {
        this.a = executor;
        this.b = context;
        this.c = pVar;
    }

    public boolean a() {
        if (this.c.a("gcm.n.noui")) {
            return true;
        }
        if (b()) {
            return false;
        }
        n nVarD = d();
        a.C0000a c0000aD = a.d(this.b, this.c);
        e(c0000aD.a, nVarD);
        c(c0000aD);
        return true;
    }

    public final boolean b() {
        if (((KeyguardManager) this.b.getSystemService("keyguard")).inKeyguardRestrictedInputMode()) {
            return false;
        }
        if (!md.n.g()) {
            SystemClock.sleep(10L);
        }
        int iMyPid = Process.myPid();
        List<ActivityManager.RunningAppProcessInfo> runningAppProcesses = ((ActivityManager) this.b.getSystemService("activity")).getRunningAppProcesses();
        if (runningAppProcesses != null) {
            for (ActivityManager.RunningAppProcessInfo runningAppProcessInfo : runningAppProcesses) {
                if (runningAppProcessInfo.pid == iMyPid) {
                    if (runningAppProcessInfo.importance == 100) {
                        return true;
                    }
                }
            }
        }
        return false;
    }

    public final void c(a.C0000a c0000a) {
        Log.isLoggable("FirebaseMessaging", 3);
        ((NotificationManager) this.b.getSystemService("notification")).notify(c0000a.b, c0000a.c, c0000a.a.b());
    }

    public final n d() {
        n nVarF = n.f(this.c.p("gcm.n.image"));
        if (nVarF != null) {
            nVarF.h(this.a);
        }
        return nVarF;
    }

    public final void e(a0.m.e eVar, n nVar) {
        if (nVar == null) {
            return;
        }
        try {
            Bitmap bitmap = (Bitmap) ce.j.b(nVar.g(), 5L, TimeUnit.SECONDS);
            eVar.t(bitmap);
            eVar.C(new a0.m.b().i(bitmap).h((Bitmap) null));
        } catch (InterruptedException unused) {
            nVar.close();
            Thread.currentThread().interrupt();
        } catch (ExecutionException e) {
            String strValueOf = String.valueOf(e.getCause());
            StringBuilder sb = new StringBuilder(strValueOf.length() + 26);
            sb.append("Failed to download image: ");
            sb.append(strValueOf);
        } catch (TimeoutException unused2) {
            nVar.close();
        }
    }
}
