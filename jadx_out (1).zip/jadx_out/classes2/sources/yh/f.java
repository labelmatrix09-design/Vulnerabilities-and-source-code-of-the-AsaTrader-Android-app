package yh;

import com.onesignal.d2;
import com.onesignal.d3;
import com.onesignal.g1;
import com.onesignal.l2;
import com.onesignal.t2$s;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.ConcurrentHashMap;
import jl.l;
import org.json.JSONObject;
import xk.n;

/* JADX INFO: compiled from: OSTrackerFactory.kt */
/* JADX INFO: loaded from: /home/kali/Desktop/bunt/agah/dex_files/classes2.dex */
public final class f {
    public final ConcurrentHashMap<String, a> a;
    public final c b;

    public f(d2 d2Var, g1 g1Var, l2 l2Var) {
        l.f(d2Var, "preferences");
        l.f(g1Var, "logger");
        l.f(l2Var, "timeProvider");
        ConcurrentHashMap<String, a> concurrentHashMap = new ConcurrentHashMap<>();
        this.a = concurrentHashMap;
        c cVar = new c(d2Var);
        this.b = cVar;
        xh.a aVar = xh.a.c;
        concurrentHashMap.put(aVar.a(), new b(cVar, g1Var, l2Var));
        concurrentHashMap.put(aVar.b(), new d(cVar, g1Var, l2Var));
    }

    public final void a(JSONObject jSONObject, List<zh.a> list) {
        l.f(jSONObject, "jsonObject");
        l.f(list, "influences");
        for (zh.a aVar : list) {
            if (e.a[aVar.c().ordinal()] == 1) {
                g().a(jSONObject, aVar);
            }
        }
    }

    public final a b(t2$s t2_s) {
        l.f(t2_s, "entryAction");
        if (t2_s.f()) {
            return g();
        }
        return null;
    }

    public final List<a> c() {
        ArrayList arrayList = new ArrayList();
        arrayList.add(g());
        arrayList.add(e());
        return arrayList;
    }

    public final List<a> d(t2$s t2_s) {
        l.f(t2_s, "entryAction");
        ArrayList arrayList = new ArrayList();
        if (t2_s.d()) {
            return arrayList;
        }
        a aVarG = t2_s.e() ? g() : null;
        if (aVarG != null) {
            arrayList.add(aVarG);
        }
        arrayList.add(e());
        return arrayList;
    }

    public final a e() {
        a aVar = this.a.get(xh.a.c.a());
        l.c(aVar);
        return aVar;
    }

    public final List<zh.a> f() {
        Collection<a> collectionValues = this.a.values();
        l.e(collectionValues, "trackers.values");
        ArrayList arrayList = new ArrayList(n.k(collectionValues, 10));
        Iterator<T> it = collectionValues.iterator();
        while (it.hasNext()) {
            arrayList.add(((a) it.next()).e());
        }
        return arrayList;
    }

    public final a g() {
        a aVar = this.a.get(xh.a.c.b());
        l.c(aVar);
        return aVar;
    }

    public final List<zh.a> h() {
        Collection<a> collectionValues = this.a.values();
        l.e(collectionValues, "trackers.values");
        ArrayList arrayList = new ArrayList();
        for (Object obj : collectionValues) {
            if (!l.a(((a) obj).h(), xh.a.c.a())) {
                arrayList.add(obj);
            }
        }
        ArrayList arrayList2 = new ArrayList(n.k(arrayList, 10));
        Iterator it = arrayList.iterator();
        while (it.hasNext()) {
            arrayList2.add(((a) it.next()).e());
        }
        return arrayList2;
    }

    public final void i() {
        Collection<a> collectionValues = this.a.values();
        l.e(collectionValues, "trackers.values");
        Iterator<T> it = collectionValues.iterator();
        while (it.hasNext()) {
            ((a) it.next()).p();
        }
    }

    public final void j(d3.e eVar) {
        l.f(eVar, "influenceParams");
        this.b.q(eVar);
    }
}
