package yh;

/* JADX INFO: loaded from: /home/kali/Desktop/bunt/agah/dex_files/classes2.dex */
public final /* synthetic */ class e {
    public static final /* synthetic */ int[] a;

    static {
        int[] iArr = new int[zh.b.values().length];
        a = iArr;
        iArr[zh.b.NOTIFICATION.ordinal()] = 1;
        iArr[zh.b.IAM.ordinal()] = 2;
    }
}
