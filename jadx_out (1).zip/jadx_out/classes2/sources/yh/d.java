package yh;

import com.onesignal.g1;
import com.onesignal.l2;
import jl.l;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import wk.p;

/* JADX INFO: compiled from: OSNotificationTracker.kt */
/* JADX INFO: loaded from: /home/kali/Desktop/bunt/agah/dex_files/classes2.dex */
public final class d extends a {
    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public d(c cVar, g1 g1Var, l2 l2Var) {
        super(cVar, g1Var, l2Var);
        l.f(cVar, "dataRepository");
        l.f(g1Var, "logger");
        l.f(l2Var, "timeProvider");
    }

    @Override // yh.a
    public void a(JSONObject jSONObject, zh.a aVar) {
        l.f(jSONObject, "jsonObject");
        l.f(aVar, "influence");
        if (aVar.d().d()) {
            try {
                jSONObject.put("direct", aVar.d().e());
                jSONObject.put("notification_ids", aVar.b());
            } catch (JSONException e) {
                o().e("Generating notification tracker addSessionData JSONObject ", e);
            }
        }
    }

    @Override // yh.a
    public void b() {
        c cVarF = f();
        zh.c cVarK = k();
        if (cVarK == null) {
            cVarK = zh.c.UNATTRIBUTED;
        }
        cVarF.b(cVarK);
        f().c(g());
    }

    @Override // yh.a
    public int c() {
        return f().l();
    }

    @Override // yh.a
    public zh.b d() {
        return zh.b.NOTIFICATION;
    }

    @Override // yh.a
    public String h() {
        return "notification_id";
    }

    @Override // yh.a
    public int i() {
        return f().k();
    }

    @Override // yh.a
    public JSONArray l() {
        return f().i();
    }

    @Override // yh.a
    public JSONArray m(String str) {
        try {
            return l();
        } catch (JSONException e) {
            o().e("Generating Notification tracker getLastChannelObjects JSONObject ", e);
            return new JSONArray();
        }
    }

    @Override // yh.a
    public void p() {
        zh.c cVarJ = f().j();
        if (cVarJ.g()) {
            x(n());
        } else if (cVarJ.e()) {
            w(f().d());
        }
        p pVar = p.a;
        y(cVarJ);
        o().b("OneSignal NotificationTracker initInfluencedTypeFromCache: " + this);
    }

    @Override // yh.a
    public void u(JSONArray jSONArray) {
        l.f(jSONArray, "channelObjects");
        f().r(jSONArray);
    }
}
