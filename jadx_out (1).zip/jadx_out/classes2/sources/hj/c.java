package hj;

import com.warkiz.tickseekbar.TickSeekBar;

/* JADX INFO: compiled from: OnSeekChangeListener.java */
/* JADX INFO: loaded from: /home/kali/Desktop/bunt/agah/dex_files/classes2.dex */
public interface c {
    void a(TickSeekBar tickSeekBar);

    void b(TickSeekBar tickSeekBar);

    void c(e eVar);
}
