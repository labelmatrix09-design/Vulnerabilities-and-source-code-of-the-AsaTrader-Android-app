package hj;

import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;

/* JADX INFO: compiled from: Builder.java */
/* JADX INFO: loaded from: /home/kali/Desktop/bunt/agah/dex_files/classes2.dex */
public class a {
    public int E;
    public final Context a;
    public int j;
    public int l;
    public int q;
    public int x;
    public float b = 100.0f;
    public float c = 0.0f;
    public float d = 0.0f;
    public boolean e = false;
    public boolean f = false;
    public boolean g = false;
    public boolean h = true;
    public boolean i = false;
    public int k = Color.parseColor("#D7D7D7");
    public int m = Color.parseColor("#FF4081");
    public boolean n = false;
    public int o = Color.parseColor("#FF4081");
    public int p = 0;
    public int r = Color.parseColor("#FF4081");
    public boolean s = true;
    public ColorStateList t = null;
    public Drawable u = null;
    public int v = 0;
    public int w = Color.parseColor("#FF4081");
    public String[] y = null;
    public Typeface z = Typeface.DEFAULT;
    public ColorStateList A = null;
    public int B = 0;
    public int C = 0;
    public int D = Color.parseColor("#FF4081");
    public Drawable F = null;
    public boolean G = false;
    public boolean H = false;
    public ColorStateList I = null;
    public boolean J = false;

    public a(Context context) {
        this.a = context;
        this.j = f.a(context, 2.0f);
        this.l = f.a(context, 2.0f);
        this.E = f.a(context, 10.0f);
        this.x = f.b(context, 13.0f);
        this.q = f.a(context, 14.0f);
    }
}
