package hj;

/* JADX INFO: loaded from: /home/kali/Desktop/bunt/agah/dex_files/classes2.dex */
public final class d {
    public static final int[] TickSeekBar = {2130969662, 2130969663, 2130969664, 2130969665, 2130969666, 2130969667, 2130969668, 2130969669, 2130969670, 2130969671, 2130969672, 2130969673, 2130969674, 2130969675, 2130969676, 2130969677, 2130969678, 2130969679, 2130969680, 2130969681, 2130969682, 2130969683, 2130969684, 2130969685, 2130969686, 2130969687, 2130969688, 2130969689, 2130969690, 2130969691, 2130969692, 2130969693};
    public static final int TickSeekBar_tsb_clear_default_padding = 0;
    public static final int TickSeekBar_tsb_max = 1;
    public static final int TickSeekBar_tsb_min = 2;
    public static final int TickSeekBar_tsb_only_thumb_draggable = 3;
    public static final int TickSeekBar_tsb_progress = 4;
    public static final int TickSeekBar_tsb_progress_value_float = 5;
    public static final int TickSeekBar_tsb_r2l = 6;
    public static final int TickSeekBar_tsb_seek_smoothly = 7;
    public static final int TickSeekBar_tsb_show_thumb_text = 8;
    public static final int TickSeekBar_tsb_show_tick_marks_type = 9;
    public static final int TickSeekBar_tsb_show_tick_texts = 10;
    public static final int TickSeekBar_tsb_thumb_adjust_auto = 11;
    public static final int TickSeekBar_tsb_thumb_color = 12;
    public static final int TickSeekBar_tsb_thumb_drawable = 13;
    public static final int TickSeekBar_tsb_thumb_size = 14;
    public static final int TickSeekBar_tsb_thumb_text_color = 15;
    public static final int TickSeekBar_tsb_tick_marks_color = 16;
    public static final int TickSeekBar_tsb_tick_marks_drawable = 17;
    public static final int TickSeekBar_tsb_tick_marks_ends_hide = 18;
    public static final int TickSeekBar_tsb_tick_marks_size = 19;
    public static final int TickSeekBar_tsb_tick_marks_swept_hide = 20;
    public static final int TickSeekBar_tsb_tick_texts_array = 21;
    public static final int TickSeekBar_tsb_tick_texts_color = 22;
    public static final int TickSeekBar_tsb_tick_texts_size = 23;
    public static final int TickSeekBar_tsb_tick_texts_typeface = 24;
    public static final int TickSeekBar_tsb_ticks_count = 25;
    public static final int TickSeekBar_tsb_track_background_color = 26;
    public static final int TickSeekBar_tsb_track_background_size = 27;
    public static final int TickSeekBar_tsb_track_progress_color = 28;
    public static final int TickSeekBar_tsb_track_progress_size = 29;
    public static final int TickSeekBar_tsb_track_rounded_corners = 30;
    public static final int TickSeekBar_tsb_user_seekable = 31;
}
