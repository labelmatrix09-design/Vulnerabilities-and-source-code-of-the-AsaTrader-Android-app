package hj;

import com.warkiz.tickseekbar.TickSeekBar;

/* JADX INFO: compiled from: SeekParams.java */
/* JADX INFO: loaded from: /home/kali/Desktop/bunt/agah/dex_files/classes2.dex */
public class e {
    public TickSeekBar a;
    public int b;
    public float c;
    public boolean d;
    public int e;
    public String f;

    public e(TickSeekBar tickSeekBar) {
        this.a = tickSeekBar;
    }
}
