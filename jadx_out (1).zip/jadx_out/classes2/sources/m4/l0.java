package m4;

import android.view.View;
import com.agah.trader.controller.user.OtpUsersPage;

/* JADX INFO: compiled from: R8$$SyntheticClass */
/* JADX INFO: loaded from: /home/kali/Desktop/bunt/agah/dex_files/classes2.dex */
public final /* synthetic */ class l0 implements View.OnClickListener {
    public final /* synthetic */ OtpUsersPage o;
    public final /* synthetic */ OtpUsersPage.c p;

    public /* synthetic */ l0(OtpUsersPage otpUsersPage, OtpUsersPage.c cVar) {
        this.o = otpUsersPage;
        this.p = cVar;
    }

    @Override // android.view.View.OnClickListener
    public final void onClick(View view) {
        OtpUsersPage.b.a.O(this.o, this.p, view);
    }
}
