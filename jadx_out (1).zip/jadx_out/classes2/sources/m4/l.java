package m4;

import android.view.View;
import com.agah.trader.controller.user.LoginPage;

/* JADX INFO: compiled from: R8$$SyntheticClass */
/* JADX INFO: loaded from: /home/kali/Desktop/bunt/agah/dex_files/classes2.dex */
public final /* synthetic */ class l implements View.OnClickListener {
    public final /* synthetic */ View o;
    public final /* synthetic */ LoginPage p;
    public final /* synthetic */ n4.p q;
    public final /* synthetic */ com.google.android.material.bottomsheet.a r;

    public /* synthetic */ l(View view, LoginPage loginPage, n4.p pVar, com.google.android.material.bottomsheet.a aVar) {
        this.o = view;
        this.p = loginPage;
        this.q = pVar;
        this.r = aVar;
    }

    @Override // android.view.View.OnClickListener
    public final void onClick(View view) {
        LoginPage.L0(this.o, this.p, this.q, this.r, view);
    }
}
