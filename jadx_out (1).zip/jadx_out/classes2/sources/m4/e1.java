package m4;

import com.agah.trader.controller.user.TrustPage;
import java.util.ArrayList;

/* JADX INFO: compiled from: R8$$SyntheticClass */
/* JADX INFO: loaded from: /home/kali/Desktop/bunt/agah/dex_files/classes2.dex */
public final /* synthetic */ class e1 implements androidx.lifecycle.c0 {
    public final /* synthetic */ s7.h a;
    public final /* synthetic */ TrustPage b;

    public /* synthetic */ e1(s7.h hVar, TrustPage trustPage) {
        this.a = hVar;
        this.b = trustPage;
    }

    public final void a(Object obj) {
        TrustPage.M0(this.a, this.b, (ArrayList) obj);
    }
}
