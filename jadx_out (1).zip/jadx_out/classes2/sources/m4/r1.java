package m4;

import com.agah.trader.controller.user.UsersPage;

/* JADX INFO: compiled from: R8$$SyntheticClass */
/* JADX INFO: loaded from: /home/kali/Desktop/bunt/agah/dex_files/classes2.dex */
public final /* synthetic */ class r1 implements Runnable {
    public final /* synthetic */ s7.j o;

    @Override // java.lang.Runnable
    public final void run() {
        UsersPage.Y0(this.o);
    }
}
