package m4;

import android.view.View;
import com.agah.trader.controller.user.UsersPage;

/* JADX INFO: compiled from: R8$$SyntheticClass */
/* JADX INFO: loaded from: /home/kali/Desktop/bunt/agah/dex_files/classes2.dex */
public final /* synthetic */ class f2 implements View.OnClickListener {
    public final /* synthetic */ UsersPage o;
    public final /* synthetic */ String p;

    public /* synthetic */ f2(UsersPage usersPage, String str) {
        this.o = usersPage;
        this.p = str;
    }

    @Override // android.view.View.OnClickListener
    public final void onClick(View view) {
        UsersPage.b.c(this.o, this.p, view);
    }
}
