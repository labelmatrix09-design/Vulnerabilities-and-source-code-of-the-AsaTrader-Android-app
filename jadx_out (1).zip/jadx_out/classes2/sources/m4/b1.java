package m4;

import android.view.View;
import com.agah.trader.controller.user.TrustPage;

/* JADX INFO: compiled from: R8$$SyntheticClass */
/* JADX INFO: loaded from: /home/kali/Desktop/bunt/agah/dex_files/classes2.dex */
public final /* synthetic */ class b1 implements View.OnClickListener {
    public final /* synthetic */ TrustPage o;
    public final /* synthetic */ v4.f2 p;

    public /* synthetic */ b1(TrustPage trustPage, v4.f2 f2Var) {
        this.o = trustPage;
        this.p = f2Var;
    }

    @Override // android.view.View.OnClickListener
    public final void onClick(View view) {
        TrustPage.K0(this.o, this.p, view);
    }
}
