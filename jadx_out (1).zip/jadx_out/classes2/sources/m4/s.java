package m4;

import com.agah.trader.controller.helper.TopSheetBehaviorOld;
import com.agah.trader.controller.user.LoginPage;

/* JADX INFO: compiled from: R8$$SyntheticClass */
/* JADX INFO: loaded from: /home/kali/Desktop/bunt/agah/dex_files/classes2.dex */
public final /* synthetic */ class s implements Runnable {
    public final /* synthetic */ TopSheetBehaviorOld o;

    @Override // java.lang.Runnable
    public final void run() {
        LoginPage.P0(this.o);
    }
}
