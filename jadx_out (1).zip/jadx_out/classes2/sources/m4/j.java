package m4;

import android.widget.Button;

/* JADX INFO: compiled from: R8$$SyntheticClass */
/* JADX INFO: loaded from: /home/kali/Desktop/bunt/agah/dex_files/classes2.dex */
public final /* synthetic */ class j implements Runnable {
    public final /* synthetic */ Button o;
    public final /* synthetic */ s7.b0 p;

    public /* synthetic */ j(Button button, s7.b0 b0Var) {
        this.o = button;
        this.p = b0Var;
    }

    @Override // java.lang.Runnable
    public final void run() {
        k.e(this.o, this.p);
    }
}
