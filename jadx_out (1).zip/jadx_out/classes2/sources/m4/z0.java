package m4;

import android.app.Dialog;
import android.view.View;
import com.agah.trader.controller.user.TrustPage;

/* JADX INFO: compiled from: R8$$SyntheticClass */
/* JADX INFO: loaded from: /home/kali/Desktop/bunt/agah/dex_files/classes2.dex */
public final /* synthetic */ class z0 implements View.OnClickListener {
    public final /* synthetic */ Dialog o;

    @Override // android.view.View.OnClickListener
    public final void onClick(View view) {
        TrustPage.Q0(this.o, view);
    }
}
