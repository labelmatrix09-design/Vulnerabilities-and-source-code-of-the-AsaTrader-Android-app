package m4;

import android.view.View;
import com.agah.trader.controller.user.UsersPage;

/* JADX INFO: compiled from: R8$$SyntheticClass */
/* JADX INFO: loaded from: /home/kali/Desktop/bunt/agah/dex_files/classes2.dex */
public final /* synthetic */ class g1 implements View.OnClickListener {
    public final /* synthetic */ UsersPage o;
    public final /* synthetic */ jl.z p;
    public final /* synthetic */ s7.j q;

    public /* synthetic */ g1(UsersPage usersPage, jl.z zVar, s7.j jVar) {
        this.o = usersPage;
        this.p = zVar;
        this.q = jVar;
    }

    @Override // android.view.View.OnClickListener
    public final void onClick(View view) {
        UsersPage.M0(this.o, this.p, this.q, view);
    }
}
