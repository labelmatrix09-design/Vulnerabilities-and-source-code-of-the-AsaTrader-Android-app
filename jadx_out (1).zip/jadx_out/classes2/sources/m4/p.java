package m4;

import com.agah.trader.controller.user.LoginPage;

/* JADX INFO: compiled from: R8$$SyntheticClass */
/* JADX INFO: loaded from: /home/kali/Desktop/bunt/agah/dex_files/classes2.dex */
public final /* synthetic */ class p implements androidx.lifecycle.c0 {
    public final /* synthetic */ LoginPage a;

    public final void a(Object obj) {
        LoginPage.T0(this.a, (v4.f0) obj);
    }
}
