package m4;

import com.agah.trader.controller.user.LoginPage;

/* JADX INFO: compiled from: R8$$SyntheticClass */
/* JADX INFO: loaded from: /home/kali/Desktop/bunt/agah/dex_files/classes2.dex */
public final /* synthetic */ class q implements androidx.lifecycle.c0 {
    public final /* synthetic */ s7.j0 a;
    public final /* synthetic */ LoginPage b;

    public /* synthetic */ q(s7.j0 j0Var, LoginPage loginPage) {
        this.a = j0Var;
        this.b = loginPage;
    }

    public final void a(Object obj) {
        LoginPage.S0(this.a, this.b, (v4.f0) obj);
    }
}
