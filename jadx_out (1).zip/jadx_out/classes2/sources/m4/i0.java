package m4;

import android.view.View;
import com.agah.trader.controller.user.OtpUsersPage;

/* JADX INFO: compiled from: R8$$SyntheticClass */
/* JADX INFO: loaded from: /home/kali/Desktop/bunt/agah/dex_files/classes2.dex */
public final /* synthetic */ class i0 implements View.OnClickListener {
    public final /* synthetic */ OtpUsersPage o;

    @Override // android.view.View.OnClickListener
    public final void onClick(View view) {
        OtpUsersPage.K0(this.o, view);
    }
}
