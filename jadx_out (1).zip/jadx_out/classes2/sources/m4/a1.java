package m4;

import android.app.Dialog;
import android.view.View;
import com.agah.trader.controller.user.TrustPage;

/* JADX INFO: compiled from: R8$$SyntheticClass */
/* JADX INFO: loaded from: /home/kali/Desktop/bunt/agah/dex_files/classes2.dex */
public final /* synthetic */ class a1 implements View.OnClickListener {
    public final /* synthetic */ TrustPage o;
    public final /* synthetic */ Dialog p;

    public /* synthetic */ a1(TrustPage trustPage, Dialog dialog) {
        this.o = trustPage;
        this.p = dialog;
    }

    @Override // android.view.View.OnClickListener
    public final void onClick(View view) {
        TrustPage.P0(this.o, this.p, view);
    }
}
