package m4;

import android.view.View;

/* JADX INFO: compiled from: R8$$SyntheticClass */
/* JADX INFO: loaded from: /home/kali/Desktop/bunt/agah/dex_files/classes2.dex */
public final /* synthetic */ class w0 implements View.OnClickListener {
    public final /* synthetic */ s7.n o;
    public final /* synthetic */ androidx.fragment.app.h p;

    public /* synthetic */ w0(s7.n nVar, androidx.fragment.app.h hVar) {
        this.o = nVar;
        this.p = hVar;
    }

    @Override // android.view.View.OnClickListener
    public final void onClick(View view) {
        x0.i(this.o, this.p, view);
    }
}
