package m4;

import android.view.View;
import com.agah.trader.controller.user.UsersPage;

/* JADX INFO: compiled from: R8$$SyntheticClass */
/* JADX INFO: loaded from: /home/kali/Desktop/bunt/agah/dex_files/classes2.dex */
public final /* synthetic */ class h2 implements View.OnClickListener {
    public final /* synthetic */ String o;
    public final /* synthetic */ UsersPage p;

    public /* synthetic */ h2(String str, UsersPage usersPage) {
        this.o = str;
        this.p = usersPage;
    }

    @Override // android.view.View.OnClickListener
    public final void onClick(View view) {
        UsersPage.b.b(this.o, this.p, view);
    }
}
