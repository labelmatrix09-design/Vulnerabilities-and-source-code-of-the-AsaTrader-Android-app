package m4;

import com.agah.trader.controller.user.UsersPage;

/* JADX INFO: compiled from: R8$$SyntheticClass */
/* JADX INFO: loaded from: /home/kali/Desktop/bunt/agah/dex_files/classes2.dex */
public final /* synthetic */ class t1 implements Runnable {
    public final /* synthetic */ s7.o o;
    public final /* synthetic */ s7.b0 p;

    public /* synthetic */ t1(s7.o oVar, s7.b0 b0Var) {
        this.o = oVar;
        this.p = b0Var;
    }

    @Override // java.lang.Runnable
    public final void run() {
        UsersPage.U0(this.o, this.p);
    }
}
