package m4;

import android.view.View;
import com.agah.trader.controller.user.LoginPage;

/* JADX INFO: compiled from: R8$$SyntheticClass */
/* JADX INFO: loaded from: /home/kali/Desktop/bunt/agah/dex_files/classes2.dex */
public final /* synthetic */ class o implements View.OnClickListener {
    public final /* synthetic */ il.a o;

    @Override // android.view.View.OnClickListener
    public final void onClick(View view) {
        LoginPage.U0(this.o, view);
    }
}
