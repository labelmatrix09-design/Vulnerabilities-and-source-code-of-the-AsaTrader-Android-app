package m4;

import com.agah.trader.controller.user.LoginPage;

/* JADX INFO: compiled from: R8$$SyntheticClass */
/* JADX INFO: loaded from: /home/kali/Desktop/bunt/agah/dex_files/classes2.dex */
public final /* synthetic */ class t implements tj.g {
    public final /* synthetic */ LoginPage a;

    @Override // tj.g
    public final void a(tj.f fVar) {
        LoginPage.O0(this.a, fVar);
    }
}
