package m4;

import com.agah.trader.controller.user.UsersPage;

/* JADX INFO: compiled from: R8$$SyntheticClass */
/* JADX INFO: loaded from: /home/kali/Desktop/bunt/agah/dex_files/classes2.dex */
public final /* synthetic */ class o1 implements Runnable {
    public final /* synthetic */ UsersPage o;
    public final /* synthetic */ String p;

    public /* synthetic */ o1(UsersPage usersPage, String str) {
        this.o = usersPage;
        this.p = str;
    }

    @Override // java.lang.Runnable
    public final void run() {
        UsersPage.L0(this.o, this.p);
    }
}
