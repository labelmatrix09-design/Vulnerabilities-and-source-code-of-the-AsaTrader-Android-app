package m4;

import android.view.View;
import com.agah.trader.controller.user.TrustPage;

/* JADX INFO: compiled from: R8$$SyntheticClass */
/* JADX INFO: loaded from: /home/kali/Desktop/bunt/agah/dex_files/classes2.dex */
public final /* synthetic */ class c1 implements View.OnClickListener {
    public final /* synthetic */ boolean o;
    public final /* synthetic */ TrustPage p;
    public final /* synthetic */ s7.h q;

    public /* synthetic */ c1(boolean z, TrustPage trustPage, s7.h hVar) {
        this.o = z;
        this.p = trustPage;
        this.q = hVar;
    }

    @Override // android.view.View.OnClickListener
    public final void onClick(View view) {
        TrustPage.N0(this.o, this.p, this.q, view);
    }
}
