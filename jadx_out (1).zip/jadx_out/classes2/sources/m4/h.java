package m4;

import android.app.Dialog;
import android.view.View;

/* JADX INFO: compiled from: R8$$SyntheticClass */
/* JADX INFO: loaded from: /home/kali/Desktop/bunt/agah/dex_files/classes2.dex */
public final /* synthetic */ class h implements View.OnClickListener {
    public final /* synthetic */ s7.q o;
    public final /* synthetic */ String p;
    public final /* synthetic */ il.a q;
    public final /* synthetic */ Dialog r;
    public final /* synthetic */ k.a s;

    public /* synthetic */ h(s7.q qVar, String str, il.a aVar, Dialog dialog, k.a aVar2) {
        this.o = qVar;
        this.p = str;
        this.q = aVar;
        this.r = dialog;
        this.s = aVar2;
    }

    @Override // android.view.View.OnClickListener
    public final void onClick(View view) {
        k.f(this.o, this.p, this.q, this.r, this.s, view);
    }
}
