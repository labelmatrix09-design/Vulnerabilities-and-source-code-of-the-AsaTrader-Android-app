package m4;

import com.agah.trader.controller.user.UsersPage;

/* JADX INFO: compiled from: R8$$SyntheticClass */
/* JADX INFO: loaded from: /home/kali/Desktop/bunt/agah/dex_files/classes2.dex */
public final /* synthetic */ class p1 implements Runnable {
    public final /* synthetic */ String o;
    public final /* synthetic */ UsersPage p;

    public /* synthetic */ p1(String str, UsersPage usersPage) {
        this.o = str;
        this.p = usersPage;
    }

    @Override // java.lang.Runnable
    public final void run() {
        UsersPage.e1(this.o, this.p);
    }
}
