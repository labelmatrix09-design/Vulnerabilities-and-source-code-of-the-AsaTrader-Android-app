package m4;

import com.agah.trader.controller.user.LoginPage;
import com.google.android.material.appbar.AppBarLayout;

/* JADX INFO: compiled from: R8$$SyntheticClass */
/* JADX INFO: loaded from: /home/kali/Desktop/bunt/agah/dex_files/classes2.dex */
public final /* synthetic */ class r implements AppBarLayout.e {
    public final /* synthetic */ tj.f a;

    public final void a(AppBarLayout appBarLayout, int i) {
        LoginPage.Q0(this.a, appBarLayout, i);
    }
}
