package m4;

import android.app.Dialog;
import android.view.View;
import com.agah.trader.controller.user.UsersPage;

/* JADX INFO: compiled from: R8$$SyntheticClass */
/* JADX INFO: loaded from: /home/kali/Desktop/bunt/agah/dex_files/classes2.dex */
public final /* synthetic */ class m1 implements View.OnClickListener {
    public final /* synthetic */ s7.j o;
    public final /* synthetic */ String p;
    public final /* synthetic */ UsersPage q;
    public final /* synthetic */ jl.z r;
    public final /* synthetic */ Dialog s;

    public /* synthetic */ m1(s7.j jVar, String str, UsersPage usersPage, jl.z zVar, Dialog dialog) {
        this.o = jVar;
        this.p = str;
        this.q = usersPage;
        this.r = zVar;
        this.s = dialog;
    }

    @Override // android.view.View.OnClickListener
    public final void onClick(View view) {
        UsersPage.K0(this.o, this.p, this.q, this.r, this.s, view);
    }
}
