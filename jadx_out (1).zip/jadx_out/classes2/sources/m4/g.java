package m4;

import android.app.Dialog;
import android.view.View;

/* JADX INFO: compiled from: R8$$SyntheticClass */
/* JADX INFO: loaded from: /home/kali/Desktop/bunt/agah/dex_files/classes2.dex */
public final /* synthetic */ class g implements View.OnClickListener {
    public final /* synthetic */ s7.l o;
    public final /* synthetic */ String p;
    public final /* synthetic */ Dialog q;

    public /* synthetic */ g(s7.l lVar, String str, Dialog dialog) {
        this.o = lVar;
        this.p = str;
        this.q = dialog;
    }

    @Override // android.view.View.OnClickListener
    public final void onClick(View view) {
        k.b(this.o, this.p, this.q, view);
    }
}
