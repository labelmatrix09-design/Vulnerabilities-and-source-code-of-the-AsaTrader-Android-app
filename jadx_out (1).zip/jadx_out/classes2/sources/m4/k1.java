package m4;

import android.view.View;
import com.agah.trader.controller.user.UsersPage;

/* JADX INFO: compiled from: R8$$SyntheticClass */
/* JADX INFO: loaded from: /home/kali/Desktop/bunt/agah/dex_files/classes2.dex */
public final /* synthetic */ class k1 implements View.OnClickListener {
    public final /* synthetic */ jl.z o;
    public final /* synthetic */ s7.b0 p;
    public final /* synthetic */ il.p q;
    public final /* synthetic */ il.a r;

    public /* synthetic */ k1(jl.z zVar, s7.b0 b0Var, il.p pVar, il.a aVar) {
        this.o = zVar;
        this.p = b0Var;
        this.q = pVar;
        this.r = aVar;
    }

    @Override // android.view.View.OnClickListener
    public final void onClick(View view) {
        UsersPage.R0(this.o, this.p, this.q, this.r, view);
    }
}
