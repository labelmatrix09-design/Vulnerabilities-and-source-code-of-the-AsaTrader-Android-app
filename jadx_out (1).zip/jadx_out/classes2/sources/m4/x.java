package m4;

import android.view.View;

/* JADX INFO: compiled from: R8$$SyntheticClass */
/* JADX INFO: loaded from: /home/kali/Desktop/bunt/agah/dex_files/classes2.dex */
public final /* synthetic */ class x implements View.OnClickListener {
    public final /* synthetic */ a0 o;

    @Override // android.view.View.OnClickListener
    public final void onClick(View view) {
        a0.i2(this.o, view);
    }
}
