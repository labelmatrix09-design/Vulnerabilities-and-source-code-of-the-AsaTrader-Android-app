package m4;

import android.app.Activity;
import android.view.View;

/* JADX INFO: compiled from: R8$$SyntheticClass */
/* JADX INFO: loaded from: /home/kali/Desktop/bunt/agah/dex_files/classes2.dex */
public final /* synthetic */ class o0 implements View.OnClickListener {
    public final /* synthetic */ Activity o;

    @Override // android.view.View.OnClickListener
    public final void onClick(View view) {
        x0.f(this.o, view);
    }
}
