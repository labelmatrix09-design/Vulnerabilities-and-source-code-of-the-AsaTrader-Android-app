package m4;

import android.content.DialogInterface;

/* JADX INFO: compiled from: R8$$SyntheticClass */
/* JADX INFO: loaded from: /home/kali/Desktop/bunt/agah/dex_files/classes2.dex */
public final /* synthetic */ class c implements DialogInterface.OnDismissListener {
    public final /* synthetic */ k.a o;

    @Override // android.content.DialogInterface.OnDismissListener
    public final void onDismiss(DialogInterface dialogInterface) {
        k.g(this.o, dialogInterface);
    }
}
