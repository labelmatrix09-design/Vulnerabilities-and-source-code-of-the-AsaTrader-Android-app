package m4;

import android.app.Dialog;
import android.view.View;
import com.agah.trader.controller.user.UsersPage;

/* JADX INFO: compiled from: R8$$SyntheticClass */
/* JADX INFO: loaded from: /home/kali/Desktop/bunt/agah/dex_files/classes2.dex */
public final /* synthetic */ class y1 implements View.OnClickListener {
    public final /* synthetic */ Dialog o;

    @Override // android.view.View.OnClickListener
    public final void onClick(View view) {
        UsersPage.i1(this.o, view);
    }
}
