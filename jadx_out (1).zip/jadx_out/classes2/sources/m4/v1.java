package m4;

import com.agah.trader.controller.user.UsersPage;

/* JADX INFO: compiled from: R8$$SyntheticClass */
/* JADX INFO: loaded from: /home/kali/Desktop/bunt/agah/dex_files/classes2.dex */
public final /* synthetic */ class v1 implements Runnable {
    public final /* synthetic */ s7.r o;
    public final /* synthetic */ s7.b0 p;

    public /* synthetic */ v1(s7.r rVar, s7.b0 b0Var) {
        this.o = rVar;
        this.p = b0Var;
    }

    @Override // java.lang.Runnable
    public final void run() {
        UsersPage.P0(this.o, this.p);
    }
}
