package m4;

import android.view.View;
import com.agah.trader.controller.user.UsersPage;

/* JADX INFO: compiled from: R8$$SyntheticClass */
/* JADX INFO: loaded from: /home/kali/Desktop/bunt/agah/dex_files/classes2.dex */
public final /* synthetic */ class i1 implements View.OnClickListener {
    public final /* synthetic */ UsersPage o;
    public final /* synthetic */ s7.b0 p;
    public final /* synthetic */ jl.z q;

    public /* synthetic */ i1(UsersPage usersPage, s7.b0 b0Var, jl.z zVar) {
        this.o = usersPage;
        this.p = b0Var;
        this.q = zVar;
    }

    @Override // android.view.View.OnClickListener
    public final void onClick(View view) {
        UsersPage.T0(this.o, this.p, this.q, view);
    }
}
