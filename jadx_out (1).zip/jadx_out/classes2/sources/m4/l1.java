package m4;

import android.app.Dialog;
import android.view.View;
import com.agah.trader.controller.user.UsersPage;

/* JADX INFO: compiled from: R8$$SyntheticClass */
/* JADX INFO: loaded from: /home/kali/Desktop/bunt/agah/dex_files/classes2.dex */
public final /* synthetic */ class l1 implements View.OnClickListener {
    public final /* synthetic */ s7.j o;
    public final /* synthetic */ UsersPage p;
    public final /* synthetic */ Dialog q;
    public final /* synthetic */ v4.f0 r;
    public final /* synthetic */ jl.z s;

    public /* synthetic */ l1(s7.j jVar, UsersPage usersPage, Dialog dialog, v4.f0 f0Var, jl.z zVar) {
        this.o = jVar;
        this.p = usersPage;
        this.q = dialog;
        this.r = f0Var;
        this.s = zVar;
    }

    @Override // android.view.View.OnClickListener
    public final void onClick(View view) {
        UsersPage.Z0(this.o, this.p, this.q, this.r, this.s, view);
    }
}
