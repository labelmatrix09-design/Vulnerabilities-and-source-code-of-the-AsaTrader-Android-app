package m4;

import android.view.View;
import com.agah.trader.controller.user.ForeignConnectionPage;

/* JADX INFO: compiled from: R8$$SyntheticClass */
/* JADX INFO: loaded from: /home/kali/Desktop/bunt/agah/dex_files/classes2.dex */
public final /* synthetic */ class b implements View.OnClickListener {
    public final /* synthetic */ ForeignConnectionPage o;

    @Override // android.view.View.OnClickListener
    public final void onClick(View view) {
        ForeignConnectionPage.K0(this.o, view);
    }
}
