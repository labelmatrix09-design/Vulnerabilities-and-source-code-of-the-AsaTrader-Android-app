package m4;

import com.agah.trader.controller.user.LoginPage;

/* JADX INFO: compiled from: R8$$SyntheticClass */
/* JADX INFO: loaded from: /home/kali/Desktop/bunt/agah/dex_files/classes2.dex */
public final /* synthetic */ class u implements wj.e {
    public final /* synthetic */ LoginPage a;

    @Override // wj.e
    public final void a(Object obj) {
        LoginPage.R0(this.a, (Float) obj);
    }
}
