package m4;

import android.view.View;

/* JADX INFO: compiled from: R8$$SyntheticClass */
/* JADX INFO: loaded from: /home/kali/Desktop/bunt/agah/dex_files/classes2.dex */
public final /* synthetic */ class f implements View.OnClickListener {
    public final /* synthetic */ k.a o;
    public final /* synthetic */ String p;
    public final /* synthetic */ s7.l q;
    public final /* synthetic */ jl.y r;

    public /* synthetic */ f(k.a aVar, String str, s7.l lVar, jl.y yVar) {
        this.o = aVar;
        this.p = str;
        this.q = lVar;
        this.r = yVar;
    }

    @Override // android.view.View.OnClickListener
    public final void onClick(View view) {
        k.c(this.o, this.p, this.q, this.r, view);
    }
}
