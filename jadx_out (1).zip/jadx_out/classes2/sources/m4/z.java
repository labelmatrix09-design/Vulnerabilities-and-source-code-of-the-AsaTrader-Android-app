package m4;

/* JADX INFO: compiled from: R8$$SyntheticClass */
/* JADX INFO: loaded from: /home/kali/Desktop/bunt/agah/dex_files/classes2.dex */
public final /* synthetic */ class z implements androidx.lifecycle.c0 {
    public final /* synthetic */ a0 a;

    public final void a(Object obj) {
        a0.f2(this.a, (Long) obj);
    }
}
