package m4;

import android.app.Dialog;
import android.view.View;
import com.agah.trader.controller.user.UsersPage;

/* JADX INFO: compiled from: R8$$SyntheticClass */
/* JADX INFO: loaded from: /home/kali/Desktop/bunt/agah/dex_files/classes2.dex */
public final /* synthetic */ class n1 implements View.OnClickListener {
    public final /* synthetic */ s7.o o;
    public final /* synthetic */ jl.z p;
    public final /* synthetic */ UsersPage q;
    public final /* synthetic */ String r;
    public final /* synthetic */ Dialog s;

    public /* synthetic */ n1(s7.o oVar, jl.z zVar, UsersPage usersPage, String str, Dialog dialog) {
        this.o = oVar;
        this.p = zVar;
        this.q = usersPage;
        this.r = str;
        this.s = dialog;
    }

    @Override // android.view.View.OnClickListener
    public final void onClick(View view) {
        UsersPage.W0(this.o, this.p, this.q, this.r, this.s, view);
    }
}
