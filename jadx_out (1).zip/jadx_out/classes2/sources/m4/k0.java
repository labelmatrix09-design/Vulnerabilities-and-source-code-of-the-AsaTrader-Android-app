package m4;

import com.agah.trader.controller.user.OtpUsersPage;

/* JADX INFO: compiled from: R8$$SyntheticClass */
/* JADX INFO: loaded from: /home/kali/Desktop/bunt/agah/dex_files/classes2.dex */
public final /* synthetic */ class k0 implements Runnable {
    public final /* synthetic */ OtpUsersPage o;
    public final /* synthetic */ int p;

    public /* synthetic */ k0(OtpUsersPage otpUsersPage, int i) {
        this.o = otpUsersPage;
        this.p = i;
    }

    @Override // java.lang.Runnable
    public final void run() {
        OtpUsersPage.L0(this.o, this.p);
    }
}
