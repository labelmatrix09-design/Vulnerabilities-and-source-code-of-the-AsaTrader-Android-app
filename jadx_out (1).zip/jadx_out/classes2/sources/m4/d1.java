package m4;

import com.agah.trader.controller.user.TrustPage;

/* JADX INFO: compiled from: R8$$SyntheticClass */
/* JADX INFO: loaded from: /home/kali/Desktop/bunt/agah/dex_files/classes2.dex */
public final /* synthetic */ class d1 implements androidx.lifecycle.c0 {
    public final /* synthetic */ s7.h a;
    public final /* synthetic */ TrustPage b;

    public /* synthetic */ d1(s7.h hVar, TrustPage trustPage) {
        this.a = hVar;
        this.b = trustPage;
    }

    public final void a(Object obj) {
        TrustPage.L0(this.a, this.b, (String) obj);
    }
}
