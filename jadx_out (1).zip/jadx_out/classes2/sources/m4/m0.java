package m4;

import com.agah.trader.controller.user.OtpUsersPage;

/* JADX INFO: compiled from: R8$$SyntheticClass */
/* JADX INFO: loaded from: /home/kali/Desktop/bunt/agah/dex_files/classes2.dex */
public final /* synthetic */ class m0 implements Runnable {
    public final /* synthetic */ OtpUsersPage o;

    @Override // java.lang.Runnable
    public final void run() {
        OtpUsersPage.d.a(this.o);
    }
}
