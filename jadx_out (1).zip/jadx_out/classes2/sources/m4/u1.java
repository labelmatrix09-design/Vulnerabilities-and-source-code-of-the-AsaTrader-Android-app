package m4;

import android.app.Dialog;
import com.agah.trader.controller.user.UsersPage;

/* JADX INFO: compiled from: R8$$SyntheticClass */
/* JADX INFO: loaded from: /home/kali/Desktop/bunt/agah/dex_files/classes2.dex */
public final /* synthetic */ class u1 implements Runnable {
    public final /* synthetic */ s7.p o;
    public final /* synthetic */ UsersPage p;
    public final /* synthetic */ Dialog q;
    public final /* synthetic */ String r;

    public /* synthetic */ u1(s7.p pVar, UsersPage usersPage, Dialog dialog, String str) {
        this.o = pVar;
        this.p = usersPage;
        this.q = dialog;
        this.r = str;
    }

    @Override // java.lang.Runnable
    public final void run() {
        UsersPage.f1(this.o, this.p, this.q, this.r);
    }
}
