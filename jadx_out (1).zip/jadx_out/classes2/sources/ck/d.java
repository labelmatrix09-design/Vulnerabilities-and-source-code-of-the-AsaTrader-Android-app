package ck;

import tj.i;
import wj.e;

/* JADX INFO: compiled from: ObservableDoOnLifecycle.java */
/* JADX INFO: loaded from: /home/kali/Desktop/bunt/agah/dex_files/classes2.dex */
public final class d<T> extends a<T, T> {
    public final e<? super uj.a> p;
    public final wj.a q;

    public d(tj.e<T> eVar, e<? super uj.a> eVar2, wj.a aVar) {
        super(eVar);
        this.p = eVar2;
        this.q = aVar;
    }

    @Override // tj.e
    public void p(i<? super T> iVar) {
        this.o.e(new ak.d(iVar, this.p, this.q));
    }
}
