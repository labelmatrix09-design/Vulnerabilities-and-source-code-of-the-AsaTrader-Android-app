package ck;

import java.util.concurrent.atomic.AtomicReference;
import tj.e;
import tj.f;
import tj.g;
import tj.i;

/* JADX INFO: compiled from: ObservableCreate.java */
/* JADX INFO: loaded from: /home/kali/Desktop/bunt/agah/dex_files/classes2.dex */
public final class b<T> extends e<T> {
    public final g<T> o;

    /* JADX INFO: compiled from: ObservableCreate.java */
    public static final class a<T> extends AtomicReference<uj.a> implements f<T>, uj.a {
        public final i<? super T> o;

        public a(i<? super T> iVar) {
            this.o = iVar;
        }

        public boolean a() {
            return xj.a.f(get());
        }

        public void b(Throwable th2) {
            if (c(th2)) {
                return;
            }
            fk.a.i(th2);
        }

        public boolean c(Throwable th2) {
            if (th2 == null) {
                th2 = new NullPointerException("onError called with null. Null values are generally not allowed in 2.x operators and sources.");
            }
            if (a()) {
                return false;
            }
            try {
                this.o.b(th2);
                return true;
            } finally {
                e();
            }
        }

        @Override // tj.d
        public void d(T t) {
            if (t == null) {
                b(new NullPointerException("onNext called with null. Null values are generally not allowed in 2.x operators and sources."));
            } else {
                if (a()) {
                    return;
                }
                this.o.d(t);
            }
        }

        @Override // uj.a
        public void e() {
            xj.a.d(this);
        }

        @Override // java.util.concurrent.atomic.AtomicReference
        public String toString() {
            return String.format("%s{%s}", a.class.getSimpleName(), super.toString());
        }
    }

    public b(g<T> gVar) {
        this.o = gVar;
    }

    @Override // tj.e
    public void p(i<? super T> iVar) {
        a aVar = new a(iVar);
        iVar.c(aVar);
        try {
            this.o.a(aVar);
        } catch (Throwable th2) {
            vj.a.a(th2);
            aVar.b(th2);
        }
    }
}
