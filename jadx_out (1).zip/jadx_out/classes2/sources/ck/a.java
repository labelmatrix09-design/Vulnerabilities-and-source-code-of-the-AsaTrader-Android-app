package ck;

import tj.e;
import tj.h;

/* JADX INFO: compiled from: AbstractObservableWithUpstream.java */
/* JADX INFO: loaded from: /home/kali/Desktop/bunt/agah/dex_files/classes2.dex */
public abstract class a<T, U> extends e<U> {
    public final h<T> o;

    public a(h<T> hVar) {
        this.o = hVar;
    }
}
