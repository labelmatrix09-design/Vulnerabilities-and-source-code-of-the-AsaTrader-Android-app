package ck;

import tj.h;
import tj.i;
import wj.f;

/* JADX INFO: compiled from: ObservableDistinctUntilChanged.java */
/* JADX INFO: loaded from: /home/kali/Desktop/bunt/agah/dex_files/classes2.dex */
public final class c<T, K> extends ck.a<T, T> {
    public final f<? super T, K> p;
    public final wj.c<? super K, ? super K> q;

    /* JADX INFO: compiled from: ObservableDistinctUntilChanged.java */
    public static final class a<T, K> extends ak.a<T, T> {
        public final f<? super T, K> t;
        public final wj.c<? super K, ? super K> u;
        public K v;
        public boolean w;

        public a(i<? super T> iVar, f<? super T, K> fVar, wj.c<? super K, ? super K> cVar) {
            super(iVar);
            this.t = fVar;
            this.u = cVar;
        }

        /* JADX WARN: Type inference incomplete: some casts might be missing */
        @Override // tj.i
        public void d(T t) {
            if (this.r) {
                return;
            }
            if (this.s != 0) {
                this.o.d((Object) t);
                return;
            }
            try {
                K kApply = this.t.apply(t);
                if (this.w) {
                    boolean zA = this.u.a(this.v, kApply);
                    this.v = kApply;
                    if (zA) {
                        return;
                    }
                } else {
                    this.w = true;
                    this.v = kApply;
                }
                this.o.d((Object) t);
            } catch (Throwable th2) {
                h(th2);
            }
        }
    }

    public c(h<T> hVar, f<? super T, K> fVar, wj.c<? super K, ? super K> cVar) {
        super(hVar);
        this.p = fVar;
        this.q = cVar;
    }

    @Override // tj.e
    public void p(i<? super T> iVar) {
        this.o.e(new a(iVar, this.p, this.q));
    }
}
