package mg;

import com.google.zxing.FormatException;
import com.google.zxing.common.reedsolomon.ReedSolomonException;
import io.github.inflationx.calligraphy3.BuildConfig;
import java.util.Arrays;
import rg.e;
import tg.c;

/* JADX INFO: compiled from: Decoder.java */
/* JADX INFO: loaded from: /home/kali/Desktop/bunt/agah/dex_files/classes2.dex */
public final class a {
    public static final String[] b = {"CTRL_PS", " ", "A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O", "P", "Q", "R", "S", "T", "U", "V", "W", "X", "Y", "Z", "CTRL_LL", "CTRL_ML", "CTRL_DL", "CTRL_BS"};
    public static final String[] c = {"CTRL_PS", " ", "a", "b", "c", "d", "e", "f", "g", "h", "i", "j", "k", "l", "m", "n", "o", "p", "q", "r", "s", "t", "u", "v", "w", "x", "y", "z", "CTRL_US", "CTRL_ML", "CTRL_DL", "CTRL_BS"};
    public static final String[] d = {"CTRL_PS", " ", "\u0001", "\u0002", "\u0003", "\u0004", "\u0005", "\u0006", "\u0007", "\b", "\t", "\n", "\u000b", "\f", "\r", "\u001b", "\u001c", "\u001d", "\u001e", "\u001f", "@", "\\", "^", "_", "`", "|", "~", "\u007f", "CTRL_LL", "CTRL_UL", "CTRL_PL", "CTRL_BS"};
    public static final String[] e = {BuildConfig.FLAVOR, "\r", "\r\n", ". ", ", ", ": ", "!", "\"", "#", "$", "%", "&", "'", "(", ")", "*", "+", ",", "-", ".", "/", ":", ";", "<", "=", ">", "?", "[", "]", "{", "}", "CTRL_UL"};
    public static final String[] f = {"CTRL_PS", " ", "0", "1", "2", "3", "4", "5", "6", "7", "8", "9", ",", ".", "CTRL_UL", "CTRL_US"};
    public lg.a a;

    /* JADX INFO: renamed from: mg.a$a, reason: collision with other inner class name */
    /* JADX INFO: compiled from: Decoder.java */
    public static /* synthetic */ class C0064a {
        public static final /* synthetic */ int[] a;

        static {
            int[] iArr = new int[b.values().length];
            a = iArr;
            try {
                iArr[b.UPPER.ordinal()] = 1;
            } catch (NoSuchFieldError unused) {
            }
            try {
                a[b.LOWER.ordinal()] = 2;
            } catch (NoSuchFieldError unused2) {
            }
            try {
                a[b.MIXED.ordinal()] = 3;
            } catch (NoSuchFieldError unused3) {
            }
            try {
                a[b.PUNCT.ordinal()] = 4;
            } catch (NoSuchFieldError unused4) {
            }
            try {
                a[b.DIGIT.ordinal()] = 5;
            } catch (NoSuchFieldError unused5) {
            }
        }
    }

    /* JADX INFO: compiled from: Decoder.java */
    public enum b {
        UPPER,
        LOWER,
        MIXED,
        DIGIT,
        PUNCT,
        BINARY
    }

    public static byte[] a(boolean[] zArr) {
        int length = (zArr.length + 7) / 8;
        byte[] bArr = new byte[length];
        for (int i = 0; i < length; i++) {
            bArr[i] = h(zArr, i << 3);
        }
        return bArr;
    }

    public static String e(b bVar, int i) {
        int i3 = C0064a.a[bVar.ordinal()];
        if (i3 == 1) {
            return b[i];
        }
        if (i3 == 2) {
            return c[i];
        }
        if (i3 == 3) {
            return d[i];
        }
        if (i3 == 4) {
            return e[i];
        }
        if (i3 == 5) {
            return f[i];
        }
        throw new IllegalStateException("Bad table");
    }

    public static String f(boolean[] zArr) {
        int length = zArr.length;
        b bVar = b.UPPER;
        StringBuilder sb = new StringBuilder(20);
        b bVarG = bVar;
        int i = 0;
        while (i < length) {
            if (bVar != b.BINARY) {
                int i3 = bVar == b.DIGIT ? 4 : 5;
                if (length - i < i3) {
                    break;
                }
                int i5 = i(zArr, i, i3);
                i += i3;
                String strE = e(bVar, i5);
                if (strE.startsWith("CTRL_")) {
                    bVarG = g(strE.charAt(5));
                    if (strE.charAt(6) != 'L') {
                        bVarG = bVar;
                        bVar = bVarG;
                    }
                } else {
                    sb.append(strE);
                }
                bVar = bVarG;
            } else {
                if (length - i < 5) {
                    break;
                }
                int i6 = i(zArr, i, 5);
                i += 5;
                if (i6 == 0) {
                    if (length - i < 11) {
                        break;
                    }
                    i6 = i(zArr, i, 11) + 31;
                    i += 11;
                }
                for (int i7 = 0; i7 < i6; i7++) {
                    if (length - i < 8) {
                        i = length;
                        break;
                    }
                    sb.append((char) i(zArr, i, 8));
                    i += 8;
                }
                bVar = bVarG;
            }
        }
        return sb.toString();
    }

    public static b g(char c2) {
        if (c2 == 'B') {
            return b.BINARY;
        }
        if (c2 == 'D') {
            return b.DIGIT;
        }
        if (c2 == 'P') {
            return b.PUNCT;
        }
        if (c2 != 'L') {
            return c2 != 'M' ? b.UPPER : b.MIXED;
        }
        return b.LOWER;
    }

    public static byte h(boolean[] zArr, int i) {
        int length = zArr.length - i;
        return (byte) (length >= 8 ? i(zArr, i, 8) : i(zArr, i, length) << (8 - length));
    }

    public static int i(boolean[] zArr, int i, int i3) {
        int i5 = 0;
        for (int i6 = i; i6 < i + i3; i6++) {
            i5 <<= 1;
            if (zArr[i6]) {
                i5 |= 1;
            }
        }
        return i5;
    }

    public static int j(int i, boolean z) {
        return ((z ? 88 : 112) + (i << 4)) * i;
    }

    public final boolean[] b(boolean[] zArr) throws FormatException {
        tg.a aVar;
        int i = 8;
        if (this.a.d() <= 2) {
            i = 6;
            aVar = tg.a.j;
        } else if (this.a.d() <= 8) {
            aVar = tg.a.n;
        } else if (this.a.d() <= 22) {
            i = 10;
            aVar = tg.a.i;
        } else {
            i = 12;
            aVar = tg.a.h;
        }
        int iC = this.a.c();
        int length = zArr.length / i;
        if (length < iC) {
            throw FormatException.a();
        }
        int length2 = zArr.length % i;
        int[] iArr = new int[length];
        int i3 = 0;
        while (i3 < length) {
            iArr[i3] = i(zArr, length2, i);
            i3++;
            length2 += i;
        }
        try {
            new c(aVar).a(iArr, length - iC);
            int i5 = (1 << i) - 1;
            int i6 = 0;
            for (int i7 = 0; i7 < iC; i7++) {
                int i8 = iArr[i7];
                if (i8 == 0 || i8 == i5) {
                    throw FormatException.a();
                }
                if (i8 == 1 || i8 == i5 - 1) {
                    i6++;
                }
            }
            boolean[] zArr2 = new boolean[(iC * i) - i6];
            int i9 = 0;
            for (int i10 = 0; i10 < iC; i10++) {
                int i11 = iArr[i10];
                if (i11 == 1 || i11 == i5 - 1) {
                    Arrays.fill(zArr2, i9, (i9 + i) - 1, i11 > 1);
                    i9 += i - 1;
                } else {
                    int i12 = i - 1;
                    while (i12 >= 0) {
                        int i13 = i9 + 1;
                        zArr2[i9] = ((1 << i12) & i11) != 0;
                        i12--;
                        i9 = i13;
                    }
                }
            }
            return zArr2;
        } catch (ReedSolomonException e2) {
            throw FormatException.b(e2);
        }
    }

    public e c(lg.a aVar) throws FormatException {
        this.a = aVar;
        boolean[] zArrB = b(d(aVar.a()));
        e eVar = new e(a(zArrB), f(zArrB), null, null);
        eVar.l(zArrB.length);
        return eVar;
    }

    public final boolean[] d(rg.b bVar) {
        boolean zE = this.a.e();
        int iD = this.a.d();
        int i = (zE ? 11 : 14) + (iD << 2);
        int[] iArr = new int[i];
        boolean[] zArr = new boolean[j(iD, zE)];
        int i3 = 2;
        if (zE) {
            for (int i5 = 0; i5 < i; i5++) {
                iArr[i5] = i5;
            }
        } else {
            int i6 = i / 2;
            int i7 = ((i + 1) + (((i6 - 1) / 15) * 2)) / 2;
            for (int i8 = 0; i8 < i6; i8++) {
                int i9 = (i8 / 15) + i8;
                iArr[(i6 - i8) - 1] = (i7 - i9) - 1;
                iArr[i6 + i8] = i9 + i7 + 1;
            }
        }
        int i10 = 0;
        int i11 = 0;
        while (i10 < iD) {
            int i12 = ((iD - i10) << i3) + (zE ? 9 : 12);
            int i13 = i10 << 1;
            int i14 = (i - 1) - i13;
            int i15 = 0;
            while (i15 < i12) {
                int i16 = i15 << 1;
                int i17 = 0;
                while (i17 < i3) {
                    int i18 = i13 + i17;
                    int i19 = i13 + i15;
                    zArr[i11 + i16 + i17] = bVar.d(iArr[i18], iArr[i19]);
                    int i20 = iArr[i19];
                    int i21 = i14 - i17;
                    zArr[(i12 * 2) + i11 + i16 + i17] = bVar.d(i20, iArr[i21]);
                    int i22 = i14 - i15;
                    zArr[(i12 * 4) + i11 + i16 + i17] = bVar.d(iArr[i21], iArr[i22]);
                    zArr[(i12 * 6) + i11 + i16 + i17] = bVar.d(iArr[i22], iArr[i18]);
                    i17++;
                    iD = iD;
                    zE = zE;
                    i3 = 2;
                }
                i15++;
                i3 = 2;
            }
            i11 += i12 << 3;
            i10++;
            i3 = 2;
        }
        return zArr;
    }
}
