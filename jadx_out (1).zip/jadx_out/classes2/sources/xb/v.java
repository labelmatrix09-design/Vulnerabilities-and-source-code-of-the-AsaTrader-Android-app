package xb;

import java.io.IOException;

/* JADX INFO: compiled from: R8$$SyntheticClass */
/* JADX INFO: loaded from: /home/kali/Desktop/bunt/agah/dex_files/classes2.dex */
public final /* synthetic */ class v implements Runnable {
    public final /* synthetic */ com.google.android.exoplayer2.source.j.a o;
    public final /* synthetic */ com.google.android.exoplayer2.source.j p;
    public final /* synthetic */ n q;
    public final /* synthetic */ o r;
    public final /* synthetic */ IOException s;
    public final /* synthetic */ boolean t;

    public /* synthetic */ v(com.google.android.exoplayer2.source.j.a aVar, com.google.android.exoplayer2.source.j jVar, n nVar, o oVar, IOException iOException, boolean z) {
        this.o = aVar;
        this.p = jVar;
        this.q = nVar;
        this.r = oVar;
        this.s = iOException;
        this.t = z;
    }

    @Override // java.lang.Runnable
    public final void run() {
        com.google.android.exoplayer2.source.j.a.b(this.o, this.p, this.q, this.r, this.s, this.t);
    }
}
