package xb;

import android.net.Uri;
import cb.l;
import cb.q;
import com.google.android.exoplayer2.m;
import com.google.android.exoplayer2.source.d;
import java.util.Map;

/* JADX INFO: compiled from: R8$$SyntheticClass */
/* JADX INFO: loaded from: /home/kali/Desktop/bunt/agah/dex_files/classes2.dex */
public final /* synthetic */ class f implements cb.r {
    public final /* synthetic */ m b;

    public final l[] a() {
        return d.d(this.b);
    }

    public /* synthetic */ l[] b(Uri uri, Map map) {
        return q.a(this, uri, map);
    }
}
