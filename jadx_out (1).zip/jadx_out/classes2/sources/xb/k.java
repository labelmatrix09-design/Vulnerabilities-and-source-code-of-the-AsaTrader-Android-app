package xb;

import com.google.android.exoplayer2.source.d;

/* JADX INFO: compiled from: R8$$SyntheticClass */
/* JADX INFO: loaded from: /home/kali/Desktop/bunt/agah/dex_files/classes2.dex */
public final /* synthetic */ class k implements bf.t {
    public final /* synthetic */ Class o;
    public final /* synthetic */ tc.j.a p;

    public /* synthetic */ k(Class cls, tc.j.a aVar) {
        this.o = cls;
        this.p = aVar;
    }

    @Override // bf.t
    public final Object get() {
        return d.a.d(this.o, this.p);
    }
}
