package xb;

import com.google.android.exoplayer2.source.m;

/* JADX INFO: compiled from: R8$$SyntheticClass */
/* JADX INFO: loaded from: /home/kali/Desktop/bunt/agah/dex_files/classes2.dex */
public final /* synthetic */ class x implements Runnable {
    public final /* synthetic */ m o;

    @Override // java.lang.Runnable
    public final void run() {
        m.v(this.o);
    }
}
