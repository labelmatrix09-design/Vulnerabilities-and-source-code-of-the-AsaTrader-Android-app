package xb;

/* JADX INFO: compiled from: R8$$SyntheticClass */
/* JADX INFO: loaded from: /home/kali/Desktop/bunt/agah/dex_files/classes2.dex */
public final /* synthetic */ class s implements Runnable {
    public final /* synthetic */ com.google.android.exoplayer2.source.j.a o;
    public final /* synthetic */ com.google.android.exoplayer2.source.j p;
    public final /* synthetic */ n q;
    public final /* synthetic */ o r;

    public /* synthetic */ s(com.google.android.exoplayer2.source.j.a aVar, com.google.android.exoplayer2.source.j jVar, n nVar, o oVar) {
        this.o = aVar;
        this.p = jVar;
        this.q = nVar;
        this.r = oVar;
    }

    @Override // java.lang.Runnable
    public final void run() {
        com.google.android.exoplayer2.source.j.a.c(this.o, this.p, this.q, this.r);
    }
}
