package xb;

import com.google.android.exoplayer2.source.d;

/* JADX INFO: compiled from: R8$$SyntheticClass */
/* JADX INFO: loaded from: /home/kali/Desktop/bunt/agah/dex_files/classes2.dex */
public final /* synthetic */ class g implements bf.t {
    public final /* synthetic */ d.a o;
    public final /* synthetic */ tc.j.a p;

    public /* synthetic */ g(d.a aVar, tc.j.a aVar2) {
        this.o = aVar;
        this.p = aVar2;
    }

    @Override // bf.t
    public final Object get() {
        return d.a.e(this.o, this.p);
    }
}
