package xb;

import com.google.android.exoplayer2.source.p;

/* JADX INFO: compiled from: R8$$SyntheticClass */
/* JADX INFO: loaded from: /home/kali/Desktop/bunt/agah/dex_files/classes2.dex */
public final /* synthetic */ class c0 implements uc.h {
    public static final /* synthetic */ c0 a = new c0();

    public final void a(Object obj) {
        p.g((p.c) obj);
    }
}
