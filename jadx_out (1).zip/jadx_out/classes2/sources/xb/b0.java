package xb;

import com.google.android.exoplayer2.source.l;
import com.google.android.exoplayer2.source.n;
import ya.s1;

/* JADX INFO: compiled from: R8$$SyntheticClass */
/* JADX INFO: loaded from: /home/kali/Desktop/bunt/agah/dex_files/classes2.dex */
public final /* synthetic */ class b0 implements l.a {
    public final /* synthetic */ cb.r a;

    public final l a(s1 s1Var) {
        return n.b.d(this.a, s1Var);
    }
}
