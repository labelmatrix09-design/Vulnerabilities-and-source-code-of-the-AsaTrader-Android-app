package xb;

import com.google.android.exoplayer2.d0;
import com.google.android.exoplayer2.source.c;

/* JADX INFO: compiled from: R8$$SyntheticClass */
/* JADX INFO: loaded from: /home/kali/Desktop/bunt/agah/dex_files/classes2.dex */
public final /* synthetic */ class b implements com.google.android.exoplayer2.source.i.c {
    public final /* synthetic */ c a;
    public final /* synthetic */ Object b;

    public /* synthetic */ b(c cVar, Object obj) {
        this.a = cVar;
        this.b = obj;
    }

    public final void a(com.google.android.exoplayer2.source.i iVar, d0 d0Var) {
        c.F(this.a, this.b, iVar, d0Var);
    }
}
