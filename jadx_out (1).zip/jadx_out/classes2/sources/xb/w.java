package xb;

/* JADX INFO: compiled from: R8$$SyntheticClass */
/* JADX INFO: loaded from: /home/kali/Desktop/bunt/agah/dex_files/classes2.dex */
public final /* synthetic */ class w implements Runnable {
    public final /* synthetic */ com.google.android.exoplayer2.source.j.a o;
    public final /* synthetic */ com.google.android.exoplayer2.source.j p;
    public final /* synthetic */ o q;

    public /* synthetic */ w(com.google.android.exoplayer2.source.j.a aVar, com.google.android.exoplayer2.source.j jVar, o oVar) {
        this.o = aVar;
        this.p = jVar;
        this.q = oVar;
    }

    @Override // java.lang.Runnable
    public final void run() {
        com.google.android.exoplayer2.source.j.a.d(this.o, this.p, this.q);
    }
}
