package xb;

import com.google.android.exoplayer2.source.d;

/* JADX INFO: compiled from: R8$$SyntheticClass */
/* JADX INFO: loaded from: /home/kali/Desktop/bunt/agah/dex_files/classes2.dex */
public final /* synthetic */ class h implements bf.t {
    public final /* synthetic */ Class o;

    @Override // bf.t
    public final Object get() {
        return d.a.a(this.o);
    }
}
