package xb;

import com.google.android.exoplayer2.source.m;

/* JADX INFO: compiled from: R8$$SyntheticClass */
/* JADX INFO: loaded from: /home/kali/Desktop/bunt/agah/dex_files/classes2.dex */
public final /* synthetic */ class a0 implements Runnable {
    public final /* synthetic */ m o;
    public final /* synthetic */ cb.b0 p;

    public /* synthetic */ a0(m mVar, cb.b0 b0Var) {
        this.o = mVar;
        this.p = b0Var;
    }

    @Override // java.lang.Runnable
    public final void run() {
        m.x(this.o, this.p);
    }
}
