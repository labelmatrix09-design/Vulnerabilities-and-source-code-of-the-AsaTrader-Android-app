package xb;

import android.os.Bundle;

/* JADX INFO: compiled from: R8$$SyntheticClass */
/* JADX INFO: loaded from: /home/kali/Desktop/bunt/agah/dex_files/classes2.dex */
public final /* synthetic */ class h0 implements com.google.android.exoplayer2.f.a {
    public static final /* synthetic */ h0 a = new h0();

    public final com.google.android.exoplayer2.f a(Bundle bundle) {
        return i0.b(bundle);
    }
}
