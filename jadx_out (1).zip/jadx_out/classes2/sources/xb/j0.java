package xb;

import android.os.Bundle;

/* JADX INFO: compiled from: R8$$SyntheticClass */
/* JADX INFO: loaded from: /home/kali/Desktop/bunt/agah/dex_files/classes2.dex */
public final /* synthetic */ class j0 implements com.google.android.exoplayer2.f.a {
    public static final /* synthetic */ j0 a = new j0();

    public final com.google.android.exoplayer2.f a(Bundle bundle) {
        return k0.b(bundle);
    }
}
