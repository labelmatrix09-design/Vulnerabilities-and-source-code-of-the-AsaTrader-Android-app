package pg;

import android.annotation.TargetApi;
import android.graphics.Rect;
import android.hardware.Camera;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.regex.Pattern;
import nh.d;
import okhttp3.internal.ws.WebSocketProtocol;

/* JADX INFO: compiled from: CameraConfigurationUtils.java */
/* JADX INFO: loaded from: /home/kali/Desktop/bunt/agah/dex_files/classes2.dex */
public final class a {
    public static final Pattern a = Pattern.compile(";");

    @TargetApi(WebSocketProtocol.B0_MASK_OPCODE)
    public static List<Camera.Area> a(int i) {
        int i3 = -i;
        return Collections.singletonList(new Camera.Area(new Rect(i3, i3, i, i), 1));
    }

    public static String b(String str, Collection<String> collection, String... strArr) {
        StringBuilder sb = new StringBuilder();
        sb.append("Requesting ");
        sb.append(str);
        sb.append(" value from among: ");
        sb.append(Arrays.toString(strArr));
        StringBuilder sb2 = new StringBuilder();
        sb2.append("Supported ");
        sb2.append(str);
        sb2.append(" values: ");
        sb2.append(collection);
        if (collection == null) {
            return null;
        }
        for (String str2 : strArr) {
            if (collection.contains(str2)) {
                StringBuilder sb3 = new StringBuilder();
                sb3.append("Can set ");
                sb3.append(str);
                sb3.append(" to: ");
                sb3.append(str2);
                return str2;
            }
        }
        return null;
    }

    public static void c(Camera.Parameters parameters) {
        String strB;
        if ("barcode".equals(parameters.getSceneMode()) || (strB = b("scene mode", parameters.getSupportedSceneModes(), "barcode")) == null) {
            return;
        }
        parameters.setSceneMode(strB);
    }

    public static void d(Camera.Parameters parameters, boolean z) {
        int minExposureCompensation = parameters.getMinExposureCompensation();
        int maxExposureCompensation = parameters.getMaxExposureCompensation();
        float exposureCompensationStep = parameters.getExposureCompensationStep();
        if (minExposureCompensation == 0 && maxExposureCompensation == 0) {
            return;
        }
        if (exposureCompensationStep > 0.0f) {
            int iRound = Math.round((z ? 0.0f : 1.5f) / exposureCompensationStep);
            float f = exposureCompensationStep * iRound;
            int iMax = Math.max(Math.min(iRound, maxExposureCompensation), minExposureCompensation);
            if (parameters.getExposureCompensation() == iMax) {
                StringBuilder sb = new StringBuilder();
                sb.append("Exposure compensation already set to ");
                sb.append(iMax);
                sb.append(" / ");
                sb.append(f);
                return;
            }
            StringBuilder sb2 = new StringBuilder();
            sb2.append("Setting exposure compensation to ");
            sb2.append(iMax);
            sb2.append(" / ");
            sb2.append(f);
            parameters.setExposureCompensation(iMax);
        }
    }

    public static void e(Camera.Parameters parameters) {
        f(parameters, 10, 20);
    }

    public static void f(Camera.Parameters parameters, int i, int i3) {
        List<int[]> supportedPreviewFpsRange = parameters.getSupportedPreviewFpsRange();
        StringBuilder sb = new StringBuilder();
        sb.append("Supported FPS ranges: ");
        sb.append(n(supportedPreviewFpsRange));
        if (supportedPreviewFpsRange == null || supportedPreviewFpsRange.isEmpty()) {
            return;
        }
        int[] iArr = null;
        for (int[] iArr2 : supportedPreviewFpsRange) {
            int i5 = iArr2[0];
            int i6 = iArr2[1];
            if (i5 >= i * 1000 && i6 <= i3 * 1000) {
                iArr = iArr2;
                break;
            }
        }
        if (iArr == null) {
            return;
        }
        int[] iArr3 = new int[2];
        parameters.getPreviewFpsRange(iArr3);
        if (Arrays.equals(iArr3, iArr)) {
            StringBuilder sb2 = new StringBuilder();
            sb2.append("FPS range already set to ");
            sb2.append(Arrays.toString(iArr));
        } else {
            StringBuilder sb3 = new StringBuilder();
            sb3.append("Setting FPS range to ");
            sb3.append(Arrays.toString(iArr));
            parameters.setPreviewFpsRange(iArr[0], iArr[1]);
        }
    }

    public static void g(Camera.Parameters parameters, d.a aVar, boolean z) {
        String strB;
        List<String> supportedFocusModes = parameters.getSupportedFocusModes();
        if (z || aVar == d.a.AUTO) {
            strB = b("focus mode", supportedFocusModes, "auto");
        } else if (aVar == d.a.CONTINUOUS) {
            strB = b("focus mode", supportedFocusModes, "continuous-picture", "continuous-video", "auto");
        } else if (aVar == d.a.INFINITY) {
            strB = b("focus mode", supportedFocusModes, "infinity");
        } else {
            strB = aVar == d.a.MACRO ? b("focus mode", supportedFocusModes, "macro") : null;
        }
        if (!z && strB == null) {
            strB = b("focus mode", supportedFocusModes, "macro", "edof");
        }
        if (strB != null) {
            if (!strB.equals(parameters.getFocusMode())) {
                parameters.setFocusMode(strB);
                return;
            }
            StringBuilder sb = new StringBuilder();
            sb.append("Focus mode already set to ");
            sb.append(strB);
        }
    }

    @TargetApi(WebSocketProtocol.B0_MASK_OPCODE)
    public static void h(Camera.Parameters parameters) {
        if (parameters.getMaxNumFocusAreas() > 0) {
            StringBuilder sb = new StringBuilder();
            sb.append("Old focus areas: ");
            sb.append(m(parameters.getFocusAreas()));
            List<Camera.Area> listA = a(400);
            StringBuilder sb2 = new StringBuilder();
            sb2.append("Setting focus area to : ");
            sb2.append(m(listA));
            parameters.setFocusAreas(listA);
        }
    }

    public static void i(Camera.Parameters parameters) {
        String strB;
        if ("negative".equals(parameters.getColorEffect()) || (strB = b("color effect", parameters.getSupportedColorEffects(), "negative")) == null) {
            return;
        }
        parameters.setColorEffect(strB);
    }

    @TargetApi(WebSocketProtocol.B0_MASK_OPCODE)
    public static void j(Camera.Parameters parameters) {
        if (parameters.getMaxNumMeteringAreas() > 0) {
            StringBuilder sb = new StringBuilder();
            sb.append("Old metering areas: ");
            sb.append(parameters.getMeteringAreas());
            List<Camera.Area> listA = a(400);
            StringBuilder sb2 = new StringBuilder();
            sb2.append("Setting metering area to : ");
            sb2.append(m(listA));
            parameters.setMeteringAreas(listA);
        }
    }

    public static void k(Camera.Parameters parameters, boolean z) {
        List<String> supportedFlashModes = parameters.getSupportedFlashModes();
        String strB = z ? b("flash mode", supportedFlashModes, "torch", "on") : b("flash mode", supportedFlashModes, "off");
        if (strB != null) {
            if (strB.equals(parameters.getFlashMode())) {
                StringBuilder sb = new StringBuilder();
                sb.append("Flash mode already set to ");
                sb.append(strB);
            } else {
                StringBuilder sb2 = new StringBuilder();
                sb2.append("Setting flash mode to ");
                sb2.append(strB);
                parameters.setFlashMode(strB);
            }
        }
    }

    @TargetApi(WebSocketProtocol.B0_MASK_OPCODE)
    public static void l(Camera.Parameters parameters) {
        if (!parameters.isVideoStabilizationSupported() || parameters.getVideoStabilization()) {
            return;
        }
        parameters.setVideoStabilization(true);
    }

    @TargetApi(WebSocketProtocol.B0_MASK_OPCODE)
    public static String m(Iterable<Camera.Area> iterable) {
        if (iterable == null) {
            return null;
        }
        StringBuilder sb = new StringBuilder();
        for (Camera.Area area : iterable) {
            sb.append(area.rect);
            sb.append(':');
            sb.append(area.weight);
            sb.append(' ');
        }
        return sb.toString();
    }

    public static String n(Collection<int[]> collection) {
        if (collection == null || collection.isEmpty()) {
            return "[]";
        }
        StringBuilder sb = new StringBuilder();
        sb.append('[');
        Iterator<int[]> it = collection.iterator();
        while (it.hasNext()) {
            sb.append(Arrays.toString(it.next()));
            if (it.hasNext()) {
                sb.append(", ");
            }
        }
        sb.append(']');
        return sb.toString();
    }
}
