package yf;

/* JADX INFO: compiled from: SystemClock.java */
/* JADX INFO: loaded from: /home/kali/Desktop/bunt/agah/dex_files/classes2.dex */
public class b implements a {
    public static b a;

    public static b b() {
        if (a == null) {
            a = new b();
        }
        return a;
    }

    @Override // yf.a
    public long a() {
        return System.currentTimeMillis();
    }
}
