package yf;

/* JADX INFO: compiled from: Clock.java */
/* JADX INFO: loaded from: /home/kali/Desktop/bunt/agah/dex_files/classes2.dex */
public interface a {
    long a();
}
