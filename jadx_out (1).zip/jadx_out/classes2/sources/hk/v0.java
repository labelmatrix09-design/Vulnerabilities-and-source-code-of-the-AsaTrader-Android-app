package hk;

import java.io.IOException;
import java.io.Reader;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.TimeZone;
import org.jetbrains.annotations.ApiStatus;

/* JADX INFO: compiled from: JsonObjectReader.java */
/* JADX INFO: loaded from: /home/kali/Desktop/bunt/agah/dex_files/classes2.dex */
@ApiStatus.Internal
public final class v0 extends uk.a {
    public v0(Reader reader) {
        super(reader);
    }

    public Float A0() {
        return Float.valueOf((float) z());
    }

    public Float J0() throws IOException {
        if (V() != uk.b.NULL) {
            return A0();
        }
        L();
        return null;
    }

    public Integer M0() throws IOException {
        if (V() != uk.b.NULL) {
            return Integer.valueOf(A());
        }
        L();
        return null;
    }

    public <T> List<T> N0(f0 f0Var, p0<T> p0Var) throws IOException {
        if (V() == uk.b.NULL) {
            L();
            return null;
        }
        a();
        ArrayList arrayList = new ArrayList();
        do {
            try {
                arrayList.add(p0Var.a(this, f0Var));
            } catch (Exception e) {
                f0Var.b(i3.ERROR, "Failed to deserialize object in list.", e);
            }
        } while (V() == uk.b.BEGIN_OBJECT);
        j();
        return arrayList;
    }

    public Long O0() throws IOException {
        if (V() != uk.b.NULL) {
            return Long.valueOf(B());
        }
        L();
        return null;
    }

    public Object Q0() {
        return new u0().c(this);
    }

    public <T> T R0(f0 f0Var, p0<T> p0Var) throws IOException {
        if (V() != uk.b.NULL) {
            return p0Var.a(this, f0Var);
        }
        L();
        return null;
    }

    public String S0() throws IOException {
        if (V() != uk.b.NULL) {
            return N();
        }
        L();
        return null;
    }

    public TimeZone T0(f0 f0Var) throws IOException {
        if (V() == uk.b.NULL) {
            L();
            return null;
        }
        try {
            return TimeZone.getTimeZone(N());
        } catch (Exception e) {
            f0Var.b(i3.ERROR, "Error when deserializing TimeZone", e);
            return null;
        }
    }

    public void V0(f0 f0Var, Map<String, Object> map, String str) {
        try {
            map.put(str, Q0());
        } catch (Exception e) {
            f0Var.d(i3.ERROR, e, "Error deserializing unknown key: %s", str);
        }
    }

    public Boolean w0() throws IOException {
        if (V() != uk.b.NULL) {
            return Boolean.valueOf(x());
        }
        L();
        return null;
    }

    public Date x0(f0 f0Var) throws IOException {
        if (V() == uk.b.NULL) {
            L();
            return null;
        }
        String strN = N();
        try {
            return g.d(strN);
        } catch (Exception e) {
            f0Var.b(i3.DEBUG, "Error when deserializing UTC timestamp format, it might be millis timestamp format.", e);
            try {
                return g.e(strN);
            } catch (Exception e2) {
                f0Var.b(i3.ERROR, "Error when deserializing millis timestamp format.", e2);
                return null;
            }
        }
    }

    public Double z0() throws IOException {
        if (V() != uk.b.NULL) {
            return Double.valueOf(z());
        }
        L();
        return null;
    }
}
