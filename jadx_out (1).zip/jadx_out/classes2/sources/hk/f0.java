package hk;

/* JADX INFO: compiled from: ILogger.java */
/* JADX INFO: loaded from: /home/kali/Desktop/bunt/agah/dex_files/classes2.dex */
public interface f0 {
    void a(i3 i3Var, String str, Object... objArr);

    void b(i3 i3Var, String str, Throwable th2);

    boolean c(i3 i3Var);

    void d(i3 i3Var, Throwable th2, String str, Object... objArr);
}
