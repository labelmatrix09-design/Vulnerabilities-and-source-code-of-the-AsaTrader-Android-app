package hk;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import org.jetbrains.annotations.ApiStatus;

/* JADX INFO: compiled from: EnvelopeSender.java */
/* JADX INFO: loaded from: /home/kali/Desktop/bunt/agah/dex_files/classes2.dex */
@ApiStatus.Internal
public final class q extends j implements c0 {
    public final e0 c;
    public final j0 d;
    public final f0 e;

    public q(e0 e0Var, j0 j0Var, f0 f0Var, long j) {
        super(f0Var, j);
        this.c = (e0) rk.j.a(e0Var, "Hub is required.");
        this.d = (j0) rk.j.a(j0Var, "Serializer is required.");
        this.e = (f0) rk.j.a(f0Var, "Logger is required.");
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void j(ok.d dVar) {
        if (dVar.e()) {
            return;
        }
        this.e.a(i3.WARNING, "Timed out waiting for envelope submission.", new Object[0]);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void k(Throwable th2, File file, ok.f fVar) {
        fVar.d(false);
        this.e.d(i3.INFO, th2, "File '%s' won't retry.", file.getAbsolutePath());
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void l(File file, ok.f fVar) {
        if (fVar.b()) {
            this.e.a(i3.INFO, "File not deleted since retry was marked. %s.", file.getAbsolutePath());
        } else {
            m(file, "after trying to capture it");
            this.e.a(i3.DEBUG, "Deleted file %s.", file.getAbsolutePath());
        }
    }

    @Override // hk.c0
    public void a(String str, u uVar) {
        rk.j.a(str, "Path is required.");
        f(new File(str), uVar);
    }

    @Override // hk.j
    public boolean c(String str) {
        return str.endsWith(".envelope");
    }

    @Override // hk.j
    public /* bridge */ /* synthetic */ void e(File file) {
        super.e(file);
    }

    @Override // hk.j
    public void f(final File file, u uVar) {
        f0 f0Var;
        rk.h.a aVar;
        if (!file.isFile()) {
            this.e.a(i3.DEBUG, "'%s' is not a file.", file.getAbsolutePath());
            return;
        }
        if (!c(file.getName())) {
            this.e.a(i3.DEBUG, "File '%s' doesn't match extension expected.", file.getAbsolutePath());
            return;
        }
        try {
            if (!file.getParentFile().canWrite()) {
                this.e.a(i3.WARNING, "File '%s' cannot be deleted so it will not be processed.", file.getAbsolutePath());
                return;
            }
            try {
                try {
                    try {
                        BufferedInputStream bufferedInputStream = new BufferedInputStream(new FileInputStream(file));
                        try {
                            l2 l2VarD = this.d.d(bufferedInputStream);
                            if (l2VarD == null) {
                                this.e.a(i3.ERROR, "Failed to deserialize cached envelope %s", file.getAbsolutePath());
                            } else {
                                this.c.d(l2VarD, uVar);
                            }
                            rk.h.o(uVar, ok.d.class, this.e, new rk.h.a() { // from class: hk.n
                                @Override // rk.h.a
                                public final void a(Object obj) {
                                    this.a.j((ok.d) obj);
                                }
                            });
                            bufferedInputStream.close();
                            f0Var = this.e;
                            aVar = new rk.h.a() { // from class: hk.o
                                @Override // rk.h.a
                                public final void a(Object obj) {
                                    this.a.l(file, (ok.f) obj);
                                }
                            };
                        } catch (Throwable th2) {
                            try {
                                bufferedInputStream.close();
                            } catch (Throwable unused) {
                            }
                            throw th2;
                        }
                    } catch (Throwable th3) {
                        this.e.d(i3.ERROR, th3, "Failed to capture cached envelope %s", file.getAbsolutePath());
                        rk.h.o(uVar, ok.f.class, this.e, new rk.h.a() { // from class: hk.p
                            @Override // rk.h.a
                            public final void a(Object obj) {
                                this.a.k(th3, file, (ok.f) obj);
                            }
                        });
                        f0Var = this.e;
                        aVar = new rk.h.a() { // from class: hk.o
                            @Override // rk.h.a
                            public final void a(Object obj) {
                                this.a.l(file, (ok.f) obj);
                            }
                        };
                    }
                } catch (FileNotFoundException e) {
                    this.e.d(i3.ERROR, e, "File '%s' cannot be found.", file.getAbsolutePath());
                    f0Var = this.e;
                    aVar = new rk.h.a() { // from class: hk.o
                        @Override // rk.h.a
                        public final void a(Object obj) {
                            this.a.l(file, (ok.f) obj);
                        }
                    };
                }
            } catch (IOException e2) {
                this.e.d(i3.ERROR, e2, "I/O on file '%s' failed.", file.getAbsolutePath());
                f0Var = this.e;
                aVar = new rk.h.a() { // from class: hk.o
                    @Override // rk.h.a
                    public final void a(Object obj) {
                        this.a.l(file, (ok.f) obj);
                    }
                };
            }
            rk.h.o(uVar, ok.f.class, f0Var, aVar);
        } catch (Throwable th4) {
            rk.h.o(uVar, ok.f.class, this.e, new rk.h.a() { // from class: hk.o
                @Override // rk.h.a
                public final void a(Object obj) {
                    this.a.l(file, (ok.f) obj);
                }
            });
            throw th4;
        }
    }

    public final void m(File file, String str) {
        try {
            if (file.delete()) {
                return;
            }
            this.e.a(i3.ERROR, "Failed to delete '%s' %s", file.getAbsolutePath(), str);
        } catch (Throwable th2) {
            this.e.d(i3.ERROR, th2, "Failed to delete '%s' %s", file.getAbsolutePath(), str);
        }
    }
}
