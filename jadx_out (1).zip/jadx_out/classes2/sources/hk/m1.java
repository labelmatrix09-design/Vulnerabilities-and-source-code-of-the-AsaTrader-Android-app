package hk;

import org.jetbrains.annotations.ApiStatus;

/* JADX INFO: compiled from: NoOpTransportFactory.java */
/* JADX INFO: loaded from: /home/kali/Desktop/bunt/agah/dex_files/classes2.dex */
@ApiStatus.Internal
public final class m1 implements n0 {
    public static final m1 a = new m1();

    public static m1 b() {
        return a;
    }

    @Override // hk.n0
    public qk.p a(j3 j3Var, t1 t1Var) {
        return qk.s.a();
    }
}
