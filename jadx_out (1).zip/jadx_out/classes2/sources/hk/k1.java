package hk;

import io.github.inflationx.calligraphy3.BuildConfig;
import java.util.Date;

/* JADX INFO: compiled from: NoOpTransaction.java */
/* JADX INFO: loaded from: /home/kali/Desktop/bunt/agah/dex_files/classes2.dex */
public final class k1 implements l0 {
    public static final k1 a = new k1();

    public static k1 k() {
        return a;
    }

    @Override // hk.k0
    public f4 a() {
        return new f4(pk.m.p, BuildConfig.FLAVOR);
    }

    @Override // hk.k0
    public boolean b() {
        return true;
    }

    @Override // hk.k0
    public void c() {
    }

    @Override // hk.k0
    public void d(a4 a4Var) {
    }

    @Override // hk.l0
    public w3 e() {
        return null;
    }

    @Override // hk.l0
    public pk.m f() {
        return pk.m.p;
    }

    @Override // hk.l0
    public void g() {
    }

    @Override // hk.l0
    public String getName() {
        return BuildConfig.FLAVOR;
    }

    @Override // hk.k0
    public x3 h() {
        return new x3(pk.m.p, z3.p, "op", null, null);
    }

    @Override // hk.k0
    public k0 i(String str, String str2, Date date) {
        return j1.k();
    }

    @Override // hk.k0
    public a4 j() {
        return null;
    }
}
