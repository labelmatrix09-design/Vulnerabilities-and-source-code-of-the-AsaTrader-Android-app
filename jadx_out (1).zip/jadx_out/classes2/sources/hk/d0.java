package hk;

import java.util.Date;
import org.jetbrains.annotations.ApiStatus;

/* JADX INFO: compiled from: IHub.java */
/* JADX INFO: loaded from: /home/kali/Desktop/bunt/agah/dex_files/classes2.dex */
public final /* synthetic */ class d0 {
    public static void a(e0 e0Var, c cVar) {
        e0Var.l(cVar, new u());
    }

    public static pk.m b(e0 e0Var, Throwable th2) {
        return e0Var.o(th2, new u());
    }

    @ApiStatus.Internal
    public static pk.m c(e0 e0Var, pk.t tVar, f4 f4Var, u uVar) {
        return e0Var.r(tVar, f4Var, uVar, null);
    }

    @ApiStatus.Internal
    public static l0 d(e0 e0Var, String str, String str2, Date date, boolean z, i4 i4Var) {
        return e0Var.m(new h4(str, str2), null, false, date, z, null, false, i4Var);
    }

    @ApiStatus.Internal
    public static l0 e(e0 e0Var, String str, String str2, boolean z, Long l, boolean z4) {
        return e0Var.m(new h4(str, str2), null, false, null, z, l, z4, null);
    }
}
