package hk;

import java.util.Date;
import org.jetbrains.annotations.ApiStatus;

/* JADX INFO: compiled from: HubAdapter.java */
/* JADX INFO: loaded from: /home/kali/Desktop/bunt/agah/dex_files/classes2.dex */
public final class a0 implements e0 {
    public static final a0 a = new a0();

    public static a0 a() {
        return a;
    }

    @Override // hk.e0
    public void c(long j) {
        f2.h(j);
    }

    @Override // hk.e0
    public void close() {
        f2.e();
    }

    @Override // hk.e0
    @ApiStatus.Internal
    public pk.m d(l2 l2Var, u uVar) {
        return f2.i().d(l2Var, uVar);
    }

    @Override // hk.e0
    public /* synthetic */ void e(c cVar) {
        d0.a(this, cVar);
    }

    @Override // hk.e0
    public void f(x1 x1Var) {
        f2.f(x1Var);
    }

    @Override // hk.e0
    public /* synthetic */ pk.m g(pk.t tVar, f4 f4Var, u uVar) {
        return d0.c(this, tVar, f4Var, uVar);
    }

    @Override // hk.e0
    public j3 h() {
        return f2.i().h();
    }

    @Override // hk.e0
    public pk.m i(e3 e3Var, u uVar) {
        return f2.c(e3Var, uVar);
    }

    @Override // hk.e0
    public boolean isEnabled() {
        return f2.m();
    }

    @Override // hk.e0
    public /* synthetic */ l0 j(String str, String str2, Date date, boolean z, i4 i4Var) {
        return d0.d(this, str, str2, date, z, i4Var);
    }

    @Override // hk.e0
    public /* synthetic */ pk.m k(Throwable th2) {
        return d0.b(this, th2);
    }

    @Override // hk.e0
    public void l(c cVar, u uVar) {
        f2.b(cVar, uVar);
    }

    @Override // hk.e0
    @ApiStatus.Internal
    public l0 m(h4 h4Var, e eVar, boolean z, Date date, boolean z4, Long l, boolean z5, i4 i4Var) {
        return f2.p(h4Var, eVar, z, date, z4, l, z5, i4Var);
    }

    @Override // hk.e0
    public /* synthetic */ l0 n(String str, String str2, boolean z, Long l, boolean z4) {
        return d0.e(this, str, str2, z, l, z4);
    }

    @Override // hk.e0
    public pk.m o(Throwable th2, u uVar) {
        return f2.d(th2, uVar);
    }

    @Override // hk.e0
    public void p() {
        f2.g();
    }

    @Override // hk.e0
    public void q() {
        f2.o();
    }

    @Override // hk.e0
    public pk.m r(pk.t tVar, f4 f4Var, u uVar, s1 s1Var) {
        return f2.i().r(tVar, f4Var, uVar, s1Var);
    }

    @Override // hk.e0
    public void s(Throwable th2, k0 k0Var, String str) {
        f2.i().s(th2, k0Var, str);
    }

    @Override // hk.e0
    /* JADX INFO: renamed from: clone, reason: merged with bridge method [inline-methods] */
    public e0 m0clone() {
        return f2.i().m2clone();
    }
}
