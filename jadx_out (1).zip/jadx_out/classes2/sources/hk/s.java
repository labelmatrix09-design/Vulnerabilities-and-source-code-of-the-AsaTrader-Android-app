package hk;

/* JADX INFO: compiled from: EventProcessor.java */
/* JADX INFO: loaded from: /home/kali/Desktop/bunt/agah/dex_files/classes2.dex */
public interface s {
    e3 a(e3 e3Var, u uVar);

    pk.t b(pk.t tVar, u uVar);
}
