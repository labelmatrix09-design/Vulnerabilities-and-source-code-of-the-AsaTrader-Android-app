package hk;

import io.github.inflationx.calligraphy3.BuildConfig;
import java.io.IOException;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import org.jetbrains.annotations.ApiStatus;

/* JADX INFO: compiled from: TraceContext.java */
/* JADX INFO: loaded from: /home/kali/Desktop/bunt/agah/dex_files/classes2.dex */
@ApiStatus.Experimental
public final class f4 implements z0 {
    public pk.m o;
    public String p;
    public String q;
    public String r;
    public b s;
    public String t;
    public Map<String, Object> u;

    /* JADX INFO: compiled from: TraceContext.java */
    public static final class a implements p0<f4> {
        @Override // hk.p0
        /* JADX INFO: renamed from: b, reason: merged with bridge method [inline-methods] */
        public f4 a(v0 v0Var, f0 f0Var) throws Exception {
            v0Var.b();
            ConcurrentHashMap concurrentHashMap = null;
            pk.m mVarA = null;
            String strN = null;
            String strS0 = null;
            String strS1 = null;
            b bVar = null;
            String strS2 = null;
            while (v0Var.V() == uk.b.NAME) {
                String strF = v0Var.F();
                strF.hashCode();
                switch (strF) {
                    case "environment":
                        strS1 = v0Var.S0();
                        break;
                    case "user":
                        bVar = (b) v0Var.R0(f0Var, new b.a());
                        break;
                    case "release":
                        strS0 = v0Var.S0();
                        break;
                    case "trace_id":
                        mVarA = new pk.m.a().a(v0Var, f0Var);
                        break;
                    case "public_key":
                        strN = v0Var.N();
                        break;
                    case "transaction":
                        strS2 = v0Var.S0();
                        break;
                    default:
                        if (concurrentHashMap == null) {
                            concurrentHashMap = new ConcurrentHashMap();
                        }
                        v0Var.V0(f0Var, concurrentHashMap, strF);
                        break;
                }
            }
            if (mVarA == null) {
                throw c("trace_id", f0Var);
            }
            if (strN == null) {
                throw c("public_key", f0Var);
            }
            f4 f4Var = new f4(mVarA, strN, strS0, strS1, bVar, strS2);
            f4Var.a(concurrentHashMap);
            v0Var.m();
            return f4Var;
        }

        public final Exception c(String str, f0 f0Var) {
            String str2 = "Missing required field \"" + str + "\"";
            IllegalStateException illegalStateException = new IllegalStateException(str2);
            f0Var.b(i3.ERROR, str2, illegalStateException);
            return illegalStateException;
        }
    }

    public f4(pk.m mVar, String str) {
        this(mVar, str, null, null, null, null);
    }

    public void a(Map<String, Object> map) {
        this.u = map;
    }

    public void serialize(x0 x0Var, f0 f0Var) throws IOException {
        x0Var.g();
        x0Var.b0("trace_id").d0(f0Var, this.o);
        x0Var.b0("public_key").V(this.p);
        if (this.q != null) {
            x0Var.b0(BuildConfig.BUILD_TYPE).V(this.q);
        }
        if (this.r != null) {
            x0Var.b0("environment").V(this.r);
        }
        b bVar = this.s;
        if (bVar != null && (bVar.o != null || this.s.p != null || this.s.q != null)) {
            x0Var.b0("user").d0(f0Var, this.s);
        }
        if (this.t != null) {
            x0Var.b0("transaction").V(this.t);
        }
        Map<String, Object> map = this.u;
        if (map != null) {
            for (String str : map.keySet()) {
                Object obj = this.u.get(str);
                x0Var.b0(str);
                x0Var.d0(f0Var, obj);
            }
        }
        x0Var.m();
    }

    public f4(pk.m mVar, String str, String str2, String str3, b bVar, String str4) {
        this.o = mVar;
        this.p = str;
        this.q = str2;
        this.r = str3;
        this.s = bVar;
        this.t = str4;
    }

    /* JADX INFO: compiled from: TraceContext.java */
    public static final class b implements z0 {
        public String o;
        public String p;
        public Map<String, Object> q;

        /* JADX INFO: compiled from: TraceContext.java */
        public static final class a implements p0<b> {
            @Override // hk.p0
            /* JADX INFO: renamed from: b, reason: merged with bridge method [inline-methods] */
            public b a(v0 v0Var, f0 f0Var) throws IOException {
                v0Var.b();
                String strS0 = null;
                String strS1 = null;
                ConcurrentHashMap concurrentHashMap = null;
                while (v0Var.V() == uk.b.NAME) {
                    String strF = v0Var.F();
                    strF.hashCode();
                    if (strF.equals("id")) {
                        strS0 = v0Var.S0();
                    } else if (strF.equals("segment")) {
                        strS1 = v0Var.S0();
                    } else {
                        if (concurrentHashMap == null) {
                            concurrentHashMap = new ConcurrentHashMap();
                        }
                        v0Var.V0(f0Var, concurrentHashMap, strF);
                    }
                }
                b bVar = new b(strS0, strS1);
                bVar.e(concurrentHashMap);
                v0Var.m();
                return bVar;
            }
        }

        public b(String str, String str2) {
            this.o = str;
            this.p = str2;
        }

        public static String d(pk.u uVar) {
            Map<String, String> mapH = uVar.h();
            if (mapH != null) {
                return mapH.get("segment");
            }
            return null;
        }

        public void e(Map<String, Object> map) {
            this.q = map;
        }

        public void serialize(x0 x0Var, f0 f0Var) throws IOException {
            x0Var.g();
            if (this.o != null) {
                x0Var.b0("id").V(this.o);
            }
            if (this.p != null) {
                x0Var.b0("segment").V(this.p);
            }
            Map<String, Object> map = this.q;
            if (map != null) {
                for (String str : map.keySet()) {
                    Object obj = this.q.get(str);
                    x0Var.b0(str);
                    x0Var.d0(f0Var, obj);
                }
            }
            x0Var.m();
        }

        public b(pk.u uVar) {
            if (uVar != null) {
                this.o = uVar.f();
                this.p = d(uVar);
            }
        }
    }

    public f4(l0 l0Var, pk.u uVar, j3 j3Var) {
        this(l0Var.h().h(), new k(j3Var.getDsn()).a(), j3Var.getRelease(), j3Var.getEnvironment(), uVar != null ? new b(uVar) : null, l0Var.getName());
    }
}
