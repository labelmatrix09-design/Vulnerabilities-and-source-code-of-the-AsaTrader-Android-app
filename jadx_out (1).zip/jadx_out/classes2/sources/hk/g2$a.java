package hk;

import java.io.IOException;
import java.util.Map;

/* JADX INFO: compiled from: SentryBaseEvent.java */
/* JADX INFO: loaded from: /home/kali/Desktop/bunt/agah/dex_files/classes2.dex */
public final class g2$a {
    public boolean a(g2 g2Var, String str, v0 v0Var, f0 f0Var) throws IOException {
        str.hashCode();
        switch (str) {
            case "server_name":
                g2.y(g2Var, v0Var.S0());
                return true;
            case "contexts":
                g2.c(g2Var).putAll(new pk.c.a().a(v0Var, f0Var));
                return true;
            case "environment":
                g2.s(g2Var, v0Var.S0());
                return true;
            case "breadcrumbs":
                g2.g(g2Var, v0Var.N0(f0Var, new c.a()));
                return true;
            case "sdk":
                g2.k(g2Var, (pk.k) v0Var.R0(f0Var, new pk.k.a()));
                return true;
            case "dist":
                g2.e(g2Var, v0Var.S0());
                return true;
            case "tags":
                g2.o(g2Var, rk.a.b((Map) v0Var.Q0()));
                return true;
            case "user":
                g2.w(g2Var, (pk.u) v0Var.R0(f0Var, new pk.u.a()));
                return true;
            case "extra":
                g2.i(g2Var, rk.a.b((Map) v0Var.Q0()));
                return true;
            case "event_id":
                g2.b(g2Var, (pk.m) v0Var.R0(f0Var, new pk.m.a()));
                return true;
            case "release":
                g2.q(g2Var, v0Var.S0());
                return true;
            case "request":
                g2.m(g2Var, (pk.j) v0Var.R0(f0Var, new pk.j.a()));
                return true;
            case "platform":
                g2.u(g2Var, v0Var.S0());
                return true;
            default:
                return false;
        }
    }
}
