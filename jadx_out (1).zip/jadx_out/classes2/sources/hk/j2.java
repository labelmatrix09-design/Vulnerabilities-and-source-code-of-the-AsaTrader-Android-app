package hk;

import io.sentry.exception.SentryEnvelopeException;
import java.io.Closeable;
import java.io.IOException;
import java.security.SecureRandom;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import org.jetbrains.annotations.ApiStatus;

/* JADX INFO: compiled from: SentryClient.java */
/* JADX INFO: loaded from: /home/kali/Desktop/bunt/agah/dex_files/classes2.dex */
public final class j2 implements h0 {
    public final j3 b;
    public final qk.p c;
    public final SecureRandom d;
    public final b e = new b();
    public boolean a = true;

    /* JADX INFO: compiled from: SentryClient.java */
    public static final class b implements Comparator<c> {
        public b() {
        }

        @Override // java.util.Comparator
        /* JADX INFO: renamed from: a, reason: merged with bridge method [inline-methods] */
        public int compare(c cVar, c cVar2) {
            return cVar.j().compareTo(cVar2.j());
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    public j2(j3 j3Var) {
        this.b = (j3) rk.j.a(j3Var, "SentryOptions is required.");
        n0 transportFactory = j3Var.getTransportFactory();
        if (transportFactory instanceof m1) {
            transportFactory = new hk.a();
            j3Var.setTransportFactory(transportFactory);
        }
        this.c = transportFactory.a(j3Var, new u1(j3Var).a());
        this.d = j3Var.getSampleRate() != null ? new SecureRandom() : null;
    }

    public static /* synthetic */ void o(t3 t3Var) {
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void p(e3 e3Var, u uVar, t3 t3Var) {
        if (t3Var == null) {
            this.b.getLogger().a(i3.INFO, "Session is null on scope.withSession", new Object[0]);
            return;
        }
        String str = null;
        t3.b bVar = e3Var.s0() ? t3.b.Crashed : null;
        boolean z = t3.b.Crashed == bVar || e3Var.t0();
        if (e3Var.I() != null && e3Var.I().i() != null && e3Var.I().i().containsKey("user-agent")) {
            str = e3Var.I().i().get("user-agent");
        }
        if (t3Var.m(bVar, str, z) && rk.h.g(uVar, ok.c.class)) {
            t3Var.c();
        }
    }

    /* JADX WARN: Code duplicated, block: B:54:0x011e  */
    @Override // hk.h0
    public pk.m a(e3 e3Var, w1 w1Var, u uVar) {
        e3 e3Var2;
        f4 f4VarA;
        rk.j.a(e3Var, "SentryEvent is required.");
        if (uVar == null) {
            uVar = new u();
        }
        if (t(e3Var, uVar)) {
            h(w1Var, uVar);
        }
        f0 logger = this.b.getLogger();
        i3 i3Var = i3.DEBUG;
        logger.a(i3Var, "Capturing event: %s", e3Var.E());
        Throwable thM = e3Var.M();
        if (thM != null && this.b.containsIgnoredExceptionForType(thM)) {
            this.b.getLogger().a(i3Var, "Event was dropped as the exception %s is ignored", thM.getClass());
            this.b.getClientReportRecorder().a(mk.e.EVENT_PROCESSOR, f.Error);
            return pk.m.p;
        }
        if (t(e3Var, uVar) && (e3Var = j(e3Var, w1Var, uVar)) == null) {
            this.b.getLogger().a(i3Var, "Event was dropped by applyScope", new Object[0]);
            return pk.m.p;
        }
        e3 e3VarQ = q(e3Var, uVar, this.b.getEventProcessors());
        if (e3VarQ != null && (e3VarQ = l(e3VarQ, uVar)) == null) {
            this.b.getLogger().a(i3Var, "Event was dropped by beforeSend", new Object[0]);
            this.b.getClientReportRecorder().a(mk.e.BEFORE_SEND, f.Error);
        }
        if (e3VarQ == null) {
            return pk.m.p;
        }
        t3 t3VarU = w1Var != null ? w1Var.u(new w1.a() { // from class: hk.i2
            @Override // hk.w1.a
            public final void a(t3 t3Var) {
                j2.o(t3Var);
            }
        }) : null;
        t3 t3VarW = w(e3VarQ, uVar, w1Var);
        if (s()) {
            e3Var2 = e3VarQ;
        } else {
            this.b.getLogger().a(i3Var, "Event %s was dropped due to sampling decision.", e3VarQ.E());
            this.b.getClientReportRecorder().a(mk.e.SAMPLE_RATE, f.Error);
            e3Var2 = null;
        }
        boolean zU = u(t3VarU, t3VarW);
        if (e3Var2 == null && !zU) {
            this.b.getLogger().a(i3Var, "Not sending session update for dropped event as it did not cause the session health to change.", new Object[0]);
            return pk.m.p;
        }
        pk.m mVarE = pk.m.p;
        if (e3Var2 != null && e3Var2.E() != null) {
            mVarE = e3Var2.E();
        }
        if (w1Var != null) {
            try {
                if (w1Var.p() != null) {
                    f4VarA = w1Var.p().a();
                } else {
                    f4VarA = null;
                }
            } catch (SentryEnvelopeException e) {
                e = e;
                this.b.getLogger().d(i3.WARNING, e, "Capturing event %s failed.", mVarE);
                return pk.m.p;
            } catch (IOException e2) {
                e = e2;
                this.b.getLogger().d(i3.WARNING, e, "Capturing event %s failed.", mVarE);
                return pk.m.p;
            }
        } else {
            f4VarA = null;
        }
        l2 l2VarK = k(e3Var2, e3Var2 != null ? n(uVar) : null, t3VarW, f4VarA, null);
        if (l2VarK == null) {
            return mVarE;
        }
        this.c.a0(l2VarK, uVar);
        return mVarE;
    }

    @Override // hk.h0
    public pk.m b(pk.t tVar, f4 f4Var, w1 w1Var, u uVar, s1 s1Var) {
        pk.t tVarR = tVar;
        rk.j.a(tVar, "Transaction is required.");
        u uVar2 = uVar == null ? new u() : uVar;
        if (t(tVar, uVar2)) {
            h(w1Var, uVar2);
        }
        f0 logger = this.b.getLogger();
        i3 i3Var = i3.DEBUG;
        logger.a(i3Var, "Capturing transaction: %s", tVar.E());
        pk.m mVar = pk.m.p;
        pk.m mVarE = tVar.E() != null ? tVar.E() : mVar;
        if (t(tVar, uVar2)) {
            tVarR = (pk.t) i(tVar, w1Var);
            if (tVarR != null && w1Var != null) {
                tVarR = r(tVarR, uVar2, w1Var.i());
            }
            if (tVarR == null) {
                this.b.getLogger().a(i3Var, "Transaction was dropped by applyScope", new Object[0]);
            }
        }
        if (tVarR != null) {
            tVarR = r(tVarR, uVar2, this.b.getEventProcessors());
        }
        pk.t tVar2 = tVarR;
        if (tVar2 == null) {
            this.b.getLogger().a(i3Var, "Transaction was dropped by Event processors.", new Object[0]);
            return mVar;
        }
        try {
            l2 l2VarK = k(tVar2, m(n(uVar2)), null, f4Var, s1Var);
            if (l2VarK == null) {
                return mVar;
            }
            this.c.a0(l2VarK, uVar2);
            return mVarE;
        } catch (SentryEnvelopeException | IOException e) {
            this.b.getLogger().d(i3.WARNING, e, "Capturing transaction %s failed.", mVarE);
            return pk.m.p;
        }
    }

    @Override // hk.h0
    public void c(long j) {
        this.c.c(j);
    }

    @Override // hk.h0
    public void close() {
        this.b.getLogger().a(i3.INFO, "Closing SentryClient.", new Object[0]);
        try {
            c(this.b.getShutdownTimeoutMillis());
            this.c.close();
        } catch (IOException e) {
            this.b.getLogger().b(i3.WARNING, "Failed to close the connection to the Sentry Server.", e);
        }
        for (s sVar : this.b.getEventProcessors()) {
            if (sVar instanceof Closeable) {
                try {
                    ((Closeable) sVar).close();
                } catch (IOException e2) {
                    this.b.getLogger().a(i3.WARNING, "Failed to close the event processor {}.", sVar, e2);
                }
            }
        }
        this.a = false;
    }

    @Override // hk.h0
    @ApiStatus.Internal
    public pk.m d(l2 l2Var, u uVar) {
        rk.j.a(l2Var, "SentryEnvelope is required.");
        if (uVar == null) {
            uVar = new u();
        }
        try {
            this.c.a0(l2Var, uVar);
            pk.m mVarA = l2Var.b().a();
            return mVarA != null ? mVarA : pk.m.p;
        } catch (IOException e) {
            this.b.getLogger().b(i3.ERROR, "Failed to capture envelope.", e);
            return pk.m.p;
        }
    }

    @Override // hk.h0
    @ApiStatus.Internal
    public void e(t3 t3Var, u uVar) {
        rk.j.a(t3Var, "Session is required.");
        if (t3Var.g() == null || t3Var.g().isEmpty()) {
            this.b.getLogger().a(i3.WARNING, "Sessions can't be captured without setting a release.", new Object[0]);
            return;
        }
        try {
            d(l2.a(this.b.getSerializer(), t3Var, this.b.getSdkVersion()), uVar);
        } catch (IOException e) {
            this.b.getLogger().b(i3.ERROR, "Failed to capture session.", e);
        }
    }

    public final void h(w1 w1Var, u uVar) {
        if (w1Var != null) {
            uVar.a(w1Var.f());
        }
    }

    public final <T extends g2> T i(T t, w1 w1Var) {
        if (w1Var != null) {
            if (t.I() == null) {
                t.W(w1Var.m());
            }
            if (t.O() == null) {
                t.b0(w1Var.r());
            }
            if (t.L() == null) {
                t.a0(new HashMap(w1Var.o()));
            } else {
                for (Map.Entry<String, String> entry : w1Var.o().entrySet()) {
                    if (!t.L().containsKey(entry.getKey())) {
                        t.L().put(entry.getKey(), entry.getValue());
                    }
                }
            }
            if (t.A() == null) {
                t.P(new ArrayList(w1Var.g()));
            } else {
                v(t, w1Var.g());
            }
            if (t.F() == null) {
                t.T(new HashMap(w1Var.j()));
            } else {
                for (Map.Entry<String, Object> entry2 : w1Var.j().entrySet()) {
                    if (!t.F().containsKey(entry2.getKey())) {
                        t.F().put(entry2.getKey(), entry2.getValue());
                    }
                }
            }
            pk.c cVarB = t.B();
            for (Map.Entry<String, Object> entry3 : new pk.c(w1Var.h()).entrySet()) {
                if (!cVarB.containsKey(entry3.getKey())) {
                    cVarB.put(entry3.getKey(), entry3.getValue());
                }
            }
        }
        return t;
    }

    public final e3 j(e3 e3Var, w1 w1Var, u uVar) {
        if (w1Var == null) {
            return e3Var;
        }
        i(e3Var, w1Var);
        if (e3Var.r0() == null) {
            e3Var.z0(w1Var.q());
        }
        if (e3Var.o0() == null) {
            e3Var.w0(w1Var.k());
        }
        if (w1Var.l() != null) {
            e3Var.x0(w1Var.l());
        }
        k0 k0VarN = w1Var.n();
        if (e3Var.B().f() == null && k0VarN != null) {
            e3Var.B().n(k0VarN.h());
        }
        return q(e3Var, uVar, w1Var.i());
    }

    public final l2 k(g2 g2Var, List<hk.b> list, t3 t3Var, f4 f4Var, s1 s1Var) {
        pk.m mVarE;
        ArrayList arrayList = new ArrayList();
        if (g2Var != null) {
            arrayList.add(c3.r(this.b.getSerializer(), g2Var));
            mVarE = g2Var.E();
        } else {
            mVarE = null;
        }
        if (t3Var != null) {
            arrayList.add(c3.t(this.b.getSerializer(), t3Var));
        }
        if (s1Var != null) {
            arrayList.add(c3.s(s1Var, this.b.getMaxTraceFileSize(), this.b.getSerializer()));
        }
        if (list != null) {
            Iterator<hk.b> it = list.iterator();
            while (it.hasNext()) {
                arrayList.add(c3.p(it.next(), this.b.getMaxAttachmentSize()));
            }
        }
        if (arrayList.isEmpty()) {
            return null;
        }
        return new l2(new m2(mVarE, this.b.getSdkVersion(), f4Var), arrayList);
    }

    public final e3 l(e3 e3Var, u uVar) {
        j3.b beforeSend = this.b.getBeforeSend();
        if (beforeSend == null) {
            return e3Var;
        }
        try {
            return beforeSend.a(e3Var, uVar);
        } catch (Throwable th2) {
            this.b.getLogger().b(i3.ERROR, "The BeforeSend callback threw an exception. It will be added as breadcrumb and continue.", th2);
            c cVar = new c();
            cVar.o("BeforeSend callback failed.");
            cVar.l("SentryClient");
            cVar.n(i3.ERROR);
            if (th2.getMessage() != null) {
                cVar.m("sentry:message", th2.getMessage());
            }
            e3Var.z(cVar);
            return e3Var;
        }
    }

    public final List<hk.b> m(List<hk.b> list) {
        if (list == null) {
            return null;
        }
        ArrayList arrayList = new ArrayList();
        for (hk.b bVar : list) {
            if (bVar.g()) {
                arrayList.add(bVar);
            }
        }
        return arrayList;
    }

    public final List<hk.b> n(u uVar) {
        List<hk.b> listC = uVar.c();
        hk.b bVarD = uVar.d();
        if (bVarD != null) {
            listC.add(bVarD);
        }
        return listC;
    }

    public final e3 q(e3 e3Var, u uVar, List<s> list) {
        for (s sVar : list) {
            try {
                e3Var = sVar.a(e3Var, uVar);
            } catch (Throwable th2) {
                this.b.getLogger().d(i3.ERROR, th2, "An exception occurred while processing event by processor: %s", sVar.getClass().getName());
            }
            if (e3Var == null) {
                this.b.getLogger().a(i3.DEBUG, "Event was dropped by a processor: %s", sVar.getClass().getName());
                this.b.getClientReportRecorder().a(mk.e.EVENT_PROCESSOR, f.Error);
                break;
            }
        }
        return e3Var;
    }

    public final pk.t r(pk.t tVar, u uVar, List<s> list) {
        for (s sVar : list) {
            try {
                tVar = sVar.b(tVar, uVar);
            } catch (Throwable th2) {
                this.b.getLogger().d(i3.ERROR, th2, "An exception occurred while processing transaction by processor: %s", sVar.getClass().getName());
            }
            if (tVar == null) {
                this.b.getLogger().a(i3.DEBUG, "Transaction was dropped by a processor: %s", sVar.getClass().getName());
                this.b.getClientReportRecorder().a(mk.e.EVENT_PROCESSOR, f.Transaction);
                break;
            }
        }
        return tVar;
    }

    public final boolean s() {
        return this.b.getSampleRate() == null || this.d == null || this.b.getSampleRate().doubleValue() >= this.d.nextDouble();
    }

    public final boolean t(g2 g2Var, u uVar) {
        if (rk.h.q(uVar)) {
            return true;
        }
        this.b.getLogger().a(i3.DEBUG, "Event was cached so not applying scope: %s", g2Var.E());
        return false;
    }

    public final boolean u(t3 t3Var, t3 t3Var2) {
        if (t3Var2 == null) {
            return false;
        }
        if (t3Var == null) {
            return true;
        }
        t3.b bVarJ = t3Var2.j();
        t3.b bVar = t3.b.Crashed;
        if (bVarJ == bVar && t3Var.j() != bVar) {
            return true;
        }
        return t3Var2.e() > 0 && t3Var.e() <= 0;
    }

    public final void v(g2 g2Var, Collection<c> collection) {
        List listA = g2Var.A();
        if (listA == null || collection.isEmpty()) {
            return;
        }
        listA.addAll(collection);
        Collections.sort(listA, this.e);
    }

    public t3 w(final e3 e3Var, final u uVar, w1 w1Var) {
        if (rk.h.q(uVar)) {
            if (w1Var != null) {
                return w1Var.u(new w1.a() { // from class: hk.h2
                    @Override // hk.w1.a
                    public final void a(t3 t3Var) {
                        this.a.p(e3Var, uVar, t3Var);
                    }
                });
            }
            this.b.getLogger().a(i3.INFO, "Scope is null on client.captureEvent", new Object[0]);
        }
        return null;
    }
}
