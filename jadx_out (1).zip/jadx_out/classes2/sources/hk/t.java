package hk;

import io.github.inflationx.calligraphy3.BuildConfig;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.CopyOnWriteArraySet;

/* JADX INFO: compiled from: ExternalOptions.java */
/* JADX INFO: loaded from: /home/kali/Desktop/bunt/agah/dex_files/classes2.dex */
public final class t {
    public String a;
    public String b;
    public String c;
    public String d;
    public String e;
    public Boolean f;
    public Boolean g;
    public Boolean h;
    public Double i;
    public j3$d j;
    public j3$c l;
    public String q;
    public Long r;
    public Boolean t;
    public Boolean u;
    public final Map<String, String> k = new ConcurrentHashMap();
    public final List<String> m = new CopyOnWriteArrayList();
    public final List<String> n = new CopyOnWriteArrayList();
    public final List<String> o = new CopyOnWriteArrayList();
    public final List<String> p = new CopyOnWriteArrayList();
    public final Set<Class<? extends Throwable>> s = new CopyOnWriteArraySet();

    /* JADX WARN: Multi-variable type inference failed */
    public static t f(nk.g gVar, f0 f0Var) {
        t tVar = new t();
        tVar.C(gVar.b("dsn"));
        tVar.F(gVar.b("environment"));
        tVar.L(gVar.b(BuildConfig.BUILD_TYPE));
        tVar.B(gVar.b("dist"));
        tVar.N(gVar.b("servername"));
        tVar.E(gVar.c("uncaught.handler.enabled"));
        tVar.I(gVar.c("uncaught.handler.print-stacktrace"));
        tVar.P(gVar.e("traces-sample-rate"));
        tVar.A(gVar.c("debug"));
        tVar.D(gVar.c("enable-deduplication"));
        tVar.M(gVar.c("send-client-reports"));
        String strB = gVar.b("max-request-body-size");
        if (strB != null) {
            tVar.H(j3$d.valueOf(strB.toUpperCase(Locale.ROOT)));
        }
        for (Map.Entry<String, String> entry : gVar.a("tags").entrySet()) {
            tVar.O(entry.getKey(), entry.getValue());
        }
        String strB2 = gVar.b("proxy.host");
        String strB3 = gVar.b("proxy.user");
        String strB4 = gVar.b("proxy.pass");
        String strF = gVar.f("proxy.port", "80");
        if (strB2 != null) {
            tVar.K(new j3$c(strB2, strF, strB3, strB4));
        }
        Iterator<String> it = gVar.g("in-app-includes").iterator();
        while (it.hasNext()) {
            tVar.d(it.next());
        }
        Iterator<String> it2 = gVar.g("in-app-excludes").iterator();
        while (it2.hasNext()) {
            tVar.c(it2.next());
        }
        Iterator<String> it3 = gVar.g("tracing-origins").iterator();
        while (it3.hasNext()) {
            tVar.e(it3.next());
        }
        Iterator<String> it4 = gVar.g("context-tags").iterator();
        while (it4.hasNext()) {
            tVar.a(it4.next());
        }
        tVar.J(gVar.b("proguard-uuid"));
        tVar.G(gVar.d("idle-timeout"));
        for (String str : gVar.g("ignored-exceptions-for-type")) {
            try {
                Class<?> cls = Class.forName(str);
                if (Throwable.class.isAssignableFrom(cls)) {
                    tVar.b(cls);
                } else {
                    f0Var.a(i3.WARNING, "Skipping setting %s as ignored-exception-for-type. Reason: %s does not extend Throwable", str, str);
                }
            } catch (ClassNotFoundException unused) {
                f0Var.a(i3.WARNING, "Skipping setting %s as ignored-exception-for-type. Reason: %s class is not found", str, str);
            }
        }
        return tVar;
    }

    public void A(Boolean bool) {
        this.g = bool;
    }

    public void B(String str) {
        this.d = str;
    }

    public void C(String str) {
        this.a = str;
    }

    public void D(Boolean bool) {
        this.h = bool;
    }

    public void E(Boolean bool) {
        this.f = bool;
    }

    public void F(String str) {
        this.b = str;
    }

    public void G(Long l) {
        this.r = l;
    }

    public void H(j3$d j3_d) {
        this.j = j3_d;
    }

    public void I(Boolean bool) {
        this.t = bool;
    }

    public void J(String str) {
        this.q = str;
    }

    public void K(j3$c j3_c) {
        this.l = j3_c;
    }

    public void L(String str) {
        this.c = str;
    }

    public void M(Boolean bool) {
        this.u = bool;
    }

    public void N(String str) {
        this.e = str;
    }

    public void O(String str, String str2) {
        this.k.put(str, str2);
    }

    public void P(Double d) {
        this.i = d;
    }

    public void a(String str) {
        this.p.add(str);
    }

    public void b(Class<? extends Throwable> cls) {
        this.s.add(cls);
    }

    public void c(String str) {
        this.m.add(str);
    }

    public void d(String str) {
        this.n.add(str);
    }

    public void e(String str) {
        this.o.add(str);
    }

    public List<String> g() {
        return this.p;
    }

    public Boolean h() {
        return this.g;
    }

    public String i() {
        return this.d;
    }

    public String j() {
        return this.a;
    }

    public Boolean k() {
        return this.h;
    }

    public Boolean l() {
        return this.f;
    }

    public String m() {
        return this.b;
    }

    public Long n() {
        return this.r;
    }

    public Set<Class<? extends Throwable>> o() {
        return this.s;
    }

    public List<String> p() {
        return this.m;
    }

    public List<String> q() {
        return this.n;
    }

    public Boolean r() {
        return this.t;
    }

    public String s() {
        return this.q;
    }

    public j3$c t() {
        return this.l;
    }

    public String u() {
        return this.c;
    }

    public Boolean v() {
        return this.u;
    }

    public String w() {
        return this.e;
    }

    public Map<String, String> x() {
        return this.k;
    }

    public Double y() {
        return this.i;
    }

    public List<String> z() {
        return this.o;
    }
}
