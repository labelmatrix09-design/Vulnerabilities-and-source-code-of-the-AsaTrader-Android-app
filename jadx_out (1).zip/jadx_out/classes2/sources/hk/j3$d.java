package hk;

/* JADX INFO: compiled from: SentryOptions.java */
/* JADX INFO: loaded from: /home/kali/Desktop/bunt/agah/dex_files/classes2.dex */
public enum j3$d {
    NONE,
    SMALL,
    MEDIUM,
    ALWAYS
}
