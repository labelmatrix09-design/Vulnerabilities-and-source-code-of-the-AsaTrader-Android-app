package hk;

import java.util.Deque;
import java.util.Iterator;
import java.util.concurrent.LinkedBlockingDeque;

/* JADX INFO: compiled from: Stack.java */
/* JADX INFO: loaded from: /home/kali/Desktop/bunt/agah/dex_files/classes2.dex */
public final class b4 {
    public final Deque<a> a;
    public final f0 b;

    public b4(f0 f0Var, a aVar) {
        LinkedBlockingDeque linkedBlockingDeque = new LinkedBlockingDeque();
        this.a = linkedBlockingDeque;
        this.b = (f0) rk.j.a(f0Var, "logger is required");
        linkedBlockingDeque.push((a) rk.j.a(aVar, "rootStackItem is required"));
    }

    public a a() {
        return this.a.peek();
    }

    public void b(a aVar) {
        this.a.push(aVar);
    }

    /* JADX INFO: compiled from: Stack.java */
    public static final class a {
        public final j3 a;
        public volatile h0 b;
        public volatile w1 c;

        public a(j3 j3Var, h0 h0Var, w1 w1Var) {
            this.b = (h0) rk.j.a(h0Var, "ISentryClient is required.");
            this.c = (w1) rk.j.a(w1Var, "Scope is required.");
            this.a = (j3) rk.j.a(j3Var, "Options is required");
        }

        public h0 a() {
            return this.b;
        }

        public j3 b() {
            return this.a;
        }

        public w1 c() {
            return this.c;
        }

        public a(a aVar) {
            this.a = aVar.a;
            this.b = aVar.b;
            this.c = new w1(aVar.c);
        }
    }

    public b4(b4 b4Var) {
        this(b4Var.b, new a(b4Var.a.getLast()));
        Iterator<a> itDescendingIterator = b4Var.a.descendingIterator();
        if (itDescendingIterator.hasNext()) {
            itDescendingIterator.next();
        }
        while (itDescendingIterator.hasNext()) {
            b(new a(itDescendingIterator.next()));
        }
    }
}
