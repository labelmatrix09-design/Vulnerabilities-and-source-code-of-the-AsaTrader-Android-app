package hk;

/* JADX INFO: compiled from: Integration.java */
/* JADX INFO: loaded from: /home/kali/Desktop/bunt/agah/dex_files/classes2.dex */
public interface o0 {
    void a(e0 e0Var, j3 j3Var);
}
