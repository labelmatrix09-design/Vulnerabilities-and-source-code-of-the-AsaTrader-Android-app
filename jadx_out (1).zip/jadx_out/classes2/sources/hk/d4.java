package hk;

import java.util.Queue;

/* JADX INFO: compiled from: SynchronizedQueue.java */
/* JADX INFO: loaded from: /home/kali/Desktop/bunt/agah/dex_files/classes2.dex */
public final class d4<E> extends c4<E> implements Queue<E> {
    public d4(Queue<E> queue) {
        super(queue);
    }

    public static <E> d4<E> e(Queue<E> queue) {
        return new d4<>(queue);
    }

    @Override // hk.c4
    /* JADX INFO: renamed from: d, reason: merged with bridge method [inline-methods] */
    public Queue<E> c() {
        return (Queue) super.c();
    }

    @Override // java.util.Queue
    public E element() {
        E eElement;
        synchronized (this.p) {
            eElement = c().element();
        }
        return eElement;
    }

    @Override // java.util.Collection
    public boolean equals(Object obj) {
        boolean zEquals;
        if (obj == this) {
            return true;
        }
        synchronized (this.p) {
            zEquals = c().equals(obj);
        }
        return zEquals;
    }

    @Override // java.util.Collection
    public int hashCode() {
        int iHashCode;
        synchronized (this.p) {
            iHashCode = c().hashCode();
        }
        return iHashCode;
    }

    @Override // java.util.Queue
    public boolean offer(E e) {
        boolean zOffer;
        synchronized (this.p) {
            zOffer = c().offer(e);
        }
        return zOffer;
    }

    @Override // java.util.Queue
    public E peek() {
        E ePeek;
        synchronized (this.p) {
            ePeek = c().peek();
        }
        return ePeek;
    }

    @Override // java.util.Queue
    public E poll() {
        E ePoll;
        synchronized (this.p) {
            ePoll = c().poll();
        }
        return ePoll;
    }

    @Override // java.util.Queue
    public E remove() {
        E eRemove;
        synchronized (this.p) {
            eRemove = c().remove();
        }
        return eRemove;
    }
}
