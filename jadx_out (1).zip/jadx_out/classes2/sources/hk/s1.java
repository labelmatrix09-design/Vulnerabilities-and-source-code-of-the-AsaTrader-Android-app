package hk;

import io.github.inflationx.calligraphy3.BuildConfig;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.Callable;
import java.util.concurrent.ConcurrentHashMap;
import org.jetbrains.annotations.ApiStatus;

/* JADX INFO: compiled from: ProfilingTraceData.java */
/* JADX INFO: loaded from: /home/kali/Desktop/bunt/agah/dex_files/classes2.dex */
@ApiStatus.Internal
public final class s1 implements z0 {
    public String A;
    public String B;
    public String C;
    public String D;
    public String E;
    public String F;
    public String G;
    public String H;
    public String I;
    public String J;
    public String K;
    public Map<String, Object> L;
    public File o;
    public Callable<List<Integer>> p;
    public int q;
    public String r;
    public String s;
    public String t;
    public String u;
    public String v;
    public String w;
    public boolean x;
    public List<Integer> y;
    public String z;

    /* JADX INFO: compiled from: ProfilingTraceData.java */
    public static final class b implements p0<s1> {
        /* JADX WARN: Multi-variable type inference failed */
        @Override // hk.p0
        /* JADX INFO: renamed from: b, reason: merged with bridge method [inline-methods] */
        public s1 a(v0 v0Var, f0 f0Var) throws IOException {
            v0Var.b();
            ConcurrentHashMap concurrentHashMap = null;
            s1 s1Var = new s1();
            while (v0Var.V() == uk.b.NAME) {
                String strF = v0Var.F();
                strF.hashCode();
                switch (strF) {
                    case "device_manufacturer":
                        String strS0 = v0Var.S0();
                        if (strS0 == null) {
                            break;
                        } else {
                            s1Var.s = strS0;
                            break;
                        }
                        break;
                    case "android_api_level":
                        Integer numM0 = v0Var.M0();
                        if (numM0 == null) {
                            break;
                        } else {
                            s1Var.q = numM0.intValue();
                            break;
                        }
                        break;
                    case "build_id":
                        String strS1 = v0Var.S0();
                        if (strS1 == null) {
                            break;
                        } else {
                            s1Var.B = strS1;
                            break;
                        }
                        break;
                    case "device_locale":
                        String strS2 = v0Var.S0();
                        if (strS2 == null) {
                            break;
                        } else {
                            s1Var.r = strS2;
                            break;
                        }
                        break;
                    case "profile_id":
                        String strS3 = v0Var.S0();
                        if (strS3 == null) {
                            break;
                        } else {
                            s1Var.I = strS3;
                            break;
                        }
                        break;
                    case "device_os_build_number":
                        String strS4 = v0Var.S0();
                        if (strS4 == null) {
                            break;
                        } else {
                            s1Var.u = strS4;
                            break;
                        }
                        break;
                    case "device_model":
                        String strS5 = v0Var.S0();
                        if (strS5 == null) {
                            break;
                        } else {
                            s1Var.t = strS5;
                            break;
                        }
                        break;
                    case "device_is_emulator":
                        Boolean boolW0 = v0Var.w0();
                        if (boolW0 == null) {
                            break;
                        } else {
                            s1Var.x = boolW0.booleanValue();
                            break;
                        }
                        break;
                    case "duration_ns":
                        String strS6 = v0Var.S0();
                        if (strS6 == null) {
                            break;
                        } else {
                            s1Var.D = strS6;
                            break;
                        }
                        break;
                    case "device_physical_memory_bytes":
                        String strS7 = v0Var.S0();
                        if (strS7 == null) {
                            break;
                        } else {
                            s1Var.z = strS7;
                            break;
                        }
                        break;
                    case "device_cpu_frequencies":
                        List list = (List) v0Var.Q0();
                        if (list == null) {
                            break;
                        } else {
                            s1Var.y = list;
                            break;
                        }
                        break;
                    case "version_code":
                        String strS8 = v0Var.S0();
                        if (strS8 == null) {
                            break;
                        } else {
                            s1Var.F = strS8;
                            break;
                        }
                        break;
                    case "version_name":
                        String strS9 = v0Var.S0();
                        if (strS9 == null) {
                            break;
                        } else {
                            s1Var.E = strS9;
                            break;
                        }
                        break;
                    case "environment":
                        String strS10 = v0Var.S0();
                        if (strS10 == null) {
                            break;
                        } else {
                            s1Var.J = strS10;
                            break;
                        }
                        break;
                    case "transaction_name":
                        String strS11 = v0Var.S0();
                        if (strS11 == null) {
                            break;
                        } else {
                            s1Var.C = strS11;
                            break;
                        }
                        break;
                    case "device_os_name":
                        String strS12 = v0Var.S0();
                        if (strS12 == null) {
                            break;
                        } else {
                            s1Var.v = strS12;
                            break;
                        }
                        break;
                    case "transaction_id":
                        String strS13 = v0Var.S0();
                        if (strS13 == null) {
                            break;
                        } else {
                            s1Var.G = strS13;
                            break;
                        }
                        break;
                    case "device_os_version":
                        String strS14 = v0Var.S0();
                        if (strS14 == null) {
                            break;
                        } else {
                            s1Var.w = strS14;
                            break;
                        }
                        break;
                    case "trace_id":
                        String strS15 = v0Var.S0();
                        if (strS15 == null) {
                            break;
                        } else {
                            s1Var.H = strS15;
                            break;
                        }
                        break;
                    case "platform":
                        String strS16 = v0Var.S0();
                        if (strS16 == null) {
                            break;
                        } else {
                            s1Var.A = strS16;
                            break;
                        }
                        break;
                    case "sampled_profile":
                        String strS17 = v0Var.S0();
                        if (strS17 == null) {
                            break;
                        } else {
                            s1Var.K = strS17;
                            break;
                        }
                        break;
                    default:
                        if (concurrentHashMap == null) {
                            concurrentHashMap = new ConcurrentHashMap();
                        }
                        v0Var.V0(f0Var, concurrentHashMap, strF);
                        break;
                }
            }
            s1Var.B(concurrentHashMap);
            v0Var.m();
            return s1Var;
        }
    }

    public static /* synthetic */ List y() {
        return new ArrayList();
    }

    public void A(String str) {
        this.K = str;
    }

    public void B(Map<String, Object> map) {
        this.L = map;
    }

    public void serialize(x0 x0Var, f0 f0Var) throws IOException {
        x0Var.g();
        x0Var.b0("android_api_level").d0(f0Var, Integer.valueOf(this.q));
        x0Var.b0("device_locale").d0(f0Var, this.r);
        x0Var.b0("device_manufacturer").V(this.s);
        x0Var.b0("device_model").V(this.t);
        x0Var.b0("device_os_build_number").V(this.u);
        x0Var.b0("device_os_name").V(this.v);
        x0Var.b0("device_os_version").V(this.w);
        x0Var.b0("device_is_emulator").Y(this.x);
        x0Var.b0("device_cpu_frequencies").d0(f0Var, this.y);
        x0Var.b0("device_physical_memory_bytes").V(this.z);
        x0Var.b0("platform").V(this.A);
        x0Var.b0("build_id").V(this.B);
        x0Var.b0("transaction_name").V(this.C);
        x0Var.b0("duration_ns").V(this.D);
        x0Var.b0("version_name").V(this.E);
        x0Var.b0("version_code").V(this.F);
        x0Var.b0("transaction_id").V(this.G);
        x0Var.b0("trace_id").V(this.H);
        x0Var.b0("profile_id").V(this.I);
        x0Var.b0("environment").V(this.J);
        if (this.K != null) {
            x0Var.b0("sampled_profile").V(this.K);
        }
        Map<String, Object> map = this.L;
        if (map != null) {
            for (String str : map.keySet()) {
                Object obj = this.L.get(str);
                x0Var.b0(str);
                x0Var.d0(f0Var, obj);
            }
        }
        x0Var.m();
    }

    public File w() {
        return this.o;
    }

    public String x() {
        return this.H;
    }

    public void z() {
        try {
            Callable<List<Integer>> callable = this.p;
            if (callable != null) {
                this.y = callable.call();
            }
        } catch (Throwable unused) {
        }
    }

    public s1() {
        this(new File("dummy"), k1.k());
    }

    public s1(File file, l0 l0Var) {
        this(file, l0Var, "0", 0, new Callable() { // from class: hk.r1
            @Override // java.util.concurrent.Callable
            public final Object call() {
                return s1.y();
            }
        }, null, null, null, null, null, null, null, null, null);
    }

    public s1(File file, l0 l0Var, String str, int i, Callable<List<Integer>> callable, String str2, String str3, String str4, Boolean bool, String str5, String str6, String str7, String str8, String str9) {
        this.y = new ArrayList();
        this.K = null;
        this.o = file;
        this.p = callable;
        this.q = i;
        this.r = Locale.getDefault().toString();
        this.s = str2 == null ? BuildConfig.FLAVOR : str2;
        this.t = str3 == null ? BuildConfig.FLAVOR : str3;
        this.w = str4 == null ? BuildConfig.FLAVOR : str4;
        this.x = bool != null ? bool.booleanValue() : false;
        this.z = str5 == null ? "0" : str5;
        this.u = BuildConfig.FLAVOR;
        this.v = "android";
        this.A = "android";
        this.B = str6 == null ? BuildConfig.FLAVOR : str6;
        this.C = l0Var.getName();
        this.D = str;
        this.E = str7 == null ? BuildConfig.FLAVOR : str7;
        this.F = str8 == null ? BuildConfig.FLAVOR : str8;
        this.G = l0Var.f().toString();
        this.H = l0Var.h().h().toString();
        this.I = UUID.randomUUID().toString();
        this.J = str9 == null ? BuildConfig.FLAVOR : str9;
    }
}
