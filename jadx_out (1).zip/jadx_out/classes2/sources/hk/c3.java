package hk;

import io.sentry.exception.SentryEnvelopeException;
import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.nio.charset.Charset;
import java.util.concurrent.Callable;
import org.jetbrains.annotations.ApiStatus;

/* JADX INFO: compiled from: SentryEnvelopeItem.java */
/* JADX INFO: loaded from: /home/kali/Desktop/bunt/agah/dex_files/classes2.dex */
@ApiStatus.Internal
public final class c3 {
    public static final Charset d = Charset.forName("UTF-8");
    public final d3 a;
    public final Callable<byte[]> b;
    public byte[] c;

    /* JADX INFO: compiled from: SentryEnvelopeItem.java */
    public static class a {
        public byte[] a;
        public final Callable<byte[]> b;

        public a(Callable<byte[]> callable) {
            this.b = callable;
        }

        public static byte[] b(byte[] bArr) {
            return bArr != null ? bArr : new byte[0];
        }

        public byte[] a() {
            Callable<byte[]> callable;
            if (this.a == null && (callable = this.b) != null) {
                this.a = callable.call();
            }
            return b(this.a);
        }
    }

    public c3(d3 d3Var, byte[] bArr) {
        this.a = (d3) rk.j.a(d3Var, "SentryEnvelopeItemHeader is required.");
        this.c = bArr;
        this.b = null;
    }

    public static /* synthetic */ byte[] A(j0 j0Var, mk.b bVar) throws IOException {
        ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
        try {
            BufferedWriter bufferedWriter = new BufferedWriter(new OutputStreamWriter(byteArrayOutputStream, d));
            try {
                j0Var.a(bVar, bufferedWriter);
                byte[] byteArray = byteArrayOutputStream.toByteArray();
                bufferedWriter.close();
                byteArrayOutputStream.close();
                return byteArray;
            } catch (Throwable th2) {
                try {
                    bufferedWriter.close();
                } catch (Throwable unused) {
                }
                throw th2;
            }
        } catch (Throwable th3) {
            try {
                byteArrayOutputStream.close();
            } catch (Throwable unused2) {
            }
            throw th3;
        }
    }

    public static /* synthetic */ Integer B(a aVar) {
        return Integer.valueOf(aVar.a().length);
    }

    public static /* synthetic */ byte[] D(j0 j0Var, g2 g2Var) throws IOException {
        ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
        try {
            BufferedWriter bufferedWriter = new BufferedWriter(new OutputStreamWriter(byteArrayOutputStream, d));
            try {
                j0Var.a(g2Var, bufferedWriter);
                byte[] byteArray = byteArrayOutputStream.toByteArray();
                bufferedWriter.close();
                byteArrayOutputStream.close();
                return byteArray;
            } catch (Throwable th2) {
                try {
                    bufferedWriter.close();
                } catch (Throwable unused) {
                }
                throw th2;
            }
        } catch (Throwable th3) {
            try {
                byteArrayOutputStream.close();
            } catch (Throwable unused2) {
            }
            throw th3;
        }
    }

    public static /* synthetic */ Integer E(a aVar) {
        return Integer.valueOf(aVar.a().length);
    }

    public static /* synthetic */ byte[] G(File file, long j, s1 s1Var, j0 j0Var) throws SentryEnvelopeException {
        if (!file.exists()) {
            throw new SentryEnvelopeException(String.format("Dropping profiling trace data, because the file '%s' doesn't exists", file.getName()));
        }
        s1Var.A(sk.a.c(M(file.getPath(), j), 3));
        s1Var.z();
        try {
            try {
                ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
                try {
                    BufferedWriter bufferedWriter = new BufferedWriter(new OutputStreamWriter(byteArrayOutputStream, d));
                    try {
                        j0Var.a(s1Var, bufferedWriter);
                        byte[] byteArray = byteArrayOutputStream.toByteArray();
                        bufferedWriter.close();
                        byteArrayOutputStream.close();
                        file.delete();
                        return byteArray;
                    } catch (Throwable th2) {
                        try {
                            bufferedWriter.close();
                        } catch (Throwable unused) {
                        }
                        throw th2;
                    }
                } catch (Throwable th3) {
                    try {
                        byteArrayOutputStream.close();
                    } catch (Throwable unused2) {
                    }
                    throw th3;
                }
            } catch (IOException e) {
                throw new SentryEnvelopeException(String.format("Failed to serialize profiling trace data\n%s", e.getMessage()));
            }
        } catch (Throwable th4) {
            file.delete();
            throw th4;
        }
    }

    public static /* synthetic */ Integer H(a aVar) {
        return Integer.valueOf(aVar.a().length);
    }

    public static /* synthetic */ byte[] J(j0 j0Var, t3 t3Var) throws IOException {
        ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
        try {
            BufferedWriter bufferedWriter = new BufferedWriter(new OutputStreamWriter(byteArrayOutputStream, d));
            try {
                j0Var.a(t3Var, bufferedWriter);
                byte[] byteArray = byteArrayOutputStream.toByteArray();
                bufferedWriter.close();
                byteArrayOutputStream.close();
                return byteArray;
            } catch (Throwable th2) {
                try {
                    bufferedWriter.close();
                } catch (Throwable unused) {
                }
                throw th2;
            }
        } catch (Throwable th3) {
            try {
                byteArrayOutputStream.close();
            } catch (Throwable unused2) {
            }
            throw th3;
        }
    }

    public static /* synthetic */ Integer K(a aVar) {
        return Integer.valueOf(aVar.a().length);
    }

    public static byte[] M(String str, long j) throws SentryEnvelopeException {
        try {
            File file = new File(str);
            if (!file.isFile()) {
                throw new SentryEnvelopeException(String.format("Reading the item %s failed, because the file located at the path is not a file.", str));
            }
            if (!file.canRead()) {
                throw new SentryEnvelopeException(String.format("Reading the item %s failed, because can't read the file.", str));
            }
            if (file.length() > j) {
                throw new SentryEnvelopeException(String.format("Dropping item, because its size located at '%s' with %d bytes is bigger than the maximum allowed size of %d bytes.", str, Long.valueOf(file.length()), Long.valueOf(j)));
            }
            FileInputStream fileInputStream = new FileInputStream(str);
            try {
                BufferedInputStream bufferedInputStream = new BufferedInputStream(fileInputStream);
                try {
                    ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
                    try {
                        byte[] bArr = new byte[1024];
                        while (true) {
                            int i = bufferedInputStream.read(bArr);
                            if (i == -1) {
                                byte[] byteArray = byteArrayOutputStream.toByteArray();
                                byteArrayOutputStream.close();
                                bufferedInputStream.close();
                                fileInputStream.close();
                                return byteArray;
                            }
                            byteArrayOutputStream.write(bArr, 0, i);
                        }
                    } catch (Throwable th2) {
                        try {
                            byteArrayOutputStream.close();
                        } catch (Throwable unused) {
                        }
                        throw th2;
                    }
                } catch (Throwable th3) {
                    try {
                        bufferedInputStream.close();
                    } catch (Throwable unused2) {
                    }
                    throw th3;
                }
            } catch (Throwable th4) {
                try {
                    fileInputStream.close();
                } catch (Throwable unused3) {
                }
                throw th4;
            }
        } catch (IOException | SecurityException e) {
            throw new SentryEnvelopeException(String.format("Reading the item %s failed.\n%s", str, e.getMessage()));
        }
    }

    public static c3 p(final b bVar, final long j) {
        final a aVar = new a(new Callable() { // from class: hk.n2
            @Override // java.util.concurrent.Callable
            public final Object call() {
                return c3.z(bVar, j);
            }
        });
        return new c3(new d3(h3.Attachment, (Callable<Integer>) new Callable() { // from class: hk.y2
            @Override // java.util.concurrent.Callable
            public final Object call() {
                return c3.x(aVar);
            }
        }, bVar.d(), bVar.e(), bVar.b()), (Callable<byte[]>) new Callable() { // from class: hk.a3
            @Override // java.util.concurrent.Callable
            public final Object call() {
                return aVar.a();
            }
        });
    }

    public static c3 q(final j0 j0Var, final mk.b bVar) {
        rk.j.a(j0Var, "ISerializer is required.");
        rk.j.a(bVar, "ClientReport is required.");
        final a aVar = new a(new Callable() { // from class: hk.v2
            @Override // java.util.concurrent.Callable
            public final Object call() {
                return c3.A(j0Var, bVar);
            }
        });
        return new c3(new d3(h3.resolve(bVar), new Callable() { // from class: hk.w2
            @Override // java.util.concurrent.Callable
            public final Object call() {
                return c3.B(aVar);
            }
        }, "application/json", null), (Callable<byte[]>) new Callable() { // from class: hk.z2
            @Override // java.util.concurrent.Callable
            public final Object call() {
                return aVar.a();
            }
        });
    }

    public static c3 r(final j0 j0Var, final g2 g2Var) {
        rk.j.a(j0Var, "ISerializer is required.");
        rk.j.a(g2Var, "SentryEvent is required.");
        final a aVar = new a(new Callable() { // from class: hk.t2
            @Override // java.util.concurrent.Callable
            public final Object call() {
                return c3.D(j0Var, g2Var);
            }
        });
        return new c3(new d3(h3.resolve(g2Var), new Callable() { // from class: hk.q2
            @Override // java.util.concurrent.Callable
            public final Object call() {
                return c3.E(aVar);
            }
        }, "application/json", null), (Callable<byte[]>) new Callable() { // from class: hk.o2
            @Override // java.util.concurrent.Callable
            public final Object call() {
                return aVar.a();
            }
        });
    }

    public static c3 s(final s1 s1Var, final long j, final j0 j0Var) {
        final File fileW = s1Var.w();
        final a aVar = new a(new Callable() { // from class: hk.s2
            @Override // java.util.concurrent.Callable
            public final Object call() {
                return c3.G(fileW, j, s1Var, j0Var);
            }
        });
        return new c3(new d3(h3.Profile, new Callable() { // from class: hk.b3
            @Override // java.util.concurrent.Callable
            public final Object call() {
                return c3.H(aVar);
            }
        }, "application-json", fileW.getName()), (Callable<byte[]>) new Callable() { // from class: hk.x2
            @Override // java.util.concurrent.Callable
            public final Object call() {
                return aVar.a();
            }
        });
    }

    public static c3 t(final j0 j0Var, final t3 t3Var) {
        rk.j.a(j0Var, "ISerializer is required.");
        rk.j.a(t3Var, "Session is required.");
        final a aVar = new a(new Callable() { // from class: hk.u2
            @Override // java.util.concurrent.Callable
            public final Object call() {
                return c3.J(j0Var, t3Var);
            }
        });
        return new c3(new d3(h3.Session, new Callable() { // from class: hk.r2
            @Override // java.util.concurrent.Callable
            public final Object call() {
                return c3.K(aVar);
            }
        }, "application/json", null), (Callable<byte[]>) new Callable() { // from class: hk.p2
            @Override // java.util.concurrent.Callable
            public final Object call() {
                return aVar.a();
            }
        });
    }

    public static /* synthetic */ Integer x(a aVar) {
        return Integer.valueOf(aVar.a().length);
    }

    public static /* synthetic */ byte[] z(b bVar, long j) throws SentryEnvelopeException {
        if (bVar.c() != null) {
            if (bVar.c().length <= j) {
                return bVar.c();
            }
            throw new SentryEnvelopeException(String.format("Dropping attachment with filename '%s', because the size of the passed bytes with %d bytes is bigger than the maximum allowed attachment size of %d bytes.", bVar.e(), Integer.valueOf(bVar.c().length), Long.valueOf(j)));
        }
        if (bVar.f() != null) {
            return M(bVar.f(), j);
        }
        throw new SentryEnvelopeException(String.format("Couldn't attach the attachment %s.\nPlease check that either bytes or a path is set.", bVar.e()));
    }

    public mk.b u(j0 j0Var) throws IOException {
        d3 d3Var = this.a;
        if (d3Var == null || d3Var.b() != h3.ClientReport) {
            return null;
        }
        BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(new ByteArrayInputStream(v()), d));
        try {
            mk.b bVar = (mk.b) j0Var.c(bufferedReader, mk.b.class);
            bufferedReader.close();
            return bVar;
        } catch (Throwable th2) {
            try {
                bufferedReader.close();
            } catch (Throwable unused) {
            }
            throw th2;
        }
    }

    public byte[] v() {
        Callable<byte[]> callable;
        if (this.c == null && (callable = this.b) != null) {
            this.c = callable.call();
        }
        return this.c;
    }

    public d3 w() {
        return this.a;
    }

    public c3(d3 d3Var, Callable<byte[]> callable) {
        this.a = (d3) rk.j.a(d3Var, "SentryEnvelopeItemHeader is required.");
        this.b = (Callable) rk.j.a(callable, "DataFactory is required.");
        this.c = null;
    }
}
