package hk;

import java.util.ArrayList;
import java.util.List;

/* JADX INFO: compiled from: SentryValues.java */
/* JADX INFO: loaded from: /home/kali/Desktop/bunt/agah/dex_files/classes2.dex */
public final class s3<T> {
    public final List<T> a;

    public s3(List<T> list) {
        this.a = new ArrayList(list == null ? new ArrayList<>(0) : list);
    }

    public List<T> a() {
        return this.a;
    }
}
