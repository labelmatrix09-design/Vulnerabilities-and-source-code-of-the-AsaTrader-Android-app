package hk;

import java.io.File;

/* JADX INFO: compiled from: SendCachedEnvelopeFireAndForgetIntegration.java */
/* JADX INFO: loaded from: /home/kali/Desktop/bunt/agah/dex_files/classes2.dex */
public final /* synthetic */ class b2 {
    public static boolean a(z1.c cVar, String str, f0 f0Var) {
        if (str != null) {
            return true;
        }
        f0Var.a(i3.INFO, "No cached dir path is defined in options.", new Object[0]);
        return false;
    }

    public static z1.a b(z1.c cVar, final j jVar, final String str, final f0 f0Var) {
        final File file = new File(str);
        return new z1.a() { // from class: hk.a2
            @Override // hk.z1.a
            public final void a() {
                b2.c(f0Var, str, jVar, file);
            }
        };
    }

    public static /* synthetic */ void c(f0 f0Var, String str, j jVar, File file) {
        i3 i3Var = i3.DEBUG;
        f0Var.a(i3Var, "Started processing cached files from %s", str);
        jVar.e(file);
        f0Var.a(i3Var, "Finished processing cached files from %s", str);
    }
}
