package hk;

import org.jetbrains.annotations.ApiStatus;

/* JADX INFO: compiled from: SentryCrashLastRunState.java */
/* JADX INFO: loaded from: /home/kali/Desktop/bunt/agah/dex_files/classes2.dex */
@ApiStatus.Internal
public final class k2 {
    public static final k2 d = new k2();
    public boolean a;
    public Boolean b;
    public final Object c = new Object();

    public static k2 a() {
        return d;
    }

    public void b(boolean z) {
        synchronized (this.c) {
            if (!this.a) {
                this.b = Boolean.valueOf(z);
                this.a = true;
            }
        }
    }
}
