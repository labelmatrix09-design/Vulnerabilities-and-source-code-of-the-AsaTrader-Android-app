package hk;

import java.io.File;
import java.util.Date;
import java.util.Iterator;
import org.jetbrains.annotations.ApiStatus;

/* JADX INFO: compiled from: Sentry.java */
/* JADX INFO: loaded from: /home/kali/Desktop/bunt/agah/dex_files/classes2.dex */
public final class f2 {
    public static final ThreadLocal<e0> a = new ThreadLocal<>();
    public static volatile e0 b = d1.a();
    public static volatile boolean c = false;

    public static void b(c cVar, u uVar) {
        i().l(cVar, uVar);
    }

    public static pk.m c(e3 e3Var, u uVar) {
        return i().i(e3Var, uVar);
    }

    public static pk.m d(Throwable th2, u uVar) {
        return i().o(th2, uVar);
    }

    public static synchronized void e() {
        e0 e0VarI = i();
        b = d1.a();
        a.remove();
        e0VarI.close();
    }

    public static void f(x1 x1Var) {
        i().f(x1Var);
    }

    public static void g() {
        i().p();
    }

    public static void h(long j) {
        i().c(j);
    }

    @ApiStatus.Internal
    public static e0 i() {
        if (c) {
            return b;
        }
        ThreadLocal<e0> threadLocal = a;
        e0 e0Var = threadLocal.get();
        if (e0Var != null && !(e0Var instanceof d1)) {
            return e0Var;
        }
        e0 e0VarM2clone = b.m2clone();
        threadLocal.set(e0VarM2clone);
        return e0VarM2clone;
    }

    public static <T extends j3> void j(n1<T> n1Var, a<T> aVar, boolean z) {
        T tB = n1Var.b();
        aVar.a(tB);
        k(tB, z);
    }

    public static synchronized void k(j3 j3Var, boolean z) {
        if (m()) {
            j3Var.getLogger().a(i3.WARNING, "Sentry has been already initialized. Previous configuration will be overwritten.", new Object[0]);
        }
        if (l(j3Var)) {
            j3Var.getLogger().a(i3.INFO, "GlobalHubMode: '%s'", String.valueOf(z));
            c = z;
            e0 e0VarI = i();
            b = new z(j3Var);
            a.set(b);
            e0VarI.close();
            Iterator it = j3Var.getIntegrations().iterator();
            while (it.hasNext()) {
                ((o0) it.next()).a(a0.a(), j3Var);
            }
        }
    }

    public static boolean l(j3 j3Var) {
        if (j3Var.isEnableExternalConfiguration()) {
            j3Var.merge(t.f(nk.h.a(), j3Var.getLogger()));
        }
        String dsn = j3Var.getDsn();
        if (dsn == null) {
            throw new IllegalArgumentException("DSN is required. Use empty string to disable SDK.");
        }
        if (dsn.isEmpty()) {
            e();
            return false;
        }
        new k(dsn);
        f0 logger = j3Var.getLogger();
        if (j3Var.isDebug() && (logger instanceof e1)) {
            j3Var.setLogger(new e4());
            logger = j3Var.getLogger();
        }
        i3 i3Var = i3.INFO;
        logger.a(i3Var, "Initializing SDK with DSN: '%s'", j3Var.getDsn());
        String outboxPath = j3Var.getOutboxPath();
        if (outboxPath != null) {
            new File(outboxPath).mkdirs();
        } else {
            logger.a(i3Var, "No outbox dir path is defined in options.", new Object[0]);
        }
        String cacheDirPath = j3Var.getCacheDirPath();
        if (cacheDirPath != null) {
            new File(cacheDirPath).mkdirs();
            j3Var.setEnvelopeDiskCache(lk.d.v(j3Var));
        }
        String profilingTracesDirPath = j3Var.getProfilingTracesDirPath();
        if (j3Var.isProfilingEnabled() && profilingTracesDirPath != null) {
            File file = new File(profilingTracesDirPath);
            file.mkdirs();
            final File[] fileArrListFiles = file.listFiles();
            j3Var.getExecutorService().submit(new Runnable() { // from class: hk.e2
                @Override // java.lang.Runnable
                public final void run() {
                    f2.n(fileArrListFiles);
                }
            });
        }
        return true;
    }

    public static boolean m() {
        return i().isEnabled();
    }

    public static /* synthetic */ void n(File[] fileArr) {
        if (fileArr == null) {
            return;
        }
        for (File file : fileArr) {
            rk.c.a(file);
        }
    }

    public static void o() {
        i().q();
    }

    @ApiStatus.Internal
    public static l0 p(h4 h4Var, e eVar, boolean z, Date date, boolean z4, Long l, boolean z5, i4 i4Var) {
        return i().m(h4Var, eVar, z, date, z4, l, z5, i4Var);
    }
}
