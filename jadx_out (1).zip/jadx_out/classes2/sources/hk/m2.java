package hk;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import org.jetbrains.annotations.ApiStatus;

/* JADX INFO: compiled from: SentryEnvelopeHeader.java */
/* JADX INFO: loaded from: /home/kali/Desktop/bunt/agah/dex_files/classes2.dex */
@ApiStatus.Internal
public final class m2 implements z0 {
    public final pk.m o;
    public final pk.k p;
    public final f4 q;
    public Map<String, Object> r;

    /* JADX INFO: compiled from: SentryEnvelopeHeader.java */
    public static final class a implements p0<m2> {
        @Override // hk.p0
        /* JADX INFO: renamed from: b, reason: merged with bridge method [inline-methods] */
        public m2 a(v0 v0Var, f0 f0Var) throws IOException {
            v0Var.b();
            pk.m mVar = null;
            pk.k kVar = null;
            f4 f4Var = null;
            HashMap map = null;
            while (v0Var.V() == uk.b.NAME) {
                String strF = v0Var.F();
                strF.hashCode();
                switch (strF) {
                    case "sdk":
                        kVar = (pk.k) v0Var.R0(f0Var, new pk.k.a());
                        break;
                    case "trace":
                        f4Var = (f4) v0Var.R0(f0Var, new f4.a());
                        break;
                    case "event_id":
                        mVar = (pk.m) v0Var.R0(f0Var, new pk.m.a());
                        break;
                    default:
                        if (map == null) {
                            map = new HashMap();
                        }
                        v0Var.V0(f0Var, map, strF);
                        break;
                }
            }
            m2 m2Var = new m2(mVar, kVar, f4Var);
            m2Var.d(map);
            v0Var.m();
            return m2Var;
        }
    }

    public m2(pk.m mVar, pk.k kVar) {
        this(mVar, kVar, null);
    }

    public pk.m a() {
        return this.o;
    }

    public pk.k b() {
        return this.p;
    }

    public f4 c() {
        return this.q;
    }

    public void d(Map<String, Object> map) {
        this.r = map;
    }

    public void serialize(x0 x0Var, f0 f0Var) throws IOException {
        x0Var.g();
        if (this.o != null) {
            x0Var.b0("event_id").d0(f0Var, this.o);
        }
        if (this.p != null) {
            x0Var.b0("sdk").d0(f0Var, this.p);
        }
        if (this.q != null) {
            x0Var.b0("trace").d0(f0Var, this.q);
        }
        Map<String, Object> map = this.r;
        if (map != null) {
            for (String str : map.keySet()) {
                Object obj = this.r.get(str);
                x0Var.b0(str);
                x0Var.d0(f0Var, obj);
            }
        }
        x0Var.m();
    }

    public m2(pk.m mVar, pk.k kVar, f4 f4Var) {
        this.o = mVar;
        this.p = kVar;
        this.q = f4Var;
    }

    public m2(pk.m mVar) {
        this(mVar, null);
    }

    public m2() {
        this(new pk.m());
    }
}
