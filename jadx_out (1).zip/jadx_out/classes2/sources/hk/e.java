package hk;

/* JADX INFO: compiled from: CustomSamplingContext.java */
/* JADX INFO: loaded from: /home/kali/Desktop/bunt/agah/dex_files/classes2.dex */
public final class e {
}
