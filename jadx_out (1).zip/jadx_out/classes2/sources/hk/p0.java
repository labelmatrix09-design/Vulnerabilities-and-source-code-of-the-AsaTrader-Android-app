package hk;

import org.jetbrains.annotations.ApiStatus;

/* JADX INFO: compiled from: JsonDeserializer.java */
/* JADX INFO: loaded from: /home/kali/Desktop/bunt/agah/dex_files/classes2.dex */
@ApiStatus.Internal
public interface p0<T> {
    T a(v0 v0Var, f0 f0Var);
}
