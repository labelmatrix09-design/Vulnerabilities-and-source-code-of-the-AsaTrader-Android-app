package hk;

import java.io.InputStream;

/* JADX INFO: compiled from: IEnvelopeReader.java */
/* JADX INFO: loaded from: /home/kali/Desktop/bunt/agah/dex_files/classes2.dex */
public interface b0 {
    l2 a(InputStream inputStream);
}
