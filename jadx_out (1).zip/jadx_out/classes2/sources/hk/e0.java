package hk;

import java.util.Date;
import org.jetbrains.annotations.ApiStatus;

/* JADX INFO: compiled from: IHub.java */
/* JADX INFO: loaded from: /home/kali/Desktop/bunt/agah/dex_files/classes2.dex */
public interface e0 {
    void c(long j);

    e0 clone();

    void close();

    pk.m d(l2 l2Var, u uVar);

    void e(c cVar);

    void f(x1 x1Var);

    @ApiStatus.Internal
    pk.m g(pk.t tVar, f4 f4Var, u uVar);

    j3 h();

    pk.m i(e3 e3Var, u uVar);

    boolean isEnabled();

    @ApiStatus.Internal
    l0 j(String str, String str2, Date date, boolean z, i4 i4Var);

    pk.m k(Throwable th2);

    void l(c cVar, u uVar);

    @ApiStatus.Internal
    l0 m(h4 h4Var, e eVar, boolean z, Date date, boolean z4, Long l, boolean z5, i4 i4Var);

    @ApiStatus.Internal
    l0 n(String str, String str2, boolean z, Long l, boolean z4);

    pk.m o(Throwable th2, u uVar);

    void p();

    void q();

    @ApiStatus.Internal
    pk.m r(pk.t tVar, f4 f4Var, u uVar, s1 s1Var);

    @ApiStatus.Internal
    void s(Throwable th2, k0 k0Var, String str);
}
