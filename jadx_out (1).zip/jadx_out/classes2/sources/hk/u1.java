package hk;

import io.github.inflationx.calligraphy3.BuildConfig;
import java.net.URI;
import java.util.HashMap;

/* JADX INFO: compiled from: RequestDetailsResolver.java */
/* JADX INFO: loaded from: /home/kali/Desktop/bunt/agah/dex_files/classes2.dex */
public final class u1 {
    public final j3 a;

    public u1(j3 j3Var) {
        this.a = (j3) rk.j.a(j3Var, "options is required");
    }

    public t1 a() {
        String str;
        k kVar = new k(this.a.getDsn());
        URI uriC = kVar.c();
        String string = uriC.resolve(uriC.getPath() + "/envelope/").toString();
        String strA = kVar.a();
        String strB = kVar.b();
        StringBuilder sb = new StringBuilder();
        sb.append("Sentry sentry_version=7,sentry_client=");
        sb.append(this.a.getSentryClientName());
        sb.append(",sentry_key=");
        sb.append(strA);
        if (strB == null || strB.length() <= 0) {
            str = BuildConfig.FLAVOR;
        } else {
            str = ",sentry_secret=" + strB;
        }
        sb.append(str);
        String string2 = sb.toString();
        String sentryClientName = this.a.getSentryClientName();
        HashMap map = new HashMap();
        map.put("User-Agent", sentryClientName);
        map.put("X-Sentry-Auth", string2);
        return new t1(string, map);
    }
}
