package hk;

/* JADX INFO: compiled from: TransactionContext.java */
/* JADX INFO: loaded from: /home/kali/Desktop/bunt/agah/dex_files/classes2.dex */
public final class h4 extends x3 {
    public final String x;
    public Boolean y;

    public h4(String str, String str2) {
        super(str2);
        this.x = (String) rk.j.a(str, "name is required");
        this.y = null;
    }

    public String m() {
        return this.x;
    }

    public Boolean n() {
        return this.y;
    }
}
