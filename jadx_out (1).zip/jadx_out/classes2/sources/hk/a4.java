package hk;

import java.io.IOException;
import java.util.Locale;

/* JADX INFO: compiled from: SpanStatus.java */
/* JADX INFO: loaded from: /home/kali/Desktop/bunt/agah/dex_files/classes2.dex */
public enum a4 implements z0 {
    OK(200, 299),
    CANCELLED(499),
    INTERNAL_ERROR(500),
    UNKNOWN(500),
    UNKNOWN_ERROR(500),
    INVALID_ARGUMENT(400),
    DEADLINE_EXCEEDED(504),
    NOT_FOUND(404),
    ALREADY_EXISTS(409),
    PERMISSION_DENIED(403),
    RESOURCE_EXHAUSTED(429),
    FAILED_PRECONDITION(400),
    ABORTED(409),
    OUT_OF_RANGE(400),
    UNIMPLEMENTED(501),
    UNAVAILABLE(503),
    DATA_LOSS(500),
    UNAUTHENTICATED(401);

    private final int maxHttpStatusCode;
    private final int minHttpStatusCode;

    /* JADX INFO: compiled from: SpanStatus.java */
    public static final class a implements p0<a4> {
        @Override // hk.p0
        /* JADX INFO: renamed from: b, reason: merged with bridge method [inline-methods] */
        public a4 a(v0 v0Var, f0 f0Var) {
            return a4.valueOf(v0Var.N().toUpperCase(Locale.ROOT));
        }
    }

    a4(int i) {
        this.minHttpStatusCode = i;
        this.maxHttpStatusCode = i;
    }

    public static a4 fromHttpStatusCode(int i) {
        for (a4 a4Var : values()) {
            if (a4Var.matches(i)) {
                return a4Var;
            }
        }
        return null;
    }

    private boolean matches(int i) {
        return i >= this.minHttpStatusCode && i <= this.maxHttpStatusCode;
    }

    public void serialize(x0 x0Var, f0 f0Var) throws IOException {
        x0Var.V(name().toLowerCase(Locale.ROOT));
    }

    public static a4 fromHttpStatusCode(Integer num, a4 a4Var) {
        a4 a4VarFromHttpStatusCode = num != null ? fromHttpStatusCode(num.intValue()) : a4Var;
        return a4VarFromHttpStatusCode != null ? a4VarFromHttpStatusCode : a4Var;
    }

    a4(int i, int i3) {
        this.minHttpStatusCode = i;
        this.maxHttpStatusCode = i3;
    }
}
