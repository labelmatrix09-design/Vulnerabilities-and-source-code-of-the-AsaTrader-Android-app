package hk;

import io.sentry.exception.ExceptionMechanismException;
import java.io.Closeable;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;

/* JADX INFO: compiled from: UncaughtExceptionHandlerIntegration.java */
/* JADX INFO: loaded from: /home/kali/Desktop/bunt/agah/dex_files/classes2.dex */
public final class k4 implements o0, Thread.UncaughtExceptionHandler, Closeable {
    public Thread.UncaughtExceptionHandler o;
    public e0 p;
    public j3 q;
    public boolean r;
    public final j4 s;

    /* JADX INFO: compiled from: UncaughtExceptionHandlerIntegration.java */
    public static final class a implements ok.c, ok.d, ok.g {
        public final CountDownLatch a = new CountDownLatch(1);
        public final long b;
        public final f0 c;

        public a(long j, f0 f0Var) {
            this.b = j;
            this.c = f0Var;
        }

        @Override // ok.c
        public void a() {
            this.a.countDown();
        }

        @Override // ok.d
        public boolean e() {
            try {
                return this.a.await(this.b, TimeUnit.MILLISECONDS);
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                this.c.b(i3.ERROR, "Exception while awaiting for flush in UncaughtExceptionHint", e);
                return false;
            }
        }
    }

    public k4() {
        this(j4.a.c());
    }

    public static Throwable b(Thread thread, Throwable th2) {
        pk.g gVar = new pk.g();
        gVar.i(Boolean.FALSE);
        gVar.j("UncaughtExceptionHandler");
        return new ExceptionMechanismException(gVar, th2, thread);
    }

    @Override // hk.o0
    public final void a(e0 e0Var, j3 j3Var) {
        if (this.r) {
            j3Var.getLogger().a(i3.ERROR, "Attempt to register a UncaughtExceptionHandlerIntegration twice.", new Object[0]);
            return;
        }
        this.r = true;
        this.p = (e0) rk.j.a(e0Var, "Hub is required");
        j3 j3Var2 = (j3) rk.j.a(j3Var, "SentryOptions is required");
        this.q = j3Var2;
        f0 logger = j3Var2.getLogger();
        i3 i3Var = i3.DEBUG;
        logger.a(i3Var, "UncaughtExceptionHandlerIntegration enabled: %s", Boolean.valueOf(this.q.isEnableUncaughtExceptionHandler()));
        if (this.q.isEnableUncaughtExceptionHandler()) {
            Thread.UncaughtExceptionHandler uncaughtExceptionHandlerB = this.s.b();
            if (uncaughtExceptionHandlerB != null) {
                this.q.getLogger().a(i3Var, "default UncaughtExceptionHandler class='" + uncaughtExceptionHandlerB.getClass().getName() + "'", new Object[0]);
                this.o = uncaughtExceptionHandlerB;
            }
            this.s.a(this);
            this.q.getLogger().a(i3Var, "UncaughtExceptionHandlerIntegration installed.", new Object[0]);
        }
    }

    @Override // java.io.Closeable, java.lang.AutoCloseable
    public void close() {
        if (this == this.s.b()) {
            this.s.a(this.o);
            j3 j3Var = this.q;
            if (j3Var != null) {
                j3Var.getLogger().a(i3.DEBUG, "UncaughtExceptionHandlerIntegration removed.", new Object[0]);
            }
        }
    }

    @Override // java.lang.Thread.UncaughtExceptionHandler
    public void uncaughtException(Thread thread, Throwable th2) {
        j3 j3Var = this.q;
        if (j3Var == null || this.p == null) {
            return;
        }
        j3Var.getLogger().a(i3.INFO, "Uncaught exception received.", new Object[0]);
        try {
            a aVar = new a(this.q.getFlushTimeoutMillis(), this.q.getLogger());
            e3 e3Var = new e3(b(thread, th2));
            e3Var.x0(i3.FATAL);
            this.p.i(e3Var, rk.h.e(aVar));
            if (!aVar.e()) {
                this.q.getLogger().a(i3.WARNING, "Timed out waiting to flush event to disk before crashing. Event: %s", e3Var.E());
            }
        } catch (Throwable th3) {
            this.q.getLogger().b(i3.ERROR, "Error sending uncaught exception to Sentry.", th3);
        }
        if (this.o != null) {
            this.q.getLogger().a(i3.INFO, "Invoking inner uncaught exception handler.", new Object[0]);
            this.o.uncaughtException(thread, th2);
        } else if (this.q.isPrintUncaughtStackTrace()) {
            th2.printStackTrace();
        }
    }

    public k4(j4 j4Var) {
        this.r = false;
        this.s = (j4) rk.j.a(j4Var, "threadAdapter is required.");
    }
}
