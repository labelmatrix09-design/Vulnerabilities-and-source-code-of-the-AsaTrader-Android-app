package hk;

/* JADX INFO: compiled from: SendCachedEnvelopeFireAndForgetIntegration.java */
/* JADX INFO: loaded from: /home/kali/Desktop/bunt/agah/dex_files/classes2.dex */
public final class z1 implements o0 {
    public final c o;

    /* JADX INFO: compiled from: SendCachedEnvelopeFireAndForgetIntegration.java */
    public interface a {
        void a();
    }

    /* JADX INFO: compiled from: SendCachedEnvelopeFireAndForgetIntegration.java */
    public interface b {
        String a();
    }

    /* JADX INFO: compiled from: SendCachedEnvelopeFireAndForgetIntegration.java */
    public interface c {
        boolean a(String str, f0 f0Var);

        a b(e0 e0Var, j3 j3Var);
    }

    public z1(c cVar) {
        this.o = (c) rk.j.a(cVar, "SendFireAndForgetFactory is required");
    }

    public static /* synthetic */ void c(a aVar, j3 j3Var) {
        try {
            aVar.a();
        } catch (Throwable th2) {
            j3Var.getLogger().b(i3.ERROR, "Failed trying to send cached events.", th2);
        }
    }

    @Override // hk.o0
    public final void a(e0 e0Var, final j3 j3Var) {
        rk.j.a(e0Var, "Hub is required");
        rk.j.a(j3Var, "SentryOptions is required");
        if (!this.o.a(j3Var.getCacheDirPath(), j3Var.getLogger())) {
            j3Var.getLogger().a(i3.ERROR, "No cache dir path is defined in options.", new Object[0]);
            return;
        }
        final a aVarB = this.o.b(e0Var, j3Var);
        if (aVarB == null) {
            j3Var.getLogger().a(i3.ERROR, "SendFireAndForget factory is null.", new Object[0]);
            return;
        }
        try {
            j3Var.getExecutorService().submit(new Runnable() { // from class: hk.y1
                @Override // java.lang.Runnable
                public final void run() {
                    z1.c(aVarB, j3Var);
                }
            });
            j3Var.getLogger().a(i3.DEBUG, "SendCachedEventFireAndForgetIntegration installed.", new Object[0]);
        } catch (Throwable th2) {
            j3Var.getLogger().b(i3.ERROR, "Failed to call the executor. Cached events will not be sent", th2);
        }
    }
}
