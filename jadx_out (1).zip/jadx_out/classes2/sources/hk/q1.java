package hk;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.charset.Charset;
import org.jetbrains.annotations.ApiStatus;

/* JADX INFO: compiled from: OutboxSender.java */
/* JADX INFO: loaded from: /home/kali/Desktop/bunt/agah/dex_files/classes2.dex */
@ApiStatus.Internal
public final class q1 extends j implements c0 {
    public static final Charset g = Charset.forName("UTF-8");
    public final e0 c;
    public final b0 d;
    public final j0 e;
    public final f0 f;

    public q1(e0 e0Var, b0 b0Var, j0 j0Var, f0 f0Var, long j) {
        super(f0Var, j);
        this.c = (e0) rk.j.a(e0Var, "Hub is required.");
        this.d = (b0) rk.j.a(b0Var, "Envelope reader is required.");
        this.e = (j0) rk.j.a(j0Var, "Serializer is required.");
        this.f = (f0) rk.j.a(f0Var, "Logger is required.");
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void j(File file, ok.f fVar) {
        if (fVar.b()) {
            return;
        }
        try {
            if (file.delete()) {
                return;
            }
            this.f.a(i3.ERROR, "Failed to delete: %s", file.getAbsolutePath());
        } catch (RuntimeException e) {
            this.f.d(i3.ERROR, e, "Failed to delete: %s", file.getAbsolutePath());
        }
    }

    @Override // hk.c0
    public void a(String str, u uVar) {
        rk.j.a(str, "Path is required.");
        f(new File(str), uVar);
    }

    @Override // hk.j
    public boolean c(String str) {
        return (str == null || str.startsWith("session")) ? false : true;
    }

    @Override // hk.j
    public /* bridge */ /* synthetic */ void e(File file) {
        super.e(file);
    }

    @Override // hk.j
    public void f(final File file, u uVar) {
        f0 f0Var;
        rk.h.a aVar;
        rk.j.a(file, "File is required.");
        try {
            if (!c(file.getName())) {
                this.f.a(i3.DEBUG, "File '%s' should be ignored.", file.getAbsolutePath());
                return;
            }
            try {
                BufferedInputStream bufferedInputStream = new BufferedInputStream(new FileInputStream(file));
                try {
                    l2 l2VarA = this.d.a(bufferedInputStream);
                    if (l2VarA == null) {
                        this.f.a(i3.ERROR, "Stream from path %s resulted in a null envelope.", file.getAbsolutePath());
                    } else {
                        o(l2VarA, uVar);
                        this.f.a(i3.DEBUG, "File '%s' is done.", file.getAbsolutePath());
                    }
                    bufferedInputStream.close();
                    f0Var = this.f;
                    aVar = new rk.h.a() { // from class: hk.o1
                        @Override // rk.h.a
                        public final void a(Object obj) {
                            this.a.j(file, (ok.f) obj);
                        }
                    };
                } catch (Throwable th2) {
                    try {
                        bufferedInputStream.close();
                    } catch (Throwable unused) {
                    }
                    throw th2;
                }
            } catch (IOException e) {
                this.f.b(i3.ERROR, "Error processing envelope.", e);
                f0Var = this.f;
                aVar = new rk.h.a() { // from class: hk.o1
                    @Override // rk.h.a
                    public final void a(Object obj) {
                        this.a.j(file, (ok.f) obj);
                    }
                };
            }
            rk.h.o(uVar, ok.f.class, f0Var, aVar);
        } catch (Throwable th3) {
            rk.h.o(uVar, ok.f.class, this.f, new rk.h.a() { // from class: hk.o1
                @Override // rk.h.a
                public final void a(Object obj) {
                    this.a.j(file, (ok.f) obj);
                }
            });
            throw th3;
        }
    }

    public final void k(c3 c3Var, int i) {
        this.f.a(i3.ERROR, "Item %d of type %s returned null by the parser.", Integer.valueOf(i), c3Var.w().b());
    }

    public final void l(int i) {
        this.f.a(i3.DEBUG, "Item %d is being captured.", Integer.valueOf(i));
    }

    public final void m(pk.m mVar) {
        this.f.a(i3.WARNING, "Timed out waiting for event id submission: %s", mVar);
    }

    public final void n(l2 l2Var, pk.m mVar, int i) {
        this.f.a(i3.ERROR, "Item %d of has a different event id (%s) to the envelope header (%s)", Integer.valueOf(i), l2Var.b().a(), mVar);
    }

    public final void o(l2 l2Var, u uVar) {
        Object objF;
        this.f.a(i3.DEBUG, "Processing Envelope with %d item(s)", Integer.valueOf(rk.a.d(l2Var.c())));
        int i = 0;
        for (c3 c3Var : l2Var.c()) {
            i++;
            if (c3Var.w() == null) {
                this.f.a(i3.ERROR, "Item %d has no header", Integer.valueOf(i));
            } else if (h3.Event.equals(c3Var.w().b())) {
                try {
                    BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(new ByteArrayInputStream(c3Var.v()), g));
                    try {
                        e3 e3Var = (e3) this.e.c(bufferedReader, e3.class);
                        if (e3Var == null) {
                            k(c3Var, i);
                        } else if (l2Var.b().a() == null || l2Var.b().a().equals(e3Var.E())) {
                            this.c.i(e3Var, uVar);
                            l(i);
                            if (!p(uVar)) {
                                m(e3Var.E());
                                bufferedReader.close();
                                return;
                            }
                        } else {
                            n(l2Var, e3Var.E(), i);
                            bufferedReader.close();
                        }
                        bufferedReader.close();
                    } catch (Throwable th2) {
                        try {
                            bufferedReader.close();
                        } catch (Throwable unused) {
                        }
                        throw th2;
                    }
                } catch (Throwable th3) {
                    this.f.b(i3.ERROR, "Item failed to process.", th3);
                }
                objF = rk.h.f(uVar);
                if (!(objF instanceof ok.k) && !((ok.k) objF).f()) {
                    this.f.a(i3.WARNING, "Envelope had a failed capture at item %d. No more items will be sent.", Integer.valueOf(i));
                    return;
                }
                rk.h.m(uVar, ok.e.class, new rk.h.a() { // from class: hk.p1
                    @Override // rk.h.a
                    public final void a(Object obj) {
                        ((ok.e) obj).a();
                    }
                });
            } else {
                if (h3.Transaction.equals(c3Var.w().b())) {
                    try {
                        BufferedReader bufferedReader2 = new BufferedReader(new InputStreamReader(new ByteArrayInputStream(c3Var.v()), g));
                        try {
                            pk.t tVar = (pk.t) this.e.c(bufferedReader2, pk.t.class);
                            if (tVar == null) {
                                k(c3Var, i);
                            } else if (l2Var.b().a() == null || l2Var.b().a().equals(tVar.E())) {
                                if (tVar.B().f() != null) {
                                    tVar.B().f().j(Boolean.TRUE);
                                }
                                this.c.g(tVar, l2Var.b().c(), uVar);
                                l(i);
                                if (!p(uVar)) {
                                    m(tVar.E());
                                    bufferedReader2.close();
                                    return;
                                }
                            } else {
                                n(l2Var, tVar.E(), i);
                                bufferedReader2.close();
                            }
                            bufferedReader2.close();
                        } catch (Throwable th4) {
                            try {
                                bufferedReader2.close();
                            } catch (Throwable unused2) {
                            }
                            throw th4;
                        }
                    } catch (Throwable th5) {
                        this.f.b(i3.ERROR, "Item failed to process.", th5);
                    }
                } else {
                    this.c.d(new l2(l2Var.b().a(), l2Var.b().b(), c3Var), uVar);
                    this.f.a(i3.DEBUG, "%s item %d is being captured.", c3Var.w().b().getItemType(), Integer.valueOf(i));
                    if (!p(uVar)) {
                        this.f.a(i3.WARNING, "Timed out waiting for item type submission: %s", c3Var.w().b().getItemType());
                        return;
                    }
                }
                objF = rk.h.f(uVar);
                if (!(objF instanceof ok.k)) {
                }
                rk.h.m(uVar, ok.e.class, new rk.h.a() { // from class: hk.p1
                    @Override // rk.h.a
                    public final void a(Object obj) {
                        ((ok.e) obj).a();
                    }
                });
            }
        }
    }

    public final boolean p(u uVar) {
        Object objF = rk.h.f(uVar);
        if (objF instanceof ok.d) {
            return ((ok.d) objF).e();
        }
        rk.i.a(ok.d.class, objF, this.f);
        return true;
    }
}
