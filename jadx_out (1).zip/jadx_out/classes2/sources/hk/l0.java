package hk;

/* JADX INFO: compiled from: ITransaction.java */
/* JADX INFO: loaded from: /home/kali/Desktop/bunt/agah/dex_files/classes2.dex */
public interface l0 extends k0 {
    w3 e();

    pk.m f();

    void g();

    String getName();
}
