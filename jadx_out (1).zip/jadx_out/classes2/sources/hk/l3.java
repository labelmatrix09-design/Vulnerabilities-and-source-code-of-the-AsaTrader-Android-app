package hk;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;

/* JADX INFO: compiled from: SentryStackTraceFactory.java */
/* JADX INFO: loaded from: /home/kali/Desktop/bunt/agah/dex_files/classes2.dex */
public final class l3 {
    public final List<String> a;
    public final List<String> b;

    public l3(List<String> list, List<String> list2) {
        this.a = list;
        this.b = list2;
    }

    public List<pk.q> a(StackTraceElement[] stackTraceElementArr) {
        if (stackTraceElementArr == null || stackTraceElementArr.length <= 0) {
            return null;
        }
        ArrayList arrayList = new ArrayList();
        for (StackTraceElement stackTraceElement : stackTraceElementArr) {
            if (stackTraceElement != null) {
                String className = stackTraceElement.getClassName();
                if (!className.startsWith("io.sentry.") || className.startsWith("io.sentry.samples.") || className.startsWith("io.sentry.mobile.")) {
                    pk.q qVar = new pk.q();
                    qVar.r(Boolean.valueOf(b(className)));
                    qVar.t(className);
                    qVar.q(stackTraceElement.getMethodName());
                    qVar.p(stackTraceElement.getFileName());
                    if (stackTraceElement.getLineNumber() >= 0) {
                        qVar.s(Integer.valueOf(stackTraceElement.getLineNumber()));
                    }
                    qVar.u(Boolean.valueOf(stackTraceElement.isNativeMethod()));
                    arrayList.add(qVar);
                }
            }
        }
        Collections.reverse(arrayList);
        return arrayList;
    }

    public boolean b(String str) {
        if (str == null || str.isEmpty()) {
            return true;
        }
        List<String> list = this.b;
        if (list != null) {
            Iterator<String> it = list.iterator();
            while (it.hasNext()) {
                if (str.startsWith(it.next())) {
                    return true;
                }
            }
        }
        List<String> list2 = this.a;
        if (list2 != null) {
            Iterator<String> it2 = list2.iterator();
            while (it2.hasNext() && !str.startsWith(it2.next())) {
            }
        }
        return false;
    }
}
