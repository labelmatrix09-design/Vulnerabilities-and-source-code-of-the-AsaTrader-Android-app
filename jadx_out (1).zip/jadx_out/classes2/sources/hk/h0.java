package hk;

import org.jetbrains.annotations.ApiStatus;

/* JADX INFO: compiled from: ISentryClient.java */
/* JADX INFO: loaded from: /home/kali/Desktop/bunt/agah/dex_files/classes2.dex */
public interface h0 {
    pk.m a(e3 e3Var, w1 w1Var, u uVar);

    @ApiStatus.Internal
    pk.m b(pk.t tVar, f4 f4Var, w1 w1Var, u uVar, s1 s1Var);

    void c(long j);

    void close();

    pk.m d(l2 l2Var, u uVar);

    void e(t3 t3Var, u uVar);
}
