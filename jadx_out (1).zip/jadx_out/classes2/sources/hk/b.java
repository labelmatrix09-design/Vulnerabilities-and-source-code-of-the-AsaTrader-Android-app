package hk;

/* JADX INFO: compiled from: Attachment.java */
/* JADX INFO: loaded from: /home/kali/Desktop/bunt/agah/dex_files/classes2.dex */
public final class b {
    public byte[] a;
    public String b;
    public final String c;
    public final String d;
    public final boolean e;
    public String f = "event.attachment";

    public b(byte[] bArr, String str, String str2, boolean z) {
        this.a = bArr;
        this.c = str;
        this.d = str2;
        this.e = z;
    }

    public static b a(byte[] bArr) {
        return new b(bArr, "screenshot.png", "image/png", false);
    }

    public String b() {
        return this.f;
    }

    public byte[] c() {
        return this.a;
    }

    public String d() {
        return this.d;
    }

    public String e() {
        return this.c;
    }

    public String f() {
        return this.b;
    }

    public boolean g() {
        return this.e;
    }
}
