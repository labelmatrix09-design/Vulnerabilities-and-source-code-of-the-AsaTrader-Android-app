package hk;

import java.util.ArrayList;
import org.jetbrains.annotations.ApiStatus;

/* JADX INFO: compiled from: SentryEnvelope.java */
/* JADX INFO: loaded from: /home/kali/Desktop/bunt/agah/dex_files/classes2.dex */
@ApiStatus.Internal
public final class l2 {
    public final m2 a;
    public final Iterable<c3> b;

    public l2(m2 m2Var, Iterable<c3> iterable) {
        this.a = (m2) rk.j.a(m2Var, "SentryEnvelopeHeader is required.");
        this.b = (Iterable) rk.j.a(iterable, "SentryEnvelope items are required.");
    }

    public static l2 a(j0 j0Var, t3 t3Var, pk.k kVar) {
        rk.j.a(j0Var, "Serializer is required.");
        rk.j.a(t3Var, "session is required.");
        return new l2(null, kVar, c3.t(j0Var, t3Var));
    }

    public m2 b() {
        return this.a;
    }

    public Iterable<c3> c() {
        return this.b;
    }

    public l2(pk.m mVar, pk.k kVar, c3 c3Var) {
        rk.j.a(c3Var, "SentryEnvelopeItem is required.");
        this.a = new m2(mVar, kVar);
        ArrayList arrayList = new ArrayList(1);
        arrayList.add(c3Var);
        this.b = arrayList;
    }
}
