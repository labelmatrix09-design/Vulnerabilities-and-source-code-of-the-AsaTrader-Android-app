package hk;

/* JADX INFO: compiled from: NoOpSpan.java */
/* JADX INFO: loaded from: /home/kali/Desktop/bunt/agah/dex_files/classes2.dex */
public final class j1 implements k0 {
    public static final j1 a = new j1();

    public static j1 k() {
        return a;
    }

    @Override // hk.k0
    public boolean b() {
        return false;
    }

    @Override // hk.k0
    public void c() {
    }

    @Override // hk.k0
    public void d(a4 a4Var) {
    }

    @Override // hk.k0
    public x3 h() {
        return new x3(pk.m.p, z3.p, "op", null, null);
    }
}
