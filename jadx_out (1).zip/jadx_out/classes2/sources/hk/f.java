package hk;

import org.jetbrains.annotations.ApiStatus;

/* JADX INFO: compiled from: DataCategory.java */
/* JADX INFO: loaded from: /home/kali/Desktop/bunt/agah/dex_files/classes2.dex */
@ApiStatus.Internal
public enum f {
    All("__all__"),
    Default("default"),
    Error("error"),
    Session("session"),
    Attachment("attachment"),
    Transaction("transaction"),
    Security("security"),
    UserReport("user_report"),
    Unknown("unknown");

    private final String category;

    f(String str) {
        this.category = str;
    }

    public String getCategory() {
        return this.category;
    }
}
