package hk;

/* JADX INFO: compiled from: UncaughtExceptionHandler.java */
/* JADX INFO: loaded from: /home/kali/Desktop/bunt/agah/dex_files/classes2.dex */
public interface j4 {

    /* JADX INFO: compiled from: UncaughtExceptionHandler.java */
    public static final class a implements j4 {
        public static final a a = new a();

        public static j4 c() {
            return a;
        }

        @Override // hk.j4
        public void a(Thread.UncaughtExceptionHandler uncaughtExceptionHandler) {
            Thread.setDefaultUncaughtExceptionHandler(uncaughtExceptionHandler);
        }

        @Override // hk.j4
        public Thread.UncaughtExceptionHandler b() {
            return Thread.getDefaultUncaughtExceptionHandler();
        }
    }

    void a(Thread.UncaughtExceptionHandler uncaughtExceptionHandler);

    Thread.UncaughtExceptionHandler b();
}
