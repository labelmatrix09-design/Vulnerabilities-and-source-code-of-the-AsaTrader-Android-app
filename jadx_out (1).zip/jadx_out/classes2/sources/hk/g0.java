package hk;

/* JADX INFO: compiled from: IScopeObserver.java */
/* JADX INFO: loaded from: /home/kali/Desktop/bunt/agah/dex_files/classes2.dex */
public interface g0 {
    void e(c cVar);
}
