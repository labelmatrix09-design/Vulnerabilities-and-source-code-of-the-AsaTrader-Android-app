package hk;

import java.lang.reflect.Field;
import java.lang.reflect.Modifier;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import org.jetbrains.annotations.ApiStatus;

/* JADX INFO: compiled from: JsonReflectionObjectSerializer.java */
/* JADX INFO: loaded from: /home/kali/Desktop/bunt/agah/dex_files/classes2.dex */
@ApiStatus.Internal
public final class y0 {
    public final Set<Object> a = new HashSet();
    public final int b;

    public y0(int i) {
        this.b = i;
    }

    public final List<Object> a(Collection<?> collection, f0 f0Var) {
        ArrayList arrayList = new ArrayList();
        Iterator<?> it = collection.iterator();
        while (it.hasNext()) {
            arrayList.add(d(it.next(), f0Var));
        }
        return arrayList;
    }

    public final List<Object> b(Object[] objArr, f0 f0Var) {
        ArrayList arrayList = new ArrayList();
        for (Object obj : objArr) {
            arrayList.add(d(obj, f0Var));
        }
        return arrayList;
    }

    public final Map<String, Object> c(Map<?, ?> map, f0 f0Var) {
        HashMap map2 = new HashMap();
        for (Object obj : map.keySet()) {
            Object obj2 = map.get(obj);
            if (obj2 != null) {
                map2.put(obj.toString(), d(obj2, f0Var));
            } else {
                map2.put(obj.toString(), null);
            }
        }
        return map2;
    }

    public Object d(Object obj, f0 f0Var) {
        Object objC;
        Object obj2 = null;
        if (obj == null) {
            return null;
        }
        if (obj instanceof Character) {
            return obj.toString();
        }
        if ((obj instanceof Number) || (obj instanceof Boolean) || (obj instanceof String)) {
            return obj;
        }
        if (this.a.contains(obj)) {
            f0Var.a(i3.INFO, "Cyclic reference detected. Calling toString() on object.", new Object[0]);
            return obj.toString();
        }
        this.a.add(obj);
        try {
            if (this.a.size() > this.b) {
                this.a.remove(obj);
                f0Var.a(i3.INFO, "Max depth exceeded. Calling toString() on object.", new Object[0]);
                return obj.toString();
            }
            if (obj.getClass().isArray()) {
                objC = b((Object[]) obj, f0Var);
            } else if (obj instanceof Collection) {
                objC = a((Collection) obj, f0Var);
            } else {
                objC = obj instanceof Map ? c((Map) obj, f0Var) : e(obj, f0Var);
            }
            obj2 = objC;
            return obj2;
        } catch (Exception e) {
            f0Var.b(i3.INFO, "Not serializing object due to throwing sub-path.", e);
        } finally {
            this.a.remove(obj);
        }
    }

    public Map<String, Object> e(Object obj, f0 f0Var) {
        Field[] declaredFields = obj.getClass().getDeclaredFields();
        HashMap map = new HashMap();
        for (Field field : declaredFields) {
            if (!Modifier.isTransient(field.getModifiers())) {
                String name = field.getName();
                try {
                    field.setAccessible(true);
                    map.put(name, d(field.get(obj), f0Var));
                    field.setAccessible(false);
                } catch (Exception unused) {
                    f0Var.a(i3.INFO, "Cannot access field " + name + ".", new Object[0]);
                }
            }
        }
        return map;
    }
}
