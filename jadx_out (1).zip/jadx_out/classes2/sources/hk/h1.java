package hk;

import java.util.concurrent.Callable;
import java.util.concurrent.Future;
import java.util.concurrent.FutureTask;

/* JADX INFO: compiled from: NoOpSentryExecutorService.java */
/* JADX INFO: loaded from: /home/kali/Desktop/bunt/agah/dex_files/classes2.dex */
public final class h1 implements i0 {
    public static final h1 a = new h1();

    public static i0 e() {
        return a;
    }

    public static /* synthetic */ Object f() {
        return null;
    }

    public static /* synthetic */ Object g() {
        return null;
    }

    @Override // hk.i0
    public void a(long j) {
    }

    @Override // hk.i0
    public Future<?> b(Runnable runnable, long j) {
        return new FutureTask(new Callable() { // from class: hk.f1
            @Override // java.util.concurrent.Callable
            public final Object call() {
                return h1.f();
            }
        });
    }

    @Override // hk.i0
    public Future<?> submit(Runnable runnable) {
        return new FutureTask(new Callable() { // from class: hk.g1
            @Override // java.util.concurrent.Callable
            public final Object call() {
                return h1.g();
            }
        });
    }
}
