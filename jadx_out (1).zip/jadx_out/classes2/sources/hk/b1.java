package hk;

import io.sentry.protocol.DebugImage;
import java.io.Closeable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.jetbrains.annotations.ApiStatus;

/* JADX INFO: compiled from: MainEventProcessor.java */
/* JADX INFO: loaded from: /home/kali/Desktop/bunt/agah/dex_files/classes2.dex */
@ApiStatus.Internal
public final class b1 implements s, Closeable {
    public final j3 o;
    public final m3 p;
    public final f3 q;
    public final x r;

    public b1(j3 j3Var) {
        this(j3Var, j3Var.isAttachServerName() ? x.e() : null);
    }

    public final void A(g2 g2Var) {
        if (g2Var.J() == null) {
            g2Var.X(this.o.getSdkVersion());
        }
    }

    public final void B(g2 g2Var) {
        if (g2Var.K() == null) {
            g2Var.Y(this.o.getServerName());
        }
        if (this.o.isAttachServerName() && this.r != null && g2Var.K() == null) {
            g2Var.Y(this.r.d());
        }
    }

    public final void F(g2 g2Var) {
        if (g2Var.L() == null) {
            g2Var.a0(new HashMap(this.o.getTags()));
            return;
        }
        for (Map.Entry entry : this.o.getTags().entrySet()) {
            if (!g2Var.L().containsKey(entry.getKey())) {
                g2Var.Z((String) entry.getKey(), (String) entry.getValue());
            }
        }
    }

    public final void I(e3 e3Var, u uVar) {
        if (e3Var.q0() == null) {
            ArrayList arrayList = null;
            List<pk.l> listN0 = e3Var.n0();
            if (listN0 != null && !listN0.isEmpty()) {
                for (pk.l lVar : listN0) {
                    if (lVar.g() != null && lVar.h() != null) {
                        if (arrayList == null) {
                            arrayList = new ArrayList();
                        }
                        arrayList.add(lVar.h());
                    }
                }
            }
            if (this.o.isAttachThreads()) {
                e3Var.y0(this.p.b(arrayList));
                return;
            }
            if (this.o.isAttachStacktrace()) {
                if ((listN0 == null || listN0.isEmpty()) && !f(uVar)) {
                    e3Var.y0(this.p.a());
                }
            }
        }
    }

    public final boolean L(g2 g2Var, u uVar) {
        if (rk.h.q(uVar)) {
            return true;
        }
        this.o.getLogger().a(i3.DEBUG, "Event was cached so not applying data relevant to the current app execution/version: %s", g2Var.E());
        return false;
    }

    @Override // hk.s
    public e3 a(e3 e3Var, u uVar) {
        j(e3Var);
        u(e3Var);
        m(e3Var);
        if (L(e3Var, uVar)) {
            h(e3Var);
            I(e3Var, uVar);
        }
        return e3Var;
    }

    @Override // hk.s
    public pk.t b(pk.t tVar, u uVar) {
        j(tVar);
        if (L(tVar, uVar)) {
            h(tVar);
        }
        return tVar;
    }

    @Override // java.io.Closeable, java.lang.AutoCloseable
    public void close() {
        x xVar = this.r;
        if (xVar != null) {
            xVar.c();
        }
    }

    public final boolean f(u uVar) {
        return rk.h.g(uVar, ok.b.class);
    }

    public final void g(g2 g2Var) {
        if (this.o.isSendDefaultPii()) {
            if (g2Var.O() == null) {
                pk.u uVar = new pk.u();
                uVar.j("{{auto}}");
                g2Var.b0(uVar);
            } else if (g2Var.O().g() == null) {
                g2Var.O().j("{{auto}}");
            }
        }
    }

    public final void h(g2 g2Var) {
        z(g2Var);
        p(g2Var);
        B(g2Var);
        o(g2Var);
        A(g2Var);
        F(g2Var);
        g(g2Var);
    }

    public final void j(g2 g2Var) {
        x(g2Var);
    }

    public final void m(e3 e3Var) {
        if (this.o.getProguardUuid() != null) {
            io.sentry.protocol.a aVarM0 = e3Var.m0();
            if (aVarM0 == null) {
                aVarM0 = new io.sentry.protocol.a();
            }
            if (aVarM0.c() == null) {
                aVarM0.d(new ArrayList());
            }
            List<DebugImage> listC = aVarM0.c();
            if (listC != null) {
                DebugImage debugImage = new DebugImage();
                debugImage.setType(DebugImage.PROGUARD);
                debugImage.setUuid(this.o.getProguardUuid());
                listC.add(debugImage);
                e3Var.u0(aVarM0);
            }
        }
    }

    public final void o(g2 g2Var) {
        if (g2Var.C() == null) {
            g2Var.Q(this.o.getDist());
        }
    }

    public final void p(g2 g2Var) {
        if (g2Var.D() == null) {
            g2Var.R(this.o.getEnvironment() != null ? this.o.getEnvironment() : "production");
        }
    }

    public final void u(e3 e3Var) {
        Throwable thN = e3Var.N();
        if (thN != null) {
            e3Var.v0(this.q.c(thN));
        }
    }

    public final void x(g2 g2Var) {
        if (g2Var.G() == null) {
            g2Var.U("java");
        }
    }

    public final void z(g2 g2Var) {
        if (g2Var.H() == null) {
            g2Var.V(this.o.getRelease());
        }
    }

    public b1(j3 j3Var, x xVar) {
        j3 j3Var2 = (j3) rk.j.a(j3Var, "The SentryOptions is required.");
        this.o = j3Var2;
        this.r = xVar;
        l3 l3Var = new l3(j3Var2.getInAppExcludes(), j3Var2.getInAppIncludes());
        this.q = new f3(l3Var);
        this.p = new m3(l3Var, j3Var2);
    }
}
