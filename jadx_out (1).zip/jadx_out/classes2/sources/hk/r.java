package hk;

/* JADX INFO: compiled from: EventProcessor.java */
/* JADX INFO: loaded from: /home/kali/Desktop/bunt/agah/dex_files/classes2.dex */
public final /* synthetic */ class r {
    public static pk.t a(s sVar, pk.t tVar, u uVar) {
        return tVar;
    }
}
