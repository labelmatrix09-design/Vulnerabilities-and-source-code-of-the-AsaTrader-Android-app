package hk;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/* JADX INFO: compiled from: SentryThreadFactory.java */
/* JADX INFO: loaded from: /home/kali/Desktop/bunt/agah/dex_files/classes2.dex */
public final class m3 {
    public final l3 a;
    public final j3 b;

    public m3(l3 l3Var, j3 j3Var) {
        this.a = (l3) rk.j.a(l3Var, "The SentryStackTraceFactory is required.");
        this.b = (j3) rk.j.a(j3Var, "The SentryOptions is required");
    }

    public List<pk.s> a() {
        HashMap map = new HashMap();
        Thread threadCurrentThread = Thread.currentThread();
        map.put(threadCurrentThread, threadCurrentThread.getStackTrace());
        return c(map, null);
    }

    public List<pk.s> b(List<Long> list) {
        return c(Thread.getAllStackTraces(), list);
    }

    public List<pk.s> c(Map<Thread, StackTraceElement[]> map, List<Long> list) {
        Thread threadCurrentThread = Thread.currentThread();
        if (map.isEmpty()) {
            return null;
        }
        ArrayList arrayList = new ArrayList();
        if (!map.containsKey(threadCurrentThread)) {
            map.put(threadCurrentThread, threadCurrentThread.getStackTrace());
        }
        for (Map.Entry<Thread, StackTraceElement[]> entry : map.entrySet()) {
            Thread key = entry.getKey();
            arrayList.add(d(key == threadCurrentThread || (list != null && list.contains(Long.valueOf(key.getId()))), entry.getValue(), entry.getKey()));
        }
        return arrayList;
    }

    public final pk.s d(boolean z, StackTraceElement[] stackTraceElementArr, Thread thread) {
        pk.s sVar = new pk.s();
        sVar.o(thread.getName());
        sVar.p(Integer.valueOf(thread.getPriority()));
        sVar.n(Long.valueOf(thread.getId()));
        sVar.m(Boolean.valueOf(thread.isDaemon()));
        sVar.r(thread.getState().name());
        sVar.k(Boolean.valueOf(z));
        List<pk.q> listA = this.a.a(stackTraceElementArr);
        if (this.b.isAttachStacktrace() && listA != null && !listA.isEmpty()) {
            pk.r rVar = new pk.r(listA);
            rVar.d(Boolean.TRUE);
            sVar.q(rVar);
        }
        return sVar;
    }
}
