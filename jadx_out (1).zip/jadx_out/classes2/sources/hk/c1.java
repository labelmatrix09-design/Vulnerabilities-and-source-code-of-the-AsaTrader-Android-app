package hk;

import java.io.InputStream;

/* JADX INFO: compiled from: NoOpEnvelopeReader.java */
/* JADX INFO: loaded from: /home/kali/Desktop/bunt/agah/dex_files/classes2.dex */
public final class c1 implements b0 {
    public static final c1 a = new c1();

    public static c1 b() {
        return a;
    }

    @Override // hk.b0
    public l2 a(InputStream inputStream) {
        return null;
    }
}
