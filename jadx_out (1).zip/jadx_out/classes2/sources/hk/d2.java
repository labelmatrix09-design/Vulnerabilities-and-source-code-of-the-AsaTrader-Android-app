package hk;

import org.jetbrains.annotations.ApiStatus;

/* JADX INFO: compiled from: SendFireAndForgetOutboxSender.java */
/* JADX INFO: loaded from: /home/kali/Desktop/bunt/agah/dex_files/classes2.dex */
@ApiStatus.Internal
public final class d2 implements z1.c {
    public final z1.b a;

    public d2(z1.b bVar) {
        this.a = (z1.b) rk.j.a(bVar, "SendFireAndForgetDirPath is required");
    }

    @Override // hk.z1.c
    public /* synthetic */ boolean a(String str, f0 f0Var) {
        return b2.a(this, str, f0Var);
    }

    @Override // hk.z1.c
    public z1.a b(e0 e0Var, j3 j3Var) {
        rk.j.a(e0Var, "Hub is required");
        rk.j.a(j3Var, "SentryOptions is required");
        String strA = this.a.a();
        if (strA != null && a(strA, j3Var.getLogger())) {
            return c(new q1(e0Var, j3Var.getEnvelopeReader(), j3Var.getSerializer(), j3Var.getLogger(), j3Var.getFlushTimeoutMillis()), strA, j3Var.getLogger());
        }
        j3Var.getLogger().a(i3.ERROR, "No outbox dir path is defined in options.", new Object[0]);
        return null;
    }

    public /* synthetic */ z1.a c(j jVar, String str, f0 f0Var) {
        return b2.b(this, jVar, str, f0Var);
    }
}
