package hk;

import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

/* JADX INFO: compiled from: SentryExecutorService.java */
/* JADX INFO: loaded from: /home/kali/Desktop/bunt/agah/dex_files/classes2.dex */
public final class g3 implements i0 {
    public final ScheduledExecutorService a;

    public g3(ScheduledExecutorService scheduledExecutorService) {
        this.a = scheduledExecutorService;
    }

    @Override // hk.i0
    public void a(long j) {
        synchronized (this.a) {
            if (!this.a.isShutdown()) {
                this.a.shutdown();
                try {
                    if (!this.a.awaitTermination(j, TimeUnit.MILLISECONDS)) {
                        this.a.shutdownNow();
                    }
                } catch (InterruptedException unused) {
                    this.a.shutdownNow();
                    Thread.currentThread().interrupt();
                }
            }
        }
    }

    @Override // hk.i0
    public Future<?> b(Runnable runnable, long j) {
        return this.a.schedule(runnable, j, TimeUnit.MILLISECONDS);
    }

    @Override // hk.i0
    public Future<?> submit(Runnable runnable) {
        return this.a.submit(runnable);
    }

    public g3() {
        this(Executors.newSingleThreadScheduledExecutor());
    }
}
