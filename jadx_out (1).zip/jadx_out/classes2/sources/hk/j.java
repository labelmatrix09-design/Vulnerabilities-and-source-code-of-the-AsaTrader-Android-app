package hk;

import java.io.File;
import java.io.FilenameFilter;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;

/* JADX INFO: compiled from: DirectoryProcessor.java */
/* JADX INFO: loaded from: /home/kali/Desktop/bunt/agah/dex_files/classes2.dex */
public abstract class j {
    public final f0 a;
    public final long b;

    /* JADX INFO: compiled from: DirectoryProcessor.java */
    public static final class a implements ok.b, ok.f, ok.k, ok.d {
        public boolean a = false;
        public boolean b = false;
        public final CountDownLatch c = new CountDownLatch(1);
        public final long d;
        public final f0 e;

        public a(long j, f0 f0Var) {
            this.d = j;
            this.e = f0Var;
        }

        @Override // ok.f
        public boolean b() {
            return this.a;
        }

        @Override // ok.k
        public void c(boolean z) {
            this.b = z;
            this.c.countDown();
        }

        @Override // ok.f
        public void d(boolean z) {
            this.a = z;
        }

        @Override // ok.d
        public boolean e() {
            try {
                return this.c.await(this.d, TimeUnit.MILLISECONDS);
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                this.e.b(i3.ERROR, "Exception while awaiting on lock.", e);
                return false;
            }
        }

        @Override // ok.k
        public boolean f() {
            return this.b;
        }
    }

    public j(f0 f0Var, long j) {
        this.a = f0Var;
        this.b = j;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ boolean d(File file, String str) {
        return c(str);
    }

    public abstract boolean c(String str);

    public void e(File file) {
        try {
            f0 f0Var = this.a;
            i3 i3Var = i3.DEBUG;
            f0Var.a(i3Var, "Processing dir. %s", file.getAbsolutePath());
            if (!file.exists()) {
                this.a.a(i3.WARNING, "Directory '%s' doesn't exist. No cached events to send.", file.getAbsolutePath());
                return;
            }
            if (!file.isDirectory()) {
                this.a.a(i3.ERROR, "Cache dir %s is not a directory.", file.getAbsolutePath());
                return;
            }
            File[] fileArrListFiles = file.listFiles();
            if (fileArrListFiles == null) {
                this.a.a(i3.ERROR, "Cache dir %s is null.", file.getAbsolutePath());
                return;
            }
            File[] fileArrListFiles2 = file.listFiles(new FilenameFilter() { // from class: hk.i
                @Override // java.io.FilenameFilter
                public final boolean accept(File file2, String str) {
                    return this.a.d(file2, str);
                }
            });
            f0 f0Var2 = this.a;
            Object[] objArr = new Object[2];
            objArr[0] = Integer.valueOf(fileArrListFiles2 != null ? fileArrListFiles2.length : 0);
            objArr[1] = file.getAbsolutePath();
            f0Var2.a(i3Var, "Processing %d items from cache dir %s", objArr);
            for (File file2 : fileArrListFiles) {
                if (file2.isFile()) {
                    this.a.a(i3.DEBUG, "Processing file: %s", file2.getAbsolutePath());
                    f(file2, rk.h.e(new a(this.b, this.a)));
                } else {
                    this.a.a(i3.DEBUG, "File %s is not a File.", file2.getAbsolutePath());
                }
            }
        } catch (Throwable th2) {
            this.a.d(i3.ERROR, th2, "Failed processing '%s'", file.getAbsolutePath());
        }
    }

    public abstract void f(File file, u uVar);
}
