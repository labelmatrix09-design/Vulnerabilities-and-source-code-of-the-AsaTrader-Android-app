package hk;

/* JADX INFO: compiled from: ScopeCallback.java */
/* JADX INFO: loaded from: /home/kali/Desktop/bunt/agah/dex_files/classes2.dex */
public interface x1 {
    void a(w1 w1Var);
}
