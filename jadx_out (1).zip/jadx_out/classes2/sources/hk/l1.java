package hk;

/* JADX INFO: compiled from: NoOpTransactionProfiler.java */
/* JADX INFO: loaded from: /home/kali/Desktop/bunt/agah/dex_files/classes2.dex */
public final class l1 implements m0 {
    public static final l1 a = new l1();

    public static l1 c() {
        return a;
    }

    @Override // hk.m0
    public s1 a(l0 l0Var) {
        return null;
    }

    @Override // hk.m0
    public void b(l0 l0Var) {
    }
}
