package hk;

/* JADX INFO: compiled from: ITransportFactory.java */
/* JADX INFO: loaded from: /home/kali/Desktop/bunt/agah/dex_files/classes2.dex */
public interface n0 {
    qk.p a(j3 j3Var, t1 t1Var);
}
