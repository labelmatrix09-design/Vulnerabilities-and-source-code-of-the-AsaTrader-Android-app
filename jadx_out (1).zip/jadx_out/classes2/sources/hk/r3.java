package hk;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Timer;
import java.util.TimerTask;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicReference;
import org.jetbrains.annotations.ApiStatus;

/* JADX INFO: compiled from: SentryTracer.java */
/* JADX INFO: loaded from: /home/kali/Desktop/bunt/agah/dex_files/classes2.dex */
@ApiStatus.Internal
public final class r3 implements l0 {
    public final w3 b;
    public final e0 d;
    public String e;
    public final boolean f;
    public final i4 h;
    public final boolean i;
    public final Long j;
    public TimerTask k;
    public Timer l;
    public f4 p;
    public final pk.m a = new pk.m();
    public final List<w3> c = new CopyOnWriteArrayList();
    public b g = b.c;
    public final Object m = new Object();
    public final c n = new c(null);
    public final AtomicBoolean o = new AtomicBoolean(false);

    /* JADX INFO: compiled from: SentryTracer.java */
    public class a extends TimerTask {
        public a() {
        }

        @Override // java.util.TimerTask, java.lang.Runnable
        public void run() {
            a4 a4VarJ = r3.this.j();
            r3 r3Var = r3.this;
            if (a4VarJ == null) {
                a4VarJ = a4.OK;
            }
            r3Var.d(a4VarJ);
            r3.this.o.set(false);
        }
    }

    /* JADX INFO: compiled from: SentryTracer.java */
    public static final class b {
        public static final b c = d();
        public final boolean a;
        public final a4 b;

        public b(boolean z, a4 a4Var) {
            this.a = z;
            this.b = a4Var;
        }

        public static b c(a4 a4Var) {
            return new b(true, a4Var);
        }

        public static b d() {
            return new b(false, null);
        }
    }

    /* JADX INFO: compiled from: SentryTracer.java */
    public static final class c implements Comparator<w3> {
        public c() {
        }

        public /* synthetic */ c(a aVar) {
            this();
        }

        @Override // java.util.Comparator
        /* JADX INFO: renamed from: a, reason: merged with bridge method [inline-methods] */
        public int compare(w3 w3Var, w3 w3Var2) {
            Double dP = w3Var.p();
            Double dP2 = w3Var2.p();
            if (dP == null) {
                return -1;
            }
            if (dP2 == null) {
                return 1;
            }
            return dP.compareTo(dP2);
        }
    }

    public r3(h4 h4Var, e0 e0Var, Date date, boolean z, Long l, boolean z4, i4 i4Var) {
        this.l = null;
        rk.j.a(h4Var, "context is required");
        rk.j.a(e0Var, "hub is required");
        this.b = new w3(h4Var, this, e0Var, date);
        this.e = h4Var.m();
        this.d = e0Var;
        this.f = z;
        this.j = l;
        this.i = z4;
        this.h = i4Var;
        if (l != null) {
            this.l = new Timer(true);
            g();
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void A(final w1 w1Var) {
        w1Var.v(new w1.b() { // from class: hk.n3
            @Override // hk.w1.b
            public final void a(l0 l0Var) {
                this.a.z(w1Var, l0Var);
            }
        });
    }

    public static /* synthetic */ void B(AtomicReference atomicReference, w1 w1Var) {
        atomicReference.set(w1Var.r());
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void y(w3 w3Var) {
        b bVar = this.g;
        if (this.j == null) {
            if (bVar.a) {
                d(bVar.b);
            }
        } else if (!this.f || w()) {
            g();
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void z(w1 w1Var, l0 l0Var) {
        if (l0Var == this) {
            w1Var.b();
        }
    }

    public k0 C(z3 z3Var, String str, String str2, Date date) {
        return q(z3Var, str, str2, date);
    }

    @Override // hk.k0
    public f4 a() {
        f4 f4Var;
        if (!this.d.h().isTraceSampling()) {
            return null;
        }
        synchronized (this) {
            if (this.p == null) {
                final AtomicReference atomicReference = new AtomicReference();
                this.d.f(new x1() { // from class: hk.p3
                    @Override // hk.x1
                    public final void a(w1 w1Var) {
                        r3.B(atomicReference, w1Var);
                    }
                });
                this.p = new f4(this, (pk.u) atomicReference.get(), this.d.h());
            }
            f4Var = this.p;
        }
        return f4Var;
    }

    @Override // hk.k0
    public boolean b() {
        return this.b.b();
    }

    @Override // hk.k0
    public void c() {
        d(j());
    }

    @Override // hk.k0
    public void d(a4 a4Var) {
        w3 w3Var;
        Double dW;
        this.g = b.c(a4Var);
        if (this.b.b()) {
            return;
        }
        if (!this.f || w()) {
            Boolean boolX = x();
            if (boolX == null) {
                boolX = Boolean.FALSE;
            }
            s1 s1VarA = (this.d.h().isProfilingEnabled() && boolX.booleanValue()) ? this.d.h().getTransactionProfiler().a(this) : null;
            Long lValueOf = Long.valueOf(System.nanoTime());
            Double dQ = this.b.q(lValueOf);
            if (dQ == null) {
                dQ = Double.valueOf(g.a(g.b()));
                lValueOf = null;
            }
            for (w3 w3Var2 : this.c) {
                if (!w3Var2.b()) {
                    w3Var2.A(null);
                    w3Var2.k(a4.DEADLINE_EXCEEDED, dQ, lValueOf);
                }
            }
            if (!this.c.isEmpty() && this.i && (dW = (w3Var = (w3) Collections.max(this.c, this.n)).w()) != null && dQ.doubleValue() > dW.doubleValue()) {
                lValueOf = w3Var.o();
                dQ = dW;
            }
            this.b.k(this.g.b, dQ, lValueOf);
            this.d.f(new x1() { // from class: hk.o3
                @Override // hk.x1
                public final void a(w1 w1Var) {
                    this.a.A(w1Var);
                }
            });
            pk.t tVar = new pk.t(this);
            i4 i4Var = this.h;
            if (i4Var != null) {
                i4Var.a(this);
            }
            if (this.l != null) {
                synchronized (this.m) {
                    this.l.cancel();
                    this.l = null;
                }
            }
            if (!this.c.isEmpty() || this.j == null) {
                this.d.r(tVar, this.p, null, s1VarA);
            }
        }
    }

    @Override // hk.l0
    public w3 e() {
        ArrayList arrayList = new ArrayList(this.c);
        if (arrayList.isEmpty()) {
            return null;
        }
        for (int size = arrayList.size() - 1; size >= 0; size--) {
            if (!((w3) arrayList.get(size)).b()) {
                return (w3) arrayList.get(size);
            }
        }
        return null;
    }

    @Override // hk.l0
    public pk.m f() {
        return this.a;
    }

    @Override // hk.l0
    public void g() {
        synchronized (this.m) {
            p();
            if (this.l != null) {
                this.o.set(true);
                a aVar = new a();
                this.k = aVar;
                this.l.schedule(aVar, this.j.longValue());
            }
        }
    }

    @Override // hk.l0
    public String getName() {
        return this.e;
    }

    @Override // hk.k0
    public x3 h() {
        return this.b.h();
    }

    @Override // hk.k0
    public k0 i(String str, String str2, Date date) {
        return r(str, str2, date);
    }

    @Override // hk.k0
    public a4 j() {
        return this.b.j();
    }

    public final void p() {
        synchronized (this.m) {
            TimerTask timerTask = this.k;
            if (timerTask != null) {
                timerTask.cancel();
                this.o.set(false);
                this.k = null;
            }
        }
    }

    public final k0 q(z3 z3Var, String str, String str2, Date date) {
        if (this.b.b()) {
            return j1.k();
        }
        rk.j.a(z3Var, "parentSpanId is required");
        rk.j.a(str, "operation is required");
        p();
        w3 w3Var = new w3(this.b.x(), z3Var, this, str, this.d, date, new y3() { // from class: hk.q3
            @Override // hk.y3
            public final void a(w3 w3Var2) {
                this.a.y(w3Var2);
            }
        });
        w3Var.z(str2);
        this.c.add(w3Var);
        return w3Var;
    }

    public final k0 r(String str, String str2, Date date) {
        if (this.b.b()) {
            return j1.k();
        }
        if (this.c.size() < this.d.h().getMaxSpans()) {
            return this.b.i(str, str2, date);
        }
        this.d.h().getLogger().a(i3.WARNING, "Span operation: %s, description: %s dropped due to limit reached. Returning NoOpSpan.", str, str2);
        return j1.k();
    }

    public List<w3> s() {
        return this.c;
    }

    public Map<String, Object> t() {
        return this.b.l();
    }

    public Double u() {
        return this.b.p();
    }

    public Date v() {
        return this.b.u();
    }

    public final boolean w() {
        ArrayList arrayList = new ArrayList(this.c);
        if (arrayList.isEmpty()) {
            return true;
        }
        Iterator it = arrayList.iterator();
        while (it.hasNext()) {
            if (!((w3) it.next()).b()) {
                return false;
            }
        }
        return true;
    }

    public Boolean x() {
        return this.b.y();
    }
}
