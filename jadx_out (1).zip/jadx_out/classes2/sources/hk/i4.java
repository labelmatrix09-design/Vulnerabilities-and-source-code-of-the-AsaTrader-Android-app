package hk;

import org.jetbrains.annotations.ApiStatus;

/* JADX INFO: compiled from: TransactionFinishedCallback.java */
/* JADX INFO: loaded from: /home/kali/Desktop/bunt/agah/dex_files/classes2.dex */
@ApiStatus.Internal
public interface i4 {
    void a(l0 l0Var);
}
