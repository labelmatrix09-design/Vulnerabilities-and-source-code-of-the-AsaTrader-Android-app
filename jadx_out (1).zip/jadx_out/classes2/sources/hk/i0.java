package hk;

import java.util.concurrent.Future;
import org.jetbrains.annotations.ApiStatus;

/* JADX INFO: compiled from: ISentryExecutorService.java */
/* JADX INFO: loaded from: /home/kali/Desktop/bunt/agah/dex_files/classes2.dex */
@ApiStatus.Internal
public interface i0 {
    void a(long j);

    Future<?> b(Runnable runnable, long j);

    Future<?> submit(Runnable runnable);
}
