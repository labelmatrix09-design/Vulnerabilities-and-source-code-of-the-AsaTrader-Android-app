package hk;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

/* JADX INFO: compiled from: UserFeedback.java */
/* JADX INFO: loaded from: /home/kali/Desktop/bunt/agah/dex_files/classes2.dex */
public final class l4 implements z0 {
    public final pk.m o;
    public String p;
    public String q;
    public String r;
    public Map<String, Object> s;

    /* JADX INFO: compiled from: UserFeedback.java */
    public static final class a implements p0<l4> {
        @Override // hk.p0
        /* JADX INFO: renamed from: b, reason: merged with bridge method [inline-methods] */
        public l4 a(v0 v0Var, f0 f0Var) throws IOException {
            v0Var.b();
            pk.m mVarA = null;
            String strS0 = null;
            String strS1 = null;
            String strS2 = null;
            HashMap map = null;
            while (v0Var.V() == uk.b.NAME) {
                String strF = v0Var.F();
                strF.hashCode();
                switch (strF) {
                    case "comments":
                        strS2 = v0Var.S0();
                        break;
                    case "name":
                        strS0 = v0Var.S0();
                        break;
                    case "email":
                        strS1 = v0Var.S0();
                        break;
                    case "event_id":
                        mVarA = new pk.m.a().a(v0Var, f0Var);
                        break;
                    default:
                        if (map == null) {
                            map = new HashMap();
                        }
                        v0Var.V0(f0Var, map, strF);
                        break;
                }
            }
            v0Var.m();
            if (mVarA != null) {
                l4 l4Var = new l4(mVarA, strS0, strS1, strS2);
                l4Var.a(map);
                return l4Var;
            }
            IllegalStateException illegalStateException = new IllegalStateException("Missing required field \"event_id\"");
            f0Var.b(i3.ERROR, "Missing required field \"event_id\"", illegalStateException);
            throw illegalStateException;
        }
    }

    public l4(pk.m mVar, String str, String str2, String str3) {
        this.o = mVar;
        this.p = str;
        this.q = str2;
        this.r = str3;
    }

    public void a(Map<String, Object> map) {
        this.s = map;
    }

    public void serialize(x0 x0Var, f0 f0Var) throws IOException {
        x0Var.g();
        x0Var.b0("event_id");
        this.o.serialize(x0Var, f0Var);
        if (this.p != null) {
            x0Var.b0("name").V(this.p);
        }
        if (this.q != null) {
            x0Var.b0("email").V(this.q);
        }
        if (this.r != null) {
            x0Var.b0("comments").V(this.r);
        }
        Map<String, Object> map = this.s;
        if (map != null) {
            for (String str : map.keySet()) {
                x0Var.b0(str).d0(f0Var, this.s.get(str));
            }
        }
        x0Var.m();
    }

    public String toString() {
        return "UserFeedback{eventId=" + this.o + ", name='" + this.p + "', email='" + this.q + "', comments='" + this.r + "'}";
    }
}
