package hk;

import io.github.inflationx.calligraphy3.BuildConfig;
import java.util.UUID;

/* JADX INFO: compiled from: SpanId.java */
/* JADX INFO: loaded from: /home/kali/Desktop/bunt/agah/dex_files/classes2.dex */
public final class z3 implements z0 {
    public static final z3 p = new z3(new UUID(0, 0).toString());
    public final String o;

    /* JADX INFO: compiled from: SpanId.java */
    public static final class a implements p0<z3> {
        @Override // hk.p0
        /* JADX INFO: renamed from: b, reason: merged with bridge method [inline-methods] */
        public z3 a(v0 v0Var, f0 f0Var) {
            return new z3(v0Var.N());
        }
    }

    public z3(String str) {
        this.o = (String) rk.j.a(str, "value is required");
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null || z3.class != obj.getClass()) {
            return false;
        }
        return this.o.equals(((z3) obj).o);
    }

    public int hashCode() {
        return this.o.hashCode();
    }

    public void serialize(x0 x0Var, f0 f0Var) {
        x0Var.V(this.o);
    }

    public String toString() {
        return this.o;
    }

    public z3() {
        this(UUID.randomUUID());
    }

    public z3(UUID uuid) {
        this(uuid.toString().replace("-", BuildConfig.FLAVOR).substring(0, 16));
    }
}
