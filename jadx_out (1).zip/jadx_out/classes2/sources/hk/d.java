package hk;

import java.io.Serializable;
import java.util.AbstractCollection;
import java.util.Arrays;
import java.util.Iterator;
import java.util.NoSuchElementException;
import java.util.Queue;

/* JADX INFO: compiled from: CircularFifoQueue.java */
/* JADX INFO: loaded from: /home/kali/Desktop/bunt/agah/dex_files/classes2.dex */
public final class d<E> extends AbstractCollection<E> implements Queue<E>, Serializable {
    public transient E[] o;
    public transient int p = 0;
    public transient int q = 0;
    public transient boolean r = false;
    public final int s;

    /* JADX INFO: compiled from: CircularFifoQueue.java */
    public class a implements Iterator<E> {
        public int o;
        public int p = -1;
        public boolean q;

        public a() {
            this.o = d.this.p;
            this.q = d.this.r;
        }

        @Override // java.util.Iterator
        public boolean hasNext() {
            return this.q || this.o != d.this.q;
        }

        @Override // java.util.Iterator
        public E next() {
            if (!hasNext()) {
                throw new NoSuchElementException();
            }
            this.q = false;
            int i = this.o;
            this.p = i;
            this.o = d.this.p(i);
            return (E) d.this.o[this.p];
        }

        @Override // java.util.Iterator
        public void remove() {
            int i = this.p;
            if (i == -1) {
                throw new IllegalStateException();
            }
            if (i == d.this.p) {
                d.this.remove();
                this.p = -1;
                return;
            }
            int iP = this.p + 1;
            if (d.this.p >= this.p || iP >= d.this.q) {
                while (iP != d.this.q) {
                    if (iP >= d.this.s) {
                        d.this.o[iP - 1] = d.this.o[0];
                        iP = 0;
                    } else {
                        d.this.o[d.this.o(iP)] = d.this.o[iP];
                        iP = d.this.p(iP);
                    }
                }
            } else {
                System.arraycopy(d.this.o, iP, d.this.o, this.p, d.this.q - iP);
            }
            this.p = -1;
            d dVar = d.this;
            dVar.q = dVar.o(dVar.q);
            d.this.o[d.this.q] = null;
            d.this.r = false;
            this.o = d.this.o(this.o);
        }
    }

    public d(int i) {
        if (i <= 0) {
            throw new IllegalArgumentException("The size must be greater than 0");
        }
        E[] eArr = (E[]) new Object[i];
        this.o = eArr;
        this.s = eArr.length;
    }

    @Override // java.util.AbstractCollection, java.util.Collection, java.util.Queue
    public boolean add(E e) {
        if (e == null) {
            throw new NullPointerException("Attempted to add null object to queue");
        }
        if (q()) {
            remove();
        }
        E[] eArr = this.o;
        int i = this.q;
        int i3 = i + 1;
        this.q = i3;
        eArr[i] = e;
        if (i3 >= this.s) {
            this.q = 0;
        }
        if (this.q == this.p) {
            this.r = true;
        }
        return true;
    }

    @Override // java.util.AbstractCollection, java.util.Collection
    public void clear() {
        this.r = false;
        this.p = 0;
        this.q = 0;
        Arrays.fill(this.o, (Object) null);
    }

    @Override // java.util.Queue
    public E element() {
        if (isEmpty()) {
            throw new NoSuchElementException("queue is empty");
        }
        return peek();
    }

    @Override // java.util.AbstractCollection, java.util.Collection
    public boolean isEmpty() {
        return size() == 0;
    }

    @Override // java.util.AbstractCollection, java.util.Collection, java.lang.Iterable
    public Iterator<E> iterator() {
        return new a();
    }

    public final int o(int i) {
        int i3 = i - 1;
        return i3 < 0 ? this.s - 1 : i3;
    }

    @Override // java.util.Queue
    public boolean offer(E e) {
        return add(e);
    }

    public final int p(int i) {
        int i3 = i + 1;
        if (i3 >= this.s) {
            return 0;
        }
        return i3;
    }

    @Override // java.util.Queue
    public E peek() {
        if (isEmpty()) {
            return null;
        }
        return this.o[this.p];
    }

    @Override // java.util.Queue
    public E poll() {
        if (isEmpty()) {
            return null;
        }
        return remove();
    }

    public boolean q() {
        return size() == this.s;
    }

    @Override // java.util.Queue
    public E remove() {
        if (isEmpty()) {
            throw new NoSuchElementException("queue is empty");
        }
        E[] eArr = this.o;
        int i = this.p;
        E e = eArr[i];
        if (e != null) {
            int i3 = i + 1;
            this.p = i3;
            eArr[i] = null;
            if (i3 >= this.s) {
                this.p = 0;
            }
            this.r = false;
        }
        return e;
    }

    @Override // java.util.AbstractCollection, java.util.Collection
    public int size() {
        int i = this.q;
        int i3 = this.p;
        if (i < i3) {
            return (this.s - i3) + i;
        }
        if (i != i3) {
            return i - i3;
        }
        if (this.r) {
            return this.s;
        }
        return 0;
    }
}
