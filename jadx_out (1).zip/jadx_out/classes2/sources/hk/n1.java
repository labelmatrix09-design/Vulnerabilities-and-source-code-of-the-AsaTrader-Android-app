package hk;

import org.jetbrains.annotations.ApiStatus;

/* JADX INFO: compiled from: OptionsContainer.java */
/* JADX INFO: loaded from: /home/kali/Desktop/bunt/agah/dex_files/classes2.dex */
@ApiStatus.Internal
public final class n1<T> {
    public final Class<T> a;

    public n1(Class<T> cls) {
        this.a = cls;
    }

    public static <T> n1<T> a(Class<T> cls) {
        return new n1<>(cls);
    }

    public T b() {
        return this.a.getDeclaredConstructor(new Class[0]).newInstance(new Object[0]);
    }
}
