package hk;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.Callable;
import org.jetbrains.annotations.ApiStatus;

/* JADX INFO: compiled from: SentryEnvelopeItemHeader.java */
/* JADX INFO: loaded from: /home/kali/Desktop/bunt/agah/dex_files/classes2.dex */
@ApiStatus.Internal
public final class d3 implements z0 {
    public final String o;
    public final String p;
    public final h3 q;
    public final int r;
    public final Callable<Integer> s;
    public final String t;
    public Map<String, Object> u;

    /* JADX INFO: compiled from: SentryEnvelopeItemHeader.java */
    public static final class a implements p0<d3> {
        @Override // hk.p0
        /* JADX INFO: renamed from: b, reason: merged with bridge method [inline-methods] */
        public d3 a(v0 v0Var, f0 f0Var) throws Exception {
            v0Var.b();
            HashMap map = null;
            h3 h3Var = null;
            String strS0 = null;
            String strS1 = null;
            String strS2 = null;
            int iA = 0;
            while (v0Var.V() == uk.b.NAME) {
                String strF = v0Var.F();
                strF.hashCode();
                switch (strF) {
                    case "length":
                        iA = v0Var.A();
                        break;
                    case "filename":
                        strS1 = v0Var.S0();
                        break;
                    case "attachment_type":
                        strS2 = v0Var.S0();
                        break;
                    case "type":
                        h3Var = (h3) v0Var.R0(f0Var, new h3.a());
                        break;
                    case "content_type":
                        strS0 = v0Var.S0();
                        break;
                    default:
                        if (map == null) {
                            map = new HashMap();
                        }
                        v0Var.V0(f0Var, map, strF);
                        break;
                }
            }
            if (h3Var == null) {
                throw c("type", f0Var);
            }
            d3 d3Var = new d3(h3Var, iA, strS0, strS1, strS2);
            d3Var.c(map);
            v0Var.m();
            return d3Var;
        }

        public final Exception c(String str, f0 f0Var) {
            String str2 = "Missing required field \"" + str + "\"";
            IllegalStateException illegalStateException = new IllegalStateException(str2);
            f0Var.b(i3.ERROR, str2, illegalStateException);
            return illegalStateException;
        }
    }

    @ApiStatus.Internal
    public d3(h3 h3Var, int i, String str, String str2, String str3) {
        this.q = (h3) rk.j.a(h3Var, "type is required");
        this.o = str;
        this.r = i;
        this.p = str2;
        this.s = null;
        this.t = str3;
    }

    public int a() {
        Callable<Integer> callable = this.s;
        if (callable == null) {
            return this.r;
        }
        try {
            return callable.call().intValue();
        } catch (Throwable unused) {
            return -1;
        }
    }

    public h3 b() {
        return this.q;
    }

    public void c(Map<String, Object> map) {
        this.u = map;
    }

    public void serialize(x0 x0Var, f0 f0Var) throws IOException {
        x0Var.g();
        if (this.o != null) {
            x0Var.b0("content_type").V(this.o);
        }
        if (this.p != null) {
            x0Var.b0("filename").V(this.p);
        }
        x0Var.b0("type").d0(f0Var, this.q);
        if (this.t != null) {
            x0Var.b0("attachment_type").V(this.t);
        }
        x0Var.b0("length").M(a());
        Map<String, Object> map = this.u;
        if (map != null) {
            for (String str : map.keySet()) {
                Object obj = this.u.get(str);
                x0Var.b0(str);
                x0Var.d0(f0Var, obj);
            }
        }
        x0Var.m();
    }

    public d3(h3 h3Var, Callable<Integer> callable, String str, String str2, String str3) {
        this.q = (h3) rk.j.a(h3Var, "type is required");
        this.o = str;
        this.r = -1;
        this.p = str2;
        this.s = callable;
        this.t = str3;
    }

    public d3(h3 h3Var, Callable<Integer> callable, String str, String str2) {
        this(h3Var, callable, str, str2, (String) null);
    }
}
