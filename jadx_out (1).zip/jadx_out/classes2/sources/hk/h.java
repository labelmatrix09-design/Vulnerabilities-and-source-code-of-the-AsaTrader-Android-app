package hk;

import org.jetbrains.annotations.ApiStatus;

/* JADX INFO: compiled from: DiagnosticLogger.java */
/* JADX INFO: loaded from: /home/kali/Desktop/bunt/agah/dex_files/classes2.dex */
@ApiStatus.Internal
public final class h implements f0 {
    public final j3 a;
    public final f0 b;

    public h(j3 j3Var, f0 f0Var) {
        this.a = (j3) rk.j.a(j3Var, "SentryOptions is required.");
        this.b = f0Var;
    }

    @Override // hk.f0
    public void a(i3 i3Var, String str, Object... objArr) {
        if (this.b == null || !c(i3Var)) {
            return;
        }
        this.b.a(i3Var, str, objArr);
    }

    @Override // hk.f0
    public void b(i3 i3Var, String str, Throwable th2) {
        if (this.b == null || !c(i3Var)) {
            return;
        }
        this.b.b(i3Var, str, th2);
    }

    @Override // hk.f0
    public boolean c(i3 i3Var) {
        return i3Var != null && this.a.isDebug() && i3Var.ordinal() >= this.a.getDiagnosticLevel().ordinal();
    }

    @Override // hk.f0
    public void d(i3 i3Var, Throwable th2, String str, Object... objArr) {
        if (this.b == null || !c(i3Var)) {
            return;
        }
        this.b.d(i3Var, th2, str, objArr);
    }
}
