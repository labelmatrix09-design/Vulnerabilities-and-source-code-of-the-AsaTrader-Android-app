package hk;

import java.net.MalformedURLException;
import java.net.URI;
import java.net.URL;
import java.util.Map;

/* JADX INFO: compiled from: RequestDetails.java */
/* JADX INFO: loaded from: /home/kali/Desktop/bunt/agah/dex_files/classes2.dex */
public final class t1 {
    public final URL a;
    public final Map<String, String> b;

    public t1(String str, Map<String, String> map) {
        rk.j.a(str, "url is required");
        rk.j.a(map, "headers is required");
        try {
            this.a = URI.create(str).toURL();
            this.b = map;
        } catch (MalformedURLException e) {
            throw new IllegalArgumentException("Failed to compose the Sentry's server URL.", e);
        }
    }

    public Map<String, String> a() {
        return this.b;
    }

    public URL b() {
        return this.a;
    }
}
