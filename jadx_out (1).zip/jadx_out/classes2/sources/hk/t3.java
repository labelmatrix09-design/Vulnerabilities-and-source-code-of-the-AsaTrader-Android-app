package hk;

import io.github.inflationx.calligraphy3.BuildConfig;
import java.io.IOException;
import java.util.Date;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicInteger;
import org.jetbrains.annotations.ApiStatus;

/* JADX INFO: compiled from: Session.java */
/* JADX INFO: loaded from: /home/kali/Desktop/bunt/agah/dex_files/classes2.dex */
public final class t3 implements z0 {
    public final String A;
    public final Object B;
    public Map<String, Object> C;
    public final Date o;
    public Date p;
    public final AtomicInteger q;
    public final String r;
    public final UUID s;
    public Boolean t;
    public b u;
    public Long v;
    public Double w;
    public final String x;
    public String y;
    public final String z;

    /* JADX INFO: compiled from: Session.java */
    public static final class a implements p0<t3> {
        /* JADX WARN: Can't fix incorrect switch cases order, some code will duplicate */
        /* JADX WARN: Code duplicated, block: B:57:0x00e5  */
        /* JADX WARN: Code duplicated, block: B:7:0x0047  */
        @Override // hk.p0
        /* JADX INFO: renamed from: b, reason: merged with bridge method [inline-methods] */
        public t3 a(v0 v0Var, f0 f0Var) throws Exception {
            String strS0;
            v0Var.b();
            Integer numM0 = null;
            b bVarValueOf = null;
            Date dateX0 = null;
            Date dateX1 = null;
            ConcurrentHashMap concurrentHashMap = null;
            String strS1 = null;
            UUID uuidFromString = null;
            Boolean boolW0 = null;
            Long lO0 = null;
            Double dZ0 = null;
            String strS2 = null;
            String strS3 = null;
            String str = null;
            String strS4 = null;
            while (true) {
                String strS5 = str;
                String str2 = strS3;
                String str3 = strS2;
                Double d = dZ0;
                if (v0Var.V() != uk.b.NAME) {
                    Long l = lO0;
                    if (bVarValueOf == null) {
                        throw c("status", f0Var);
                    }
                    if (dateX0 == null) {
                        throw c("started", f0Var);
                    }
                    if (numM0 == null) {
                        throw c("errors", f0Var);
                    }
                    if (strS4 == null) {
                        throw c(BuildConfig.BUILD_TYPE, f0Var);
                    }
                    t3 t3Var = new t3(bVarValueOf, dateX0, dateX1, numM0.intValue(), strS1, uuidFromString, boolW0, l, d, str3, str2, strS5, strS4);
                    t3Var.l(concurrentHashMap);
                    v0Var.m();
                    return t3Var;
                }
                String strF = v0Var.F();
                strF.hashCode();
                Long l5 = lO0;
                switch (strF) {
                    case "duration":
                        dZ0 = v0Var.z0();
                        str = strS5;
                        strS3 = str2;
                        strS2 = str3;
                        lO0 = l5;
                        break;
                    case "started":
                        dateX0 = v0Var.x0(f0Var);
                        str = strS5;
                        strS3 = str2;
                        strS2 = str3;
                        dZ0 = d;
                        lO0 = l5;
                        break;
                    case "errors":
                        numM0 = v0Var.M0();
                        str = strS5;
                        strS3 = str2;
                        strS2 = str3;
                        dZ0 = d;
                        lO0 = l5;
                        break;
                    case "status":
                        String strB = rk.m.b(v0Var.S0());
                        if (strB != null) {
                            bVarValueOf = b.valueOf(strB);
                        }
                        str = strS5;
                        strS3 = str2;
                        strS2 = str3;
                        dZ0 = d;
                        lO0 = l5;
                        break;
                    case "did":
                        strS1 = v0Var.S0();
                        str = strS5;
                        strS3 = str2;
                        strS2 = str3;
                        dZ0 = d;
                        lO0 = l5;
                        break;
                    case "seq":
                        lO0 = v0Var.O0();
                        str = strS5;
                        strS3 = str2;
                        strS2 = str3;
                        dZ0 = d;
                        break;
                    case "sid":
                        try {
                            strS0 = v0Var.S0();
                            try {
                                uuidFromString = UUID.fromString(strS0);
                            } catch (IllegalArgumentException unused) {
                                f0Var.a(i3.ERROR, "%s sid is not valid.", strS0);
                            }
                            break;
                        } catch (IllegalArgumentException unused2) {
                            strS0 = null;
                        }
                        str = strS5;
                        strS3 = str2;
                        strS2 = str3;
                        dZ0 = d;
                        lO0 = l5;
                        break;
                    case "init":
                        boolW0 = v0Var.w0();
                        str = strS5;
                        strS3 = str2;
                        strS2 = str3;
                        dZ0 = d;
                        lO0 = l5;
                        break;
                    case "timestamp":
                        dateX1 = v0Var.x0(f0Var);
                        str = strS5;
                        strS3 = str2;
                        strS2 = str3;
                        dZ0 = d;
                        lO0 = l5;
                        break;
                    case "attrs":
                        v0Var.b();
                        strS3 = str2;
                        strS2 = str3;
                        while (v0Var.V() == uk.b.NAME) {
                            String strF2 = v0Var.F();
                            strF2.hashCode();
                            switch (strF2) {
                                case "environment":
                                    strS5 = v0Var.S0();
                                    break;
                                case "release":
                                    strS4 = v0Var.S0();
                                    break;
                                case "ip_address":
                                    strS2 = v0Var.S0();
                                    break;
                                case "user_agent":
                                    strS3 = v0Var.S0();
                                    break;
                                default:
                                    v0Var.t0();
                                    break;
                            }
                        }
                        v0Var.m();
                        str = strS5;
                        dZ0 = d;
                        lO0 = l5;
                        break;
                    default:
                        if (concurrentHashMap == null) {
                            concurrentHashMap = new ConcurrentHashMap();
                        }
                        v0Var.V0(f0Var, concurrentHashMap, strF);
                        str = strS5;
                        strS3 = str2;
                        strS2 = str3;
                        dZ0 = d;
                        lO0 = l5;
                        break;
                }
            }
        }

        public final Exception c(String str, f0 f0Var) {
            String str2 = "Missing required field \"" + str + "\"";
            IllegalStateException illegalStateException = new IllegalStateException(str2);
            f0Var.b(i3.ERROR, str2, illegalStateException);
            return illegalStateException;
        }
    }

    /* JADX INFO: compiled from: Session.java */
    public enum b {
        Ok,
        Exited,
        Crashed,
        Abnormal
    }

    public t3(b bVar, Date date, Date date2, int i, String str, UUID uuid, Boolean bool, Long l, Double d, String str2, String str3, String str4, String str5) {
        this.B = new Object();
        this.u = bVar;
        this.o = date;
        this.p = date2;
        this.q = new AtomicInteger(i);
        this.r = str;
        this.s = uuid;
        this.t = bool;
        this.v = l;
        this.w = d;
        this.x = str2;
        this.y = str3;
        this.z = str4;
        this.A = str5;
    }

    public final double a(Date date) {
        double dAbs = Math.abs(date.getTime() - this.o.getTime());
        Double.isNaN(dAbs);
        return dAbs / 1000.0d;
    }

    /* JADX INFO: renamed from: b, reason: merged with bridge method [inline-methods] */
    public t3 clone() {
        return new t3(this.u, this.o, this.p, this.q.get(), this.r, this.s, this.t, this.v, this.w, this.x, this.y, this.z, this.A);
    }

    public void c() {
        d(g.b());
    }

    public void d(Date date) {
        synchronized (this.B) {
            this.t = null;
            if (this.u == b.Ok) {
                this.u = b.Exited;
            }
            if (date != null) {
                this.p = date;
            } else {
                this.p = g.b();
            }
            Date date2 = this.p;
            if (date2 != null) {
                this.w = Double.valueOf(a(date2));
                this.v = Long.valueOf(h(this.p));
            }
        }
    }

    public int e() {
        return this.q.get();
    }

    public Boolean f() {
        return this.t;
    }

    public String g() {
        return this.A;
    }

    public final long h(Date date) {
        long time = date.getTime();
        return time < 0 ? Math.abs(time) : time;
    }

    public UUID i() {
        return this.s;
    }

    public b j() {
        return this.u;
    }

    @ApiStatus.Internal
    public void k() {
        this.t = Boolean.TRUE;
    }

    public void l(Map<String, Object> map) {
        this.C = map;
    }

    public boolean m(b bVar, String str, boolean z) {
        boolean z4;
        synchronized (this.B) {
            boolean z5 = false;
            z4 = true;
            if (bVar != null) {
                try {
                    this.u = bVar;
                    z5 = true;
                } catch (Throwable th2) {
                    throw th2;
                }
            }
            if (str != null) {
                this.y = str;
                z5 = true;
            }
            if (z) {
                this.q.addAndGet(1);
            } else {
                z4 = z5;
            }
            if (z4) {
                this.t = null;
                Date dateB = g.b();
                this.p = dateB;
                if (dateB != null) {
                    this.v = Long.valueOf(h(dateB));
                }
            }
        }
        return z4;
    }

    public void serialize(x0 x0Var, f0 f0Var) throws IOException {
        x0Var.g();
        if (this.s != null) {
            x0Var.b0("sid").V(this.s.toString());
        }
        if (this.r != null) {
            x0Var.b0("did").V(this.r);
        }
        if (this.t != null) {
            x0Var.b0("init").N(this.t);
        }
        x0Var.b0("started").d0(f0Var, this.o);
        x0Var.b0("status").d0(f0Var, this.u.name().toLowerCase(Locale.ROOT));
        if (this.v != null) {
            x0Var.b0("seq").Q(this.v);
        }
        x0Var.b0("errors").M(this.q.intValue());
        if (this.w != null) {
            x0Var.b0("duration").Q(this.w);
        }
        if (this.p != null) {
            x0Var.b0("timestamp").d0(f0Var, this.p);
        }
        x0Var.b0("attrs");
        x0Var.g();
        x0Var.b0(BuildConfig.BUILD_TYPE).d0(f0Var, this.A);
        if (this.z != null) {
            x0Var.b0("environment").d0(f0Var, this.z);
        }
        if (this.x != null) {
            x0Var.b0("ip_address").d0(f0Var, this.x);
        }
        if (this.y != null) {
            x0Var.b0("user_agent").d0(f0Var, this.y);
        }
        x0Var.m();
        Map<String, Object> map = this.C;
        if (map != null) {
            for (String str : map.keySet()) {
                Object obj = this.C.get(str);
                x0Var.b0(str);
                x0Var.d0(f0Var, obj);
            }
        }
        x0Var.m();
    }

    public t3(String str, pk.u uVar, String str2, String str3) {
        this(b.Ok, g.b(), g.b(), 0, str, UUID.randomUUID(), Boolean.TRUE, null, null, uVar != null ? uVar.g() : null, null, str2, str3);
    }
}
