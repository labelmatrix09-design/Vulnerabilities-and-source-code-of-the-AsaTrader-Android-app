package hk;

import java.io.Closeable;

/* JADX INFO: compiled from: ShutdownHookIntegration.java */
/* JADX INFO: loaded from: /home/kali/Desktop/bunt/agah/dex_files/classes2.dex */
public final class v3 implements o0, Closeable {
    public final Runtime o;
    public Thread p;

    public v3(Runtime runtime) {
        this.o = (Runtime) rk.j.a(runtime, "Runtime is required");
    }

    public static /* synthetic */ void f(e0 e0Var, j3 j3Var) {
        e0Var.c(j3Var.getFlushTimeoutMillis());
    }

    @Override // hk.o0
    public void a(final e0 e0Var, final j3 j3Var) {
        rk.j.a(e0Var, "Hub is required");
        rk.j.a(j3Var, "SentryOptions is required");
        if (!j3Var.isEnableShutdownHook()) {
            j3Var.getLogger().a(i3.INFO, "enableShutdownHook is disabled.", new Object[0]);
            return;
        }
        Thread thread = new Thread(new Runnable() { // from class: hk.u3
            @Override // java.lang.Runnable
            public final void run() {
                v3.f(e0Var, j3Var);
            }
        });
        this.p = thread;
        this.o.addShutdownHook(thread);
        j3Var.getLogger().a(i3.DEBUG, "ShutdownHookIntegration installed.", new Object[0]);
    }

    @Override // java.io.Closeable, java.lang.AutoCloseable
    public void close() {
        Thread thread = this.p;
        if (thread != null) {
            this.o.removeShutdownHook(thread);
        }
    }

    public v3() {
        this(Runtime.getRuntime());
    }
}
