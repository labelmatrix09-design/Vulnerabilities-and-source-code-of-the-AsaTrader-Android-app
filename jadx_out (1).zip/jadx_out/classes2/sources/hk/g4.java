package hk;

import java.security.SecureRandom;

/* JADX INFO: compiled from: TracesSampler.java */
/* JADX INFO: loaded from: /home/kali/Desktop/bunt/agah/dex_files/classes2.dex */
public final class g4 {
    public final j3 a;
    public final SecureRandom b;

    public g4(j3 j3Var) {
        this((j3) rk.j.a(j3Var, "options are required"), new SecureRandom());
    }

    public boolean a(v1 v1Var) {
        Double dA;
        if (v1Var.a().d() != null) {
            return v1Var.a().d().booleanValue();
        }
        if (this.a.getTracesSampler() != null && (dA = this.a.getTracesSampler().a(v1Var)) != null) {
            return b(dA);
        }
        if (v1Var.a().n() != null) {
            return v1Var.a().n().booleanValue();
        }
        if (this.a.getTracesSampleRate() != null) {
            return b(this.a.getTracesSampleRate());
        }
        return false;
    }

    public final boolean b(Double d) {
        return d.doubleValue() >= this.b.nextDouble();
    }

    public g4(j3 j3Var, SecureRandom secureRandom) {
        this.a = j3Var;
        this.b = secureRandom;
    }
}
