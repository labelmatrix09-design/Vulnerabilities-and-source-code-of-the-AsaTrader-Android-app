package hk;

import org.jetbrains.annotations.ApiStatus;

/* JADX INFO: compiled from: ITransactionProfiler.java */
/* JADX INFO: loaded from: /home/kali/Desktop/bunt/agah/dex_files/classes2.dex */
@ApiStatus.Internal
public interface m0 {
    s1 a(l0 l0Var);

    void b(l0 l0Var);
}
