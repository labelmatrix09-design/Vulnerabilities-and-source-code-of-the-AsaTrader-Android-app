package hk;

import java.util.Locale;

/* JADX INFO: compiled from: SentryLevel.java */
/* JADX INFO: loaded from: /home/kali/Desktop/bunt/agah/dex_files/classes2.dex */
public final class i3$a implements p0<i3> {
    @Override // hk.p0
    /* JADX INFO: renamed from: b, reason: merged with bridge method [inline-methods] */
    public i3 a(v0 v0Var, f0 f0Var) {
        return i3.valueOf(v0Var.N().toUpperCase(Locale.ROOT));
    }
}
