package hk;

import java.util.Date;

/* JADX INFO: compiled from: NoOpHub.java */
/* JADX INFO: loaded from: /home/kali/Desktop/bunt/agah/dex_files/classes2.dex */
public final class d1 implements e0 {
    public static final d1 b = new d1();
    public final j3 a = j3.empty();

    public static d1 a() {
        return b;
    }

    @Override // hk.e0
    public void c(long j) {
    }

    @Override // hk.e0
    public void close() {
    }

    @Override // hk.e0
    public pk.m d(l2 l2Var, u uVar) {
        return pk.m.p;
    }

    @Override // hk.e0
    public /* synthetic */ void e(c cVar) {
        d0.a(this, cVar);
    }

    @Override // hk.e0
    public void f(x1 x1Var) {
    }

    @Override // hk.e0
    public /* synthetic */ pk.m g(pk.t tVar, f4 f4Var, u uVar) {
        return d0.c(this, tVar, f4Var, uVar);
    }

    @Override // hk.e0
    public j3 h() {
        return this.a;
    }

    @Override // hk.e0
    public pk.m i(e3 e3Var, u uVar) {
        return pk.m.p;
    }

    @Override // hk.e0
    public boolean isEnabled() {
        return false;
    }

    @Override // hk.e0
    public /* synthetic */ l0 j(String str, String str2, Date date, boolean z, i4 i4Var) {
        return d0.d(this, str, str2, date, z, i4Var);
    }

    @Override // hk.e0
    public /* synthetic */ pk.m k(Throwable th2) {
        return d0.b(this, th2);
    }

    @Override // hk.e0
    public void l(c cVar, u uVar) {
    }

    @Override // hk.e0
    public l0 m(h4 h4Var, e eVar, boolean z, Date date, boolean z4, Long l, boolean z5, i4 i4Var) {
        return k1.k();
    }

    @Override // hk.e0
    public /* synthetic */ l0 n(String str, String str2, boolean z, Long l, boolean z4) {
        return d0.e(this, str, str2, z, l, z4);
    }

    @Override // hk.e0
    public pk.m o(Throwable th2, u uVar) {
        return pk.m.p;
    }

    @Override // hk.e0
    public void p() {
    }

    @Override // hk.e0
    public void q() {
    }

    @Override // hk.e0
    public pk.m r(pk.t tVar, f4 f4Var, u uVar, s1 s1Var) {
        return pk.m.p;
    }

    @Override // hk.e0
    public void s(Throwable th2, k0 k0Var, String str) {
    }

    @Override // hk.e0
    /* JADX INFO: renamed from: clone, reason: merged with bridge method [inline-methods] */
    public e0 m1clone() {
        return b;
    }
}
