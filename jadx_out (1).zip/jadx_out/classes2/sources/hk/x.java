package hk;

import java.net.InetAddress;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;
import java.util.concurrent.atomic.AtomicBoolean;

/* JADX INFO: compiled from: HostnameCache.java */
/* JADX INFO: loaded from: /home/kali/Desktop/bunt/agah/dex_files/classes2.dex */
public final class x {
    public static final long g = TimeUnit.HOURS.toMillis(5);
    public static final long h = TimeUnit.SECONDS.toMillis(1);
    public static x i;
    public final long a;
    public volatile String b;
    public volatile long c;
    public final AtomicBoolean d;
    public final Callable<InetAddress> e;
    public final ExecutorService f;

    /* JADX INFO: compiled from: HostnameCache.java */
    public static final class b implements ThreadFactory {
        public int a;

        public b() {
        }

        @Override // java.util.concurrent.ThreadFactory
        public Thread newThread(Runnable runnable) {
            StringBuilder sb = new StringBuilder();
            sb.append("SentryHostnameCache-");
            int i = this.a;
            this.a = i + 1;
            sb.append(i);
            Thread thread = new Thread(runnable, sb.toString());
            thread.setDaemon(true);
            return thread;
        }
    }

    public x() {
        this(g);
    }

    public static x e() {
        if (i == null) {
            i = new x();
        }
        return i;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ Void h() {
        try {
            this.b = this.e.call().getCanonicalHostName();
            this.c = System.currentTimeMillis() + this.a;
            return null;
        } finally {
            this.d.set(false);
        }
    }

    public void c() {
        this.f.shutdown();
    }

    public String d() {
        if (this.c < System.currentTimeMillis() && this.d.compareAndSet(false, true)) {
            i();
        }
        return this.b;
    }

    public final void f() {
        this.c = System.currentTimeMillis() + TimeUnit.SECONDS.toMillis(1L);
    }

    public final void i() {
        try {
            this.f.submit(new Callable() { // from class: hk.v
                @Override // java.util.concurrent.Callable
                public final Object call() {
                    return this.a.h();
                }
            }).get(h, TimeUnit.MILLISECONDS);
        } catch (InterruptedException unused) {
            Thread.currentThread().interrupt();
            f();
        } catch (RuntimeException | ExecutionException | TimeoutException unused2) {
            f();
        }
    }

    public x(long j) {
        this(j, new Callable() { // from class: hk.w
            @Override // java.util.concurrent.Callable
            public final Object call() {
                return InetAddress.getLocalHost();
            }
        });
    }

    public x(long j, Callable<InetAddress> callable) {
        this.d = new AtomicBoolean(false);
        this.f = Executors.newSingleThreadExecutor(new b());
        this.a = j;
        this.e = (Callable) rk.j.a(callable, "getLocalhost is required");
        i();
    }
}
