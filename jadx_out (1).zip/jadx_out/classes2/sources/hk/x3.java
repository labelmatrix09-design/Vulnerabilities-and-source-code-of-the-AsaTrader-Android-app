package hk;

import java.io.IOException;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import org.jetbrains.annotations.ApiStatus;

/* JADX INFO: compiled from: SpanContext.java */
/* JADX INFO: loaded from: /home/kali/Desktop/bunt/agah/dex_files/classes2.dex */
public class x3 implements z0 {
    public final pk.m o;
    public final z3 p;
    public final z3 q;
    public transient Boolean r;
    public String s;
    public String t;
    public a4 u;
    public Map<String, String> v;
    public Map<String, Object> w;

    /* JADX INFO: compiled from: SpanContext.java */
    public static final class a implements p0<x3> {
        @Override // hk.p0
        /* JADX INFO: renamed from: b, reason: merged with bridge method [inline-methods] */
        public x3 a(v0 v0Var, f0 f0Var) throws IOException {
            v0Var.b();
            ConcurrentHashMap concurrentHashMap = null;
            pk.m mVarA = null;
            z3 z3VarB = null;
            String strN = null;
            z3 z3Var = null;
            String strN2 = null;
            a4 a4Var = null;
            Map<String, String> mapB = null;
            while (v0Var.V() == uk.b.NAME) {
                String strF = v0Var.F();
                strF.hashCode();
                switch (strF) {
                    case "span_id":
                        z3VarB = new z3.a().a(v0Var, f0Var);
                        break;
                    case "parent_span_id":
                        z3Var = (z3) v0Var.R0(f0Var, new z3.a());
                        break;
                    case "description":
                        strN2 = v0Var.N();
                        break;
                    case "status":
                        a4Var = (a4) v0Var.R0(f0Var, new a4.a());
                        break;
                    case "op":
                        strN = v0Var.N();
                        break;
                    case "tags":
                        mapB = rk.a.b((Map) v0Var.Q0());
                        break;
                    case "trace_id":
                        mVarA = new pk.m.a().a(v0Var, f0Var);
                        break;
                    default:
                        if (concurrentHashMap == null) {
                            concurrentHashMap = new ConcurrentHashMap();
                        }
                        v0Var.V0(f0Var, concurrentHashMap, strF);
                        break;
                }
            }
            if (mVarA == null) {
                IllegalStateException illegalStateException = new IllegalStateException("Missing required field \"trace_id\"");
                f0Var.b(i3.ERROR, "Missing required field \"trace_id\"", illegalStateException);
                throw illegalStateException;
            }
            if (z3VarB == null) {
                IllegalStateException illegalStateException2 = new IllegalStateException("Missing required field \"span_id\"");
                f0Var.b(i3.ERROR, "Missing required field \"span_id\"", illegalStateException2);
                throw illegalStateException2;
            }
            if (strN == null) {
                IllegalStateException illegalStateException3 = new IllegalStateException("Missing required field \"op\"");
                f0Var.b(i3.ERROR, "Missing required field \"op\"", illegalStateException3);
                throw illegalStateException3;
            }
            x3 x3Var = new x3(mVarA, z3VarB, strN, z3Var, null);
            x3Var.i(strN2);
            x3Var.k(a4Var);
            if (mapB != null) {
                x3Var.v = mapB;
            }
            x3Var.l(concurrentHashMap);
            v0Var.m();
            return x3Var;
        }
    }

    public x3(String str) {
        this(new pk.m(), new z3(), str, null, null);
    }

    public String a() {
        return this.t;
    }

    public String b() {
        return this.s;
    }

    public z3 c() {
        return this.q;
    }

    public Boolean d() {
        return this.r;
    }

    public z3 e() {
        return this.p;
    }

    public a4 f() {
        return this.u;
    }

    public Map<String, String> g() {
        return this.v;
    }

    public pk.m h() {
        return this.o;
    }

    public void i(String str) {
        this.t = str;
    }

    @ApiStatus.Internal
    public void j(Boolean bool) {
        this.r = bool;
    }

    public void k(a4 a4Var) {
        this.u = a4Var;
    }

    public void l(Map<String, Object> map) {
        this.w = map;
    }

    public void serialize(x0 x0Var, f0 f0Var) throws IOException {
        x0Var.g();
        x0Var.b0("trace_id");
        this.o.serialize(x0Var, f0Var);
        x0Var.b0("span_id");
        this.p.serialize(x0Var, f0Var);
        if (this.q != null) {
            x0Var.b0("parent_span_id");
            this.q.serialize(x0Var, f0Var);
        }
        x0Var.b0("op").V(this.s);
        if (this.t != null) {
            x0Var.b0("description").V(this.t);
        }
        if (this.u != null) {
            x0Var.b0("status").d0(f0Var, this.u);
        }
        if (!this.v.isEmpty()) {
            x0Var.b0("tags").d0(f0Var, this.v);
        }
        Map<String, Object> map = this.w;
        if (map != null) {
            for (String str : map.keySet()) {
                x0Var.b0(str).d0(f0Var, this.w.get(str));
            }
        }
        x0Var.m();
    }

    public x3(pk.m mVar, z3 z3Var, String str, z3 z3Var2, Boolean bool) {
        this(mVar, z3Var, z3Var2, str, null, bool, null);
    }

    @ApiStatus.Internal
    public x3(pk.m mVar, z3 z3Var, z3 z3Var2, String str, String str2, Boolean bool, a4 a4Var) {
        this.v = new ConcurrentHashMap();
        this.o = (pk.m) rk.j.a(mVar, "traceId is required");
        this.p = (z3) rk.j.a(z3Var, "spanId is required");
        this.s = (String) rk.j.a(str, "operation is required");
        this.q = z3Var2;
        this.r = bool;
        this.t = str2;
        this.u = a4Var;
    }

    public x3(x3 x3Var) {
        this.v = new ConcurrentHashMap();
        this.o = x3Var.o;
        this.p = x3Var.p;
        this.q = x3Var.q;
        this.r = x3Var.r;
        this.s = x3Var.s;
        this.t = x3Var.t;
        this.u = x3Var.u;
        Map<String, String> mapB = rk.a.b(x3Var.v);
        if (mapB != null) {
            this.v = mapB;
        }
    }
}
