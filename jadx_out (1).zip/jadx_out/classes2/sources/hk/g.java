package hk;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.text.ParseException;
import java.text.ParsePosition;
import java.util.Calendar;
import java.util.Date;
import org.jetbrains.annotations.ApiStatus;

/* JADX INFO: compiled from: DateUtils.java */
/* JADX INFO: loaded from: /home/kali/Desktop/bunt/agah/dex_files/classes2.dex */
@ApiStatus.Internal
public final class g {
    public static double a(Date date) {
        return g(date.getTime());
    }

    public static Date b() {
        return Calendar.getInstance(tk.a.a).getTime();
    }

    public static Date c(long j) {
        Calendar calendar = Calendar.getInstance(tk.a.a);
        calendar.setTimeInMillis(j);
        return calendar.getTime();
    }

    public static Date d(String str) {
        try {
            return tk.a.f(str, new ParsePosition(0));
        } catch (ParseException unused) {
            throw new IllegalArgumentException("timestamp is not ISO format " + str);
        }
    }

    public static Date e(String str) {
        try {
            return c(new BigDecimal(str).setScale(3, RoundingMode.DOWN).movePointRight(3).longValue());
        } catch (NumberFormatException unused) {
            throw new IllegalArgumentException("timestamp is not millis format " + str);
        }
    }

    public static String f(Date date) {
        return tk.a.b(date, true);
    }

    public static double g(double d) {
        return d / 1000.0d;
    }

    public static double h(double d) {
        return d / 1000000.0d;
    }
}
