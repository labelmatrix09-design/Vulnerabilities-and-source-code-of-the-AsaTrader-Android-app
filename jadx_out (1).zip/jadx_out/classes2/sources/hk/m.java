package hk;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.StringReader;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.Arrays;
import org.jetbrains.annotations.ApiStatus;

/* JADX INFO: compiled from: EnvelopeReader.java */
/* JADX INFO: loaded from: /home/kali/Desktop/bunt/agah/dex_files/classes2.dex */
@ApiStatus.Internal
public final class m implements b0 {
    public static final Charset b = Charset.forName("UTF-8");
    public final j0 a;

    public m(j0 j0Var) {
        this.a = j0Var;
    }

    @Override // hk.b0
    public l2 a(InputStream inputStream) throws IOException {
        byte[] bArr = new byte[1024];
        ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
        int i = -1;
        int i3 = 0;
        while (true) {
            try {
                int i5 = inputStream.read(bArr);
                if (i5 <= 0) {
                    break;
                }
                for (int i6 = 0; i == -1 && i6 < i5; i6++) {
                    if (bArr[i6] == 10) {
                        i = i3 + i6;
                        break;
                    }
                }
                byteArrayOutputStream.write(bArr, 0, i5);
                i3 += i5;
            } catch (Throwable th2) {
                try {
                    byteArrayOutputStream.close();
                } catch (Throwable unused) {
                }
                throw th2;
            }
        }
        byte[] byteArray = byteArrayOutputStream.toByteArray();
        if (byteArray.length == 0) {
            throw new IllegalArgumentException("Empty stream.");
        }
        if (i == -1) {
            throw new IllegalArgumentException("Envelope contains no header.");
        }
        m2 m2VarB = b(byteArray, 0, i);
        if (m2VarB == null) {
            throw new IllegalArgumentException("Envelope header is null.");
        }
        int i7 = i + 1;
        ArrayList arrayList = new ArrayList();
        while (true) {
            int i8 = i7;
            while (true) {
                if (i8 >= byteArray.length) {
                    i8 = -1;
                    break;
                }
                if (byteArray[i8] == 10) {
                    break;
                }
                i8++;
            }
            if (i8 == -1) {
                throw new IllegalArgumentException("Invalid envelope. Item at index '" + arrayList.size() + "'. has no header delimiter.");
            }
            d3 d3VarC = c(byteArray, i7, i8 - i7);
            if (d3VarC == null || d3VarC.a() <= 0) {
                throw new IllegalArgumentException("Item header at index '" + arrayList.size() + "' is null or empty.");
            }
            int iA = d3VarC.a() + i8 + 1;
            if (iA > byteArray.length) {
                throw new IllegalArgumentException("Invalid length for item at index '" + arrayList.size() + "'. Item is '" + iA + "' bytes. There are '" + byteArray.length + "' in the buffer.");
            }
            arrayList.add(new c3(d3VarC, Arrays.copyOfRange(byteArray, i8 + 1, iA)));
            if (iA == byteArray.length) {
                break;
            }
            i7 = iA + 1;
            if (i7 == byteArray.length) {
                if (byteArray[iA] == 10) {
                    break;
                }
                throw new IllegalArgumentException("Envelope has invalid data following an item.");
            }
        }
        l2 l2Var = new l2(m2VarB, arrayList);
        byteArrayOutputStream.close();
        return l2Var;
    }

    public final m2 b(byte[] bArr, int i, int i3) {
        return (m2) this.a.c(new StringReader(new String(bArr, i, i3, b)), m2.class);
    }

    public final d3 c(byte[] bArr, int i, int i3) {
        return (d3) this.a.c(new StringReader(new String(bArr, i, i3, b)), d3.class);
    }
}
