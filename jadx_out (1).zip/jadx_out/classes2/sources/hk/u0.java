package hk;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import org.jetbrains.annotations.ApiStatus;

/* JADX INFO: compiled from: JsonObjectDeserializer.java */
/* JADX INFO: loaded from: /home/kali/Desktop/bunt/agah/dex_files/classes2.dex */
@ApiStatus.Internal
public final class u0 {
    public final ArrayList<c> a = new ArrayList<>();

    /* JADX INFO: compiled from: JsonObjectDeserializer.java */
    public static /* synthetic */ class a {
        public static final /* synthetic */ int[] a;

        static {
            int[] iArr = new int[uk.b.values().length];
            a = iArr;
            try {
                iArr[uk.b.BEGIN_ARRAY.ordinal()] = 1;
            } catch (NoSuchFieldError unused) {
            }
            try {
                a[uk.b.END_ARRAY.ordinal()] = 2;
            } catch (NoSuchFieldError unused2) {
            }
            try {
                a[uk.b.BEGIN_OBJECT.ordinal()] = 3;
            } catch (NoSuchFieldError unused3) {
            }
            try {
                a[uk.b.END_OBJECT.ordinal()] = 4;
            } catch (NoSuchFieldError unused4) {
            }
            try {
                a[uk.b.NAME.ordinal()] = 5;
            } catch (NoSuchFieldError unused5) {
            }
            try {
                a[uk.b.STRING.ordinal()] = 6;
            } catch (NoSuchFieldError unused6) {
            }
            try {
                a[uk.b.NUMBER.ordinal()] = 7;
            } catch (NoSuchFieldError unused7) {
            }
            try {
                a[uk.b.BOOLEAN.ordinal()] = 8;
            } catch (NoSuchFieldError unused8) {
            }
            try {
                a[uk.b.NULL.ordinal()] = 9;
            } catch (NoSuchFieldError unused9) {
            }
            try {
                a[uk.b.END_DOCUMENT.ordinal()] = 10;
            } catch (NoSuchFieldError unused10) {
            }
        }
    }

    /* JADX INFO: compiled from: JsonObjectDeserializer.java */
    public interface b {
        Object a();
    }

    /* JADX INFO: compiled from: JsonObjectDeserializer.java */
    public interface c {
        Object getValue();
    }

    /* JADX INFO: compiled from: JsonObjectDeserializer.java */
    public static final class f implements c {
        public final String a;

        public f(String str) {
            this.a = str;
        }

        @Override // hk.u0.c
        public Object getValue() {
            return this.a;
        }
    }

    /* JADX INFO: compiled from: JsonObjectDeserializer.java */
    public static final class g implements c {
        public final Object a;

        public g(Object obj) {
            this.a = obj;
        }

        @Override // hk.u0.c
        public Object getValue() {
            return this.a;
        }
    }

    public static /* synthetic */ Object i() {
        return null;
    }

    public Object c(v0 v0Var) {
        k(v0Var);
        c cVarD = d();
        if (cVarD != null) {
            return cVarD.getValue();
        }
        return null;
    }

    public final c d() {
        if (this.a.isEmpty()) {
            return null;
        }
        ArrayList<c> arrayList = this.a;
        return arrayList.get(arrayList.size() - 1);
    }

    public final boolean e() {
        if (g()) {
            return true;
        }
        c cVarD = d();
        l();
        if (!(d() instanceof f)) {
            if (!(d() instanceof d)) {
                return false;
            }
            d dVar = (d) d();
            if (cVarD == null || dVar == null) {
                return false;
            }
            dVar.a.add(cVarD.getValue());
            return false;
        }
        f fVar = (f) d();
        l();
        e eVar = (e) d();
        if (fVar == null || cVarD == null || eVar == null) {
            return false;
        }
        eVar.a.put(fVar.a, cVarD.getValue());
        return false;
    }

    public final boolean f(b bVar) {
        Object objA = bVar.a();
        if (d() == null && objA != null) {
            m(new g(objA));
            return true;
        }
        if (d() instanceof f) {
            f fVar = (f) d();
            l();
            ((e) d()).a.put(fVar.a, objA);
            return false;
        }
        if (!(d() instanceof d)) {
            return false;
        }
        ((d) d()).a.add(objA);
        return false;
    }

    public final boolean g() {
        return this.a.size() == 1;
    }

    /* JADX INFO: renamed from: j, reason: merged with bridge method [inline-methods] */
    public final Object h(v0 v0Var) {
        try {
            try {
                return Integer.valueOf(v0Var.A());
            } catch (Exception unused) {
                return Double.valueOf(v0Var.z());
            }
        } catch (Exception unused2) {
            return Long.valueOf(v0Var.B());
        }
    }

    /* JADX WARN: Can't fix incorrect switch cases order, some code will duplicate */
    public final void k(final v0 v0Var) throws IOException {
        boolean zE;
        a aVar = null;
        switch (a.a[v0Var.V().ordinal()]) {
            case 1:
                v0Var.a();
                m(new d(aVar));
                zE = false;
                break;
            case 2:
                v0Var.j();
                zE = e();
                break;
            case 3:
                v0Var.b();
                m(new e(aVar));
                zE = false;
                break;
            case 4:
                v0Var.m();
                zE = e();
                break;
            case 5:
                m(new f(v0Var.F()));
                zE = false;
                break;
            case 6:
                zE = f(new b() { // from class: hk.s0
                    @Override // hk.u0.b
                    public final Object a() {
                        return v0Var.N();
                    }
                });
                break;
            case 7:
                zE = f(new b() { // from class: hk.q0
                    @Override // hk.u0.b
                    public final Object a() {
                        return this.a.h(v0Var);
                    }
                });
                break;
            case 8:
                zE = f(new b() { // from class: hk.r0
                    @Override // hk.u0.b
                    public final Object a() {
                        return Boolean.valueOf(v0Var.x());
                    }
                });
                break;
            case 9:
                v0Var.L();
                zE = f(new b() { // from class: hk.t0
                    @Override // hk.u0.b
                    public final Object a() {
                        return u0.i();
                    }
                });
                break;
            case 10:
                zE = true;
                break;
            default:
                zE = false;
                break;
        }
        if (zE) {
            return;
        }
        k(v0Var);
    }

    public final void l() {
        if (this.a.isEmpty()) {
            return;
        }
        ArrayList<c> arrayList = this.a;
        arrayList.remove(arrayList.size() - 1);
    }

    public final void m(c cVar) {
        this.a.add(cVar);
    }

    /* JADX INFO: compiled from: JsonObjectDeserializer.java */
    public static final class d implements c {
        public final ArrayList<Object> a;

        public d() {
            this.a = new ArrayList<>();
        }

        @Override // hk.u0.c
        public Object getValue() {
            return this.a;
        }

        public /* synthetic */ d(a aVar) {
            this();
        }
    }

    /* JADX INFO: compiled from: JsonObjectDeserializer.java */
    public static final class e implements c {
        public final HashMap<String, Object> a;

        public e() {
            this.a = new HashMap<>();
        }

        @Override // hk.u0.c
        public Object getValue() {
            return this.a;
        }

        public /* synthetic */ e(a aVar) {
            this();
        }
    }
}
