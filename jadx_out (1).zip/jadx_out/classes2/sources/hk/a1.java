package hk;

import io.sentry.protocol.DebugImage;
import java.io.BufferedOutputStream;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.Reader;
import java.io.StringWriter;
import java.io.Writer;
import java.nio.charset.Charset;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import pk.l$a;

/* JADX INFO: compiled from: JsonSerializer.java */
/* JADX INFO: loaded from: /home/kali/Desktop/bunt/agah/dex_files/classes2.dex */
public final class a1 implements j0 {
    public static final Charset c = Charset.forName("UTF-8");
    public final j3 a;
    public final Map<Class<?>, p0<?>> b;

    public a1(j3 j3Var) {
        this.a = j3Var;
        HashMap map = new HashMap();
        this.b = map;
        map.put(pk.a.class, new pk.a.C0076a());
        map.put(c.class, new c.a());
        map.put(pk.b.class, new pk.b.a());
        map.put(pk.c.class, new pk.c.a());
        map.put(DebugImage.class, new DebugImage.a());
        map.put(io.sentry.protocol.a.class, new io.sentry.protocol.a.C0058a());
        map.put(pk.d.class, new pk.d.a());
        map.put(pk.d.b.class, new pk.d.b.a());
        map.put(pk.e.class, new pk.e.a());
        map.put(pk.f.class, new pk.f.a());
        map.put(pk.g.class, new pk.g.a());
        map.put(pk.h.class, new pk.h.a());
        map.put(pk.i.class, new pk.i.a());
        map.put(s1.class, new s1.b());
        map.put(pk.j.class, new pk.j.a());
        map.put(io.sentry.protocol.b.class, new io.sentry.protocol.b.a());
        map.put(pk.k.class, new pk.k.a());
        map.put(m2.class, new m2.a());
        map.put(d3.class, new d3.a());
        map.put(e3.class, new p0<e3>() { // from class: hk.e3$a
            @Override // hk.p0
            /* JADX INFO: renamed from: b, reason: merged with bridge method [inline-methods] */
            public e3 a(v0 v0Var, f0 f0Var) throws IOException {
                v0Var.b();
                g2 e3Var = new e3();
                g2$a g2_a = new g2$a();
                ConcurrentHashMap concurrentHashMap = null;
                while (v0Var.V() == uk.b.NAME) {
                    String strF = v0Var.F();
                    strF.hashCode();
                    switch (strF) {
                        case "debug_meta":
                            e3.l0(e3Var, (io.sentry.protocol.a) v0Var.R0(f0Var, new io.sentry.protocol.a.C0058a()));
                            break;
                        case "fingerprint":
                            List list = (List) v0Var.Q0();
                            if (list == null) {
                                break;
                            } else {
                                e3.j0(e3Var, list);
                                break;
                            }
                            break;
                        case "threads":
                            v0Var.b();
                            v0Var.F();
                            e3.f0(e3Var, new s3(v0Var.N0(f0Var, new pk.s.a())));
                            v0Var.m();
                            break;
                        case "logger":
                            e3.e0(e3Var, v0Var.S0());
                            break;
                        case "timestamp":
                            Date dateX0 = v0Var.x0(f0Var);
                            if (dateX0 == null) {
                                break;
                            } else {
                                e3.c0(e3Var, dateX0);
                                break;
                            }
                            break;
                        case "level":
                            e3.h0(e3Var, (i3) v0Var.R0(f0Var, new i3$a()));
                            break;
                        case "message":
                            e3.d0(e3Var, (pk.h) v0Var.R0(f0Var, new pk.h.a()));
                            break;
                        case "modules":
                            e3.k0(e3Var, rk.a.b((Map) v0Var.Q0()));
                            break;
                        case "exception":
                            v0Var.b();
                            v0Var.F();
                            e3.g0(e3Var, new s3(v0Var.N0(f0Var, new l$a())));
                            v0Var.m();
                            break;
                        case "transaction":
                            e3.i0(e3Var, v0Var.S0());
                            break;
                        default:
                            if (!g2_a.a(e3Var, strF, v0Var, f0Var)) {
                                if (concurrentHashMap == null) {
                                    concurrentHashMap = new ConcurrentHashMap();
                                }
                                v0Var.V0(f0Var, concurrentHashMap, strF);
                                break;
                            } else {
                                break;
                            }
                            break;
                    }
                }
                e3Var.A0(concurrentHashMap);
                v0Var.m();
                return e3Var;
            }
        });
        map.put(pk.l.class, new l$a());
        map.put(h3.class, new h3.a());
        map.put(i3.class, new i3$a());
        map.put(pk.n.class, new pk.n.a());
        map.put(pk.o.class, new pk.o.a());
        map.put(pk.p.class, new pk.p.a());
        map.put(pk.q.class, new pk.q.a());
        map.put(pk.r.class, new pk.r.a());
        map.put(pk.s.class, new pk.s.a());
        map.put(pk.t.class, new pk.t.a());
        map.put(t3.class, new t3.a());
        map.put(x3.class, new x3.a());
        map.put(z3.class, new z3.a());
        map.put(a4.class, new a4.a());
        map.put(pk.u.class, new pk.u.a());
        map.put(l4.class, new l4.a());
        map.put(mk.b.class, new mk.b.a());
    }

    @Override // hk.j0
    public <T> void a(T t, Writer writer) throws IOException {
        rk.j.a(t, "The entity is required.");
        rk.j.a(writer, "The Writer object is required.");
        f0 logger = this.a.getLogger();
        i3 i3Var = i3.DEBUG;
        if (logger.c(i3Var)) {
            this.a.getLogger().a(i3Var, "Serializing object: %s", f(t, true));
        }
        new x0(writer, this.a.getMaxDepth()).d0(this.a.getLogger(), t);
        writer.flush();
    }

    @Override // hk.j0
    public void b(l2 l2Var, OutputStream outputStream) throws IOException {
        rk.j.a(l2Var, "The SentryEnvelope object is required.");
        rk.j.a(outputStream, "The Stream object is required.");
        BufferedWriter bufferedWriter = new BufferedWriter(new OutputStreamWriter(new BufferedOutputStream(outputStream), c));
        try {
            l2Var.b().serialize(new x0(bufferedWriter, this.a.getMaxDepth()), this.a.getLogger());
            bufferedWriter.write("\n");
            for (c3 c3Var : l2Var.c()) {
                try {
                    byte[] bArrV = c3Var.v();
                    c3Var.w().serialize(new x0(bufferedWriter, this.a.getMaxDepth()), this.a.getLogger());
                    bufferedWriter.write("\n");
                    bufferedWriter.flush();
                    outputStream.write(bArrV);
                    bufferedWriter.write("\n");
                } catch (Exception e) {
                    this.a.getLogger().b(i3.ERROR, "Failed to create envelope item. Dropping it.", e);
                }
            }
            bufferedWriter.flush();
        } catch (Throwable th2) {
            bufferedWriter.flush();
            throw th2;
        }
    }

    @Override // hk.j0
    public <T> T c(Reader reader, Class<T> cls) {
        try {
            v0 v0Var = new v0(reader);
            p0<?> p0Var = this.b.get(cls);
            if (p0Var != null) {
                return cls.cast(p0Var.a(v0Var, this.a.getLogger()));
            }
            return null;
        } catch (Exception e) {
            this.a.getLogger().b(i3.ERROR, "Error when deserializing", e);
            return null;
        }
    }

    @Override // hk.j0
    public l2 d(InputStream inputStream) {
        rk.j.a(inputStream, "The InputStream object is required.");
        try {
            return this.a.getEnvelopeReader().a(inputStream);
        } catch (IOException e) {
            this.a.getLogger().b(i3.ERROR, "Error deserializing envelope.", e);
            return null;
        }
    }

    @Override // hk.j0
    public String e(Map<String, Object> map) {
        return f(map, false);
    }

    public final String f(Object obj, boolean z) {
        StringWriter stringWriter = new StringWriter();
        x0 x0Var = new x0(stringWriter, this.a.getMaxDepth());
        if (z) {
            x0Var.F("\t");
        }
        x0Var.d0(this.a.getLogger(), obj);
        return stringWriter.toString();
    }
}
