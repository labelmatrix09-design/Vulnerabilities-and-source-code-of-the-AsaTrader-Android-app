package hk;

import java.io.IOException;
import java.util.Arrays;
import java.util.Collection;
import java.util.Date;
import java.util.Iterator;
import java.util.Map;
import java.util.TimeZone;
import org.jetbrains.annotations.ApiStatus;

/* JADX INFO: compiled from: JsonObjectSerializer.java */
/* JADX INFO: loaded from: /home/kali/Desktop/bunt/agah/dex_files/classes2.dex */
@ApiStatus.Internal
public final class w0 {
    public final y0 a;

    public w0(int i) {
        this.a = new y0(i);
    }

    public void a(x0 x0Var, f0 f0Var, Object obj) throws IOException {
        if (obj == null) {
            x0Var.u();
            return;
        }
        if (obj instanceof Character) {
            x0Var.V(Character.toString(((Character) obj).charValue()));
            return;
        }
        if (obj instanceof String) {
            x0Var.V((String) obj);
            return;
        }
        if (obj instanceof Boolean) {
            x0Var.Y(((Boolean) obj).booleanValue());
            return;
        }
        if (obj instanceof Number) {
            x0Var.Q((Number) obj);
            return;
        }
        if (obj instanceof Date) {
            c(x0Var, f0Var, (Date) obj);
            return;
        }
        if (obj instanceof TimeZone) {
            e(x0Var, f0Var, (TimeZone) obj);
            return;
        }
        if (obj instanceof z0) {
            ((z0) obj).serialize(x0Var, f0Var);
            return;
        }
        if (obj instanceof Collection) {
            b(x0Var, f0Var, (Collection) obj);
            return;
        }
        if (obj.getClass().isArray()) {
            b(x0Var, f0Var, Arrays.asList((Object[]) obj));
            return;
        }
        if (obj instanceof Map) {
            d(x0Var, f0Var, (Map) obj);
            return;
        }
        try {
            a(x0Var, f0Var, this.a.d(obj, f0Var));
        } catch (Exception e) {
            f0Var.b(i3.ERROR, "Failed serializing unknown object.", e);
            x0Var.V("[OBJECT]");
        }
    }

    public final void b(x0 x0Var, f0 f0Var, Collection<?> collection) throws IOException {
        x0Var.f();
        Iterator<?> it = collection.iterator();
        while (it.hasNext()) {
            a(x0Var, f0Var, it.next());
        }
        x0Var.j();
    }

    public final void c(x0 x0Var, f0 f0Var, Date date) throws IOException {
        try {
            x0Var.V(g.f(date));
        } catch (Exception e) {
            f0Var.b(i3.ERROR, "Error when serializing Date", e);
            x0Var.u();
        }
    }

    public final void d(x0 x0Var, f0 f0Var, Map<?, ?> map) throws IOException {
        x0Var.g();
        for (Object obj : map.keySet()) {
            if (obj instanceof String) {
                x0Var.b0((String) obj);
                a(x0Var, f0Var, map.get(obj));
            }
        }
        x0Var.m();
    }

    public final void e(x0 x0Var, f0 f0Var, TimeZone timeZone) throws IOException {
        try {
            x0Var.V(timeZone.getID());
        } catch (Exception e) {
            f0Var.b(i3.ERROR, "Error when serializing TimeZone", e);
            x0Var.u();
        }
    }
}
