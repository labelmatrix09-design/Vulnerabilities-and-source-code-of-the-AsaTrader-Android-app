package hk;

import io.github.inflationx.calligraphy3.BuildConfig;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.Reader;
import java.io.Writer;
import java.util.Map;

/* JADX INFO: compiled from: NoOpSerializer.java */
/* JADX INFO: loaded from: /home/kali/Desktop/bunt/agah/dex_files/classes2.dex */
public final class i1 implements j0 {
    public static final i1 a = new i1();

    public static i1 f() {
        return a;
    }

    @Override // hk.j0
    public <T> void a(T t, Writer writer) {
    }

    @Override // hk.j0
    public void b(l2 l2Var, OutputStream outputStream) {
    }

    @Override // hk.j0
    public <T> T c(Reader reader, Class<T> cls) {
        return null;
    }

    @Override // hk.j0
    public l2 d(InputStream inputStream) {
        return null;
    }

    @Override // hk.j0
    public String e(Map<String, Object> map) {
        return BuildConfig.FLAVOR;
    }
}
