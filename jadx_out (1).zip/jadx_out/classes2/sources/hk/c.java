package hk;

import java.io.IOException;
import java.util.Date;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import org.jetbrains.annotations.ApiStatus;

/* JADX INFO: compiled from: Breadcrumb.java */
/* JADX INFO: loaded from: /home/kali/Desktop/bunt/agah/dex_files/classes2.dex */
public final class c implements z0 {
    public final Date o;
    public String p;
    public String q;
    public Map<String, Object> r;
    public String s;
    public i3 t;
    public Map<String, Object> u;

    /* JADX INFO: compiled from: Breadcrumb.java */
    public static final class a implements p0<c> {
        @Override // hk.p0
        /* JADX INFO: renamed from: b, reason: merged with bridge method [inline-methods] */
        public c a(v0 v0Var, f0 f0Var) throws IOException {
            v0Var.b();
            Date dateB = g.b();
            Map concurrentHashMap = new ConcurrentHashMap();
            String strS0 = null;
            String strS1 = null;
            String strS2 = null;
            i3 i3VarA = null;
            ConcurrentHashMap concurrentHashMap2 = null;
            while (v0Var.V() == uk.b.NAME) {
                String strF = v0Var.F();
                strF.hashCode();
                switch (strF) {
                    case "data":
                        Map mapB = rk.a.b((Map) v0Var.Q0());
                        if (mapB == null) {
                            break;
                        } else {
                            concurrentHashMap = mapB;
                            break;
                        }
                        break;
                    case "type":
                        strS1 = v0Var.S0();
                        break;
                    case "category":
                        strS2 = v0Var.S0();
                        break;
                    case "timestamp":
                        Date dateX0 = v0Var.x0(f0Var);
                        if (dateX0 == null) {
                            break;
                        } else {
                            dateB = dateX0;
                            break;
                        }
                        break;
                    case "level":
                        try {
                            i3VarA = new i3$a().a(v0Var, f0Var);
                            break;
                        } catch (Exception e) {
                            f0Var.d(i3.ERROR, e, "Error when deserializing SentryLevel", new Object[0]);
                            break;
                        }
                        break;
                    case "message":
                        strS0 = v0Var.S0();
                        break;
                    default:
                        if (concurrentHashMap2 == null) {
                            concurrentHashMap2 = new ConcurrentHashMap();
                        }
                        v0Var.V0(f0Var, concurrentHashMap2, strF);
                        break;
                }
            }
            c cVar = new c(dateB);
            cVar.p = strS0;
            cVar.q = strS1;
            cVar.r = concurrentHashMap;
            cVar.s = strS2;
            cVar.t = i3VarA;
            cVar.q(concurrentHashMap2);
            v0Var.m();
            return cVar;
        }
    }

    public c(Date date) {
        this.r = new ConcurrentHashMap();
        this.o = date;
    }

    public static c r(String str, String str2, String str3, Map<String, Object> map) {
        c cVar = new c();
        cVar.p("user");
        cVar.l("ui." + str);
        if (str2 != null) {
            cVar.m("view.id", str2);
        }
        if (str3 != null) {
            cVar.m("view.class", str3);
        }
        for (Map.Entry<String, Object> entry : map.entrySet()) {
            cVar.g().put(entry.getKey(), entry.getValue());
        }
        cVar.n(i3.INFO);
        return cVar;
    }

    public String f() {
        return this.s;
    }

    @ApiStatus.Internal
    public Map<String, Object> g() {
        return this.r;
    }

    public i3 h() {
        return this.t;
    }

    public String i() {
        return this.p;
    }

    public Date j() {
        return (Date) this.o.clone();
    }

    public String k() {
        return this.q;
    }

    public void l(String str) {
        this.s = str;
    }

    public void m(String str, Object obj) {
        this.r.put(str, obj);
    }

    public void n(i3 i3Var) {
        this.t = i3Var;
    }

    public void o(String str) {
        this.p = str;
    }

    public void p(String str) {
        this.q = str;
    }

    public void q(Map<String, Object> map) {
        this.u = map;
    }

    public void serialize(x0 x0Var, f0 f0Var) throws IOException {
        x0Var.g();
        x0Var.b0("timestamp").d0(f0Var, this.o);
        if (this.p != null) {
            x0Var.b0("message").V(this.p);
        }
        if (this.q != null) {
            x0Var.b0("type").V(this.q);
        }
        x0Var.b0("data").d0(f0Var, this.r);
        if (this.s != null) {
            x0Var.b0("category").V(this.s);
        }
        if (this.t != null) {
            x0Var.b0("level").d0(f0Var, this.t);
        }
        Map<String, Object> map = this.u;
        if (map != null) {
            for (String str : map.keySet()) {
                Object obj = this.u.get(str);
                x0Var.b0(str);
                x0Var.d0(f0Var, obj);
            }
        }
        x0Var.m();
    }

    public c(c cVar) {
        this.r = new ConcurrentHashMap();
        this.o = cVar.o;
        this.p = cVar.p;
        this.q = cVar.q;
        this.s = cVar.s;
        Map<String, Object> mapB = rk.a.b(cVar.r);
        if (mapB != null) {
            this.r = mapB;
        }
        this.u = rk.a.b(cVar.u);
        this.t = cVar.t;
    }

    public c() {
        this(g.b());
    }
}
