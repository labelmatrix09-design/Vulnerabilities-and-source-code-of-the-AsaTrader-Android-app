package hk;

/* JADX INFO: compiled from: NoOpLogger.java */
/* JADX INFO: loaded from: /home/kali/Desktop/bunt/agah/dex_files/classes2.dex */
public final class e1 implements f0 {
    public static final e1 a = new e1();

    public static e1 e() {
        return a;
    }

    @Override // hk.f0
    public void a(i3 i3Var, String str, Object... objArr) {
    }

    @Override // hk.f0
    public void b(i3 i3Var, String str, Throwable th2) {
    }

    @Override // hk.f0
    public boolean c(i3 i3Var) {
        return false;
    }

    @Override // hk.f0
    public void d(i3 i3Var, Throwable th2, String str, Object... objArr) {
    }
}
