package hk;

import java.io.InputStream;
import java.io.OutputStream;
import java.io.Reader;
import java.io.Writer;
import java.util.Map;

/* JADX INFO: compiled from: ISerializer.java */
/* JADX INFO: loaded from: /home/kali/Desktop/bunt/agah/dex_files/classes2.dex */
public interface j0 {
    <T> void a(T t, Writer writer);

    void b(l2 l2Var, OutputStream outputStream);

    <T> T c(Reader reader, Class<T> cls);

    l2 d(InputStream inputStream);

    String e(Map<String, Object> map);
}
