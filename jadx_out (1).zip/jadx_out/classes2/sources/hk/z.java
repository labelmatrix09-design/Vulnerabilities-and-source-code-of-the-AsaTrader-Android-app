package hk;

import java.io.Closeable;
import java.util.Collections;
import java.util.Date;
import java.util.Map;
import java.util.WeakHashMap;
import org.jetbrains.annotations.ApiStatus;

/* JADX INFO: compiled from: Hub.java */
/* JADX INFO: loaded from: /home/kali/Desktop/bunt/agah/dex_files/classes2.dex */
public final class z implements e0 {
    public volatile pk.m a;
    public final j3 b;
    public volatile boolean c;
    public final b4 d;
    public final g4 e;
    public final Map<Throwable, rk.k<k0, String>> f;

    public z(j3 j3Var) {
        this(j3Var, w(j3Var));
    }

    public static b4.a w(j3 j3Var) {
        z(j3Var);
        return new b4.a(j3Var, new j2(j3Var), new w1(j3Var));
    }

    public static void z(j3 j3Var) {
        rk.j.a(j3Var, "SentryOptions is required.");
        if (j3Var.getDsn() == null || j3Var.getDsn().isEmpty()) {
            throw new IllegalArgumentException("Hub requires a DSN to be instantiated. Considering using the NoOpHub if no DSN is available.");
        }
    }

    public final void b(e3 e3Var) {
        rk.k<k0, String> kVar;
        if (!this.b.isTracingEnabled() || e3Var.M() == null || (kVar = this.f.get(rk.b.a(e3Var.M()))) == null) {
            return;
        }
        k0 k0VarA = kVar.a();
        if (e3Var.B().f() == null && k0VarA != null) {
            e3Var.B().n(k0VarA.h());
        }
        String strB = kVar.b();
        if (e3Var.r0() != null || strB == null) {
            return;
        }
        e3Var.z0(strB);
    }

    @Override // hk.e0
    public void c(long j) {
        if (!isEnabled()) {
            this.b.getLogger().a(i3.WARNING, "Instance is disabled and this 'flush' call is a no-op.", new Object[0]);
            return;
        }
        try {
            this.d.a().a().c(j);
        } catch (Throwable th2) {
            this.b.getLogger().b(i3.ERROR, "Error in the 'client.flush'.", th2);
        }
    }

    @Override // hk.e0
    public void close() {
        if (!isEnabled()) {
            this.b.getLogger().a(i3.WARNING, "Instance is disabled and this 'close' call is a no-op.", new Object[0]);
            return;
        }
        try {
            for (o0 o0Var : this.b.getIntegrations()) {
                if (o0Var instanceof Closeable) {
                    ((Closeable) o0Var).close();
                }
            }
            this.b.getExecutorService().a(this.b.getShutdownTimeoutMillis());
            this.d.a().a().close();
        } catch (Throwable th2) {
            this.b.getLogger().b(i3.ERROR, "Error while closing the Hub.", th2);
        }
        this.c = false;
    }

    @Override // hk.e0
    @ApiStatus.Internal
    public pk.m d(l2 l2Var, u uVar) {
        rk.j.a(l2Var, "SentryEnvelope is required.");
        pk.m mVar = pk.m.p;
        if (!isEnabled()) {
            this.b.getLogger().a(i3.WARNING, "Instance is disabled and this 'captureEnvelope' call is a no-op.", new Object[0]);
            return mVar;
        }
        try {
            pk.m mVarD = this.d.a().a().d(l2Var, uVar);
            return mVarD != null ? mVarD : mVar;
        } catch (Throwable th2) {
            this.b.getLogger().b(i3.ERROR, "Error while capturing envelope.", th2);
            return mVar;
        }
    }

    @Override // hk.e0
    public /* synthetic */ void e(c cVar) {
        d0.a(this, cVar);
    }

    @Override // hk.e0
    public void f(x1 x1Var) {
        if (!isEnabled()) {
            this.b.getLogger().a(i3.WARNING, "Instance is disabled and this 'configureScope' call is a no-op.", new Object[0]);
            return;
        }
        try {
            x1Var.a(this.d.a().c());
        } catch (Throwable th2) {
            this.b.getLogger().b(i3.ERROR, "Error in the 'configureScope' callback.", th2);
        }
    }

    @Override // hk.e0
    public /* synthetic */ pk.m g(pk.t tVar, f4 f4Var, u uVar) {
        return d0.c(this, tVar, f4Var, uVar);
    }

    @Override // hk.e0
    public j3 h() {
        return this.d.a().b();
    }

    @Override // hk.e0
    public pk.m i(e3 e3Var, u uVar) {
        return u(e3Var, uVar, null);
    }

    @Override // hk.e0
    public boolean isEnabled() {
        return this.c;
    }

    @Override // hk.e0
    public /* synthetic */ l0 j(String str, String str2, Date date, boolean z, i4 i4Var) {
        return d0.d(this, str, str2, date, z, i4Var);
    }

    @Override // hk.e0
    public /* synthetic */ pk.m k(Throwable th2) {
        return d0.b(this, th2);
    }

    @Override // hk.e0
    public void l(c cVar, u uVar) {
        if (!isEnabled()) {
            this.b.getLogger().a(i3.WARNING, "Instance is disabled and this 'addBreadcrumb' call is a no-op.", new Object[0]);
        } else if (cVar == null) {
            this.b.getLogger().a(i3.WARNING, "addBreadcrumb called with null parameter.", new Object[0]);
        } else {
            this.d.a().c().a(cVar, uVar);
        }
    }

    @Override // hk.e0
    @ApiStatus.Internal
    public l0 m(h4 h4Var, e eVar, boolean z, Date date, boolean z4, Long l, boolean z5, i4 i4Var) {
        return x(h4Var, eVar, z, date, z4, l, z5, i4Var);
    }

    @Override // hk.e0
    public /* synthetic */ l0 n(String str, String str2, boolean z, Long l, boolean z4) {
        return d0.e(this, str, str2, z, l, z4);
    }

    @Override // hk.e0
    public pk.m o(Throwable th2, u uVar) {
        return v(th2, uVar, null);
    }

    @Override // hk.e0
    public void p() {
        if (!isEnabled()) {
            this.b.getLogger().a(i3.WARNING, "Instance is disabled and this 'endSession' call is a no-op.", new Object[0]);
            return;
        }
        b4.a aVarA = this.d.a();
        t3 t3VarD = aVarA.c().d();
        if (t3VarD != null) {
            aVarA.a().e(t3VarD, rk.h.e(new ok.h()));
        }
    }

    @Override // hk.e0
    public void q() {
        if (!isEnabled()) {
            this.b.getLogger().a(i3.WARNING, "Instance is disabled and this 'startSession' call is a no-op.", new Object[0]);
            return;
        }
        b4.a aVarA = this.d.a();
        w1.c cVarT = aVarA.c().t();
        if (cVarT == null) {
            this.b.getLogger().a(i3.WARNING, "Session could not be started.", new Object[0]);
            return;
        }
        if (cVarT.b() != null) {
            aVarA.a().e(cVarT.b(), rk.h.e(new ok.h()));
        }
        aVarA.a().e(cVarT.a(), rk.h.e(new ok.j()));
    }

    @Override // hk.e0
    @ApiStatus.Internal
    public pk.m r(pk.t tVar, f4 f4Var, u uVar, s1 s1Var) {
        rk.j.a(tVar, "transaction is required");
        pk.m mVar = pk.m.p;
        if (!isEnabled()) {
            this.b.getLogger().a(i3.WARNING, "Instance is disabled and this 'captureTransaction' call is a no-op.", new Object[0]);
            return mVar;
        }
        if (!tVar.k0()) {
            this.b.getLogger().a(i3.WARNING, "Transaction: %s is not finished and this 'captureTransaction' call is a no-op.", tVar.E());
            return mVar;
        }
        if (!Boolean.TRUE.equals(Boolean.valueOf(tVar.l0()))) {
            this.b.getLogger().a(i3.DEBUG, "Transaction %s was dropped due to sampling decision.", tVar.E());
            this.b.getClientReportRecorder().a(mk.e.SAMPLE_RATE, f.Transaction);
            return mVar;
        }
        try {
            b4.a aVarA = this.d.a();
            return aVarA.a().b(tVar, f4Var, aVarA.c(), uVar, s1Var);
        } catch (Throwable th2) {
            this.b.getLogger().b(i3.ERROR, "Error while capturing transaction with id: " + tVar.E(), th2);
            return mVar;
        }
    }

    @Override // hk.e0
    @ApiStatus.Internal
    public void s(Throwable th2, k0 k0Var, String str) {
        rk.j.a(th2, "throwable is required");
        rk.j.a(k0Var, "span is required");
        rk.j.a(str, "transactionName is required");
        Throwable thA = rk.b.a(th2);
        if (this.f.containsKey(thA)) {
            return;
        }
        this.f.put(thA, new rk.k<>(k0Var, str));
    }

    public final w1 t(w1 w1Var, x1 x1Var) {
        if (x1Var == null) {
            return w1Var;
        }
        w1 w1Var2 = new w1(w1Var);
        x1Var.a(w1Var2);
        return w1Var2;
    }

    public final pk.m u(e3 e3Var, u uVar, x1 x1Var) {
        pk.m mVarA = pk.m.p;
        if (!isEnabled()) {
            this.b.getLogger().a(i3.WARNING, "Instance is disabled and this 'captureEvent' call is a no-op.", new Object[0]);
            return mVarA;
        }
        if (e3Var == null) {
            this.b.getLogger().a(i3.WARNING, "captureEvent called with null parameter.", new Object[0]);
            return mVarA;
        }
        try {
            b(e3Var);
            b4.a aVarA = this.d.a();
            mVarA = aVarA.a().a(e3Var, t(aVarA.c(), x1Var), uVar);
            this.a = mVarA;
            return mVarA;
        } catch (Throwable th2) {
            this.b.getLogger().b(i3.ERROR, "Error while capturing event with id: " + e3Var.E(), th2);
            return mVarA;
        }
    }

    public final pk.m v(Throwable th2, u uVar, x1 x1Var) {
        pk.m mVarA = pk.m.p;
        if (!isEnabled()) {
            this.b.getLogger().a(i3.WARNING, "Instance is disabled and this 'captureException' call is a no-op.", new Object[0]);
        } else if (th2 == null) {
            this.b.getLogger().a(i3.WARNING, "captureException called with null parameter.", new Object[0]);
        } else {
            try {
                b4.a aVarA = this.d.a();
                e3 e3Var = new e3(th2);
                b(e3Var);
                mVarA = aVarA.a().a(e3Var, t(aVarA.c(), x1Var), uVar);
            } catch (Throwable th3) {
                this.b.getLogger().b(i3.ERROR, "Error while capturing exception: " + th2.getMessage(), th3);
            }
        }
        this.a = mVarA;
        return mVarA;
    }

    public final l0 x(h4 h4Var, e eVar, boolean z, Date date, boolean z4, Long l, boolean z5, i4 i4Var) {
        final l0 l0VarK;
        rk.j.a(h4Var, "transactionContext is required");
        if (!isEnabled()) {
            this.b.getLogger().a(i3.WARNING, "Instance is disabled and this 'startTransaction' returns a no-op.", new Object[0]);
            l0VarK = k1.k();
        } else if (this.b.isTracingEnabled()) {
            boolean zA = this.e.a(new v1(h4Var, eVar));
            h4Var.j(Boolean.valueOf(zA));
            r3 r3Var = new r3(h4Var, this, date, z4, l, z5, i4Var);
            if (zA && this.b.isProfilingEnabled()) {
                this.b.getTransactionProfiler().b(r3Var);
            }
            l0VarK = r3Var;
        } else {
            this.b.getLogger().a(i3.INFO, "Tracing is disabled and this 'startTransaction' returns a no-op.", new Object[0]);
            l0VarK = k1.k();
        }
        if (z) {
            f(new x1() { // from class: hk.y
                @Override // hk.x1
                public final void a(w1 w1Var) {
                    w1Var.s(l0VarK);
                }
            });
        }
        return l0VarK;
    }

    public z(j3 j3Var, b4 b4Var) {
        this.f = Collections.synchronizedMap(new WeakHashMap());
        z(j3Var);
        this.b = j3Var;
        this.e = new g4(j3Var);
        this.d = b4Var;
        this.a = pk.m.p;
        this.c = true;
    }

    @Override // hk.e0
    /* JADX INFO: renamed from: clone, reason: merged with bridge method [inline-methods] */
    public e0 m2clone() {
        if (!isEnabled()) {
            this.b.getLogger().a(i3.WARNING, "Disabled Hub cloned.", new Object[0]);
        }
        return new z(this.b, new b4(this.d));
    }

    public z(j3 j3Var, b4.a aVar) {
        this(j3Var, new b4(j3Var.getLogger(), aVar));
    }
}
