package hk;

import java.io.Serializable;
import java.util.Collection;
import java.util.Iterator;

/* JADX INFO: compiled from: SynchronizedCollection.java */
/* JADX INFO: loaded from: /home/kali/Desktop/bunt/agah/dex_files/classes2.dex */
public class c4<E> implements Collection<E>, Serializable {
    public final Collection<E> o;
    public final Object p;

    public c4(Collection<E> collection) {
        if (collection == null) {
            throw new NullPointerException("Collection must not be null.");
        }
        this.o = collection;
        this.p = this;
    }

    @Override // java.util.Collection
    public boolean add(E e) {
        boolean zAdd;
        synchronized (this.p) {
            zAdd = c().add(e);
        }
        return zAdd;
    }

    @Override // java.util.Collection
    public boolean addAll(Collection<? extends E> collection) {
        boolean zAddAll;
        synchronized (this.p) {
            zAddAll = c().addAll(collection);
        }
        return zAddAll;
    }

    public Collection<E> c() {
        return this.o;
    }

    @Override // java.util.Collection
    public void clear() {
        synchronized (this.p) {
            c().clear();
        }
    }

    @Override // java.util.Collection
    public boolean contains(Object obj) {
        boolean zContains;
        synchronized (this.p) {
            zContains = c().contains(obj);
        }
        return zContains;
    }

    @Override // java.util.Collection
    public boolean containsAll(Collection<?> collection) {
        boolean zContainsAll;
        synchronized (this.p) {
            zContainsAll = c().containsAll(collection);
        }
        return zContainsAll;
    }

    @Override // java.util.Collection
    public boolean isEmpty() {
        boolean zIsEmpty;
        synchronized (this.p) {
            zIsEmpty = c().isEmpty();
        }
        return zIsEmpty;
    }

    @Override // java.util.Collection, java.lang.Iterable
    public Iterator<E> iterator() {
        return c().iterator();
    }

    @Override // java.util.Collection
    public boolean remove(Object obj) {
        boolean zRemove;
        synchronized (this.p) {
            zRemove = c().remove(obj);
        }
        return zRemove;
    }

    @Override // java.util.Collection
    public boolean removeAll(Collection<?> collection) {
        boolean zRemoveAll;
        synchronized (this.p) {
            zRemoveAll = c().removeAll(collection);
        }
        return zRemoveAll;
    }

    @Override // java.util.Collection
    public boolean retainAll(Collection<?> collection) {
        boolean zRetainAll;
        synchronized (this.p) {
            zRetainAll = c().retainAll(collection);
        }
        return zRetainAll;
    }

    @Override // java.util.Collection
    public int size() {
        int size;
        synchronized (this.p) {
            size = c().size();
        }
        return size;
    }

    @Override // java.util.Collection
    public Object[] toArray() {
        Object[] array;
        synchronized (this.p) {
            array = c().toArray();
        }
        return array;
    }

    public String toString() {
        String string;
        synchronized (this.p) {
            string = c().toString();
        }
        return string;
    }

    @Override // java.util.Collection
    public <T> T[] toArray(T[] tArr) {
        T[] tArr2;
        synchronized (this.p) {
            tArr2 = (T[]) c().toArray(tArr);
        }
        return tArr2;
    }
}
