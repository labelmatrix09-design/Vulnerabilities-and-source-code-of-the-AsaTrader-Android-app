package hk;

import java.util.Date;
import org.jetbrains.annotations.ApiStatus;

/* JADX INFO: compiled from: ISpan.java */
/* JADX INFO: loaded from: /home/kali/Desktop/bunt/agah/dex_files/classes2.dex */
public interface k0 {
    @ApiStatus.Experimental
    f4 a();

    boolean b();

    void c();

    void d(a4 a4Var);

    x3 h();

    @ApiStatus.Internal
    k0 i(String str, String str2, Date date);

    a4 j();
}
