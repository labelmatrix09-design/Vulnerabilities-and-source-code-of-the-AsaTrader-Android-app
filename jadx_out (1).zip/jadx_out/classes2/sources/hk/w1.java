package hk;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Queue;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CopyOnWriteArrayList;
import org.jetbrains.annotations.ApiStatus;

/* JADX INFO: compiled from: Scope.java */
/* JADX INFO: loaded from: /home/kali/Desktop/bunt/agah/dex_files/classes2.dex */
public final class w1 {
    public i3 a;
    public l0 b;
    public String c;
    public pk.u d;
    public pk.j e;
    public List<String> f;
    public Queue<hk.c> g;
    public Map<String, String> h;
    public Map<String, Object> i;
    public List<s> j;
    public final j3 k;
    public volatile t3 l;
    public final Object m;
    public final Object n;
    public pk.c o;
    public List<hk.b> p;

    /* JADX INFO: compiled from: Scope.java */
    public interface a {
        void a(t3 t3Var);
    }

    /* JADX INFO: compiled from: Scope.java */
    @ApiStatus.Internal
    public interface b {
        void a(l0 l0Var);
    }

    /* JADX INFO: compiled from: Scope.java */
    public static final class c {
        public final t3 a;
        public final t3 b;

        public c(t3 t3Var, t3 t3Var2) {
            this.b = t3Var;
            this.a = t3Var2;
        }

        public t3 a() {
            return this.b;
        }

        public t3 b() {
            return this.a;
        }
    }

    public w1(j3 j3Var) {
        this.f = new ArrayList();
        this.h = new ConcurrentHashMap();
        this.i = new ConcurrentHashMap();
        this.j = new CopyOnWriteArrayList();
        this.m = new Object();
        this.n = new Object();
        this.o = new pk.c();
        this.p = new CopyOnWriteArrayList();
        j3 j3Var2 = (j3) rk.j.a(j3Var, "SentryOptions is required.");
        this.k = j3Var2;
        this.g = c(j3Var2.getMaxBreadcrumbs());
    }

    public void a(hk.c cVar, u uVar) {
        if (cVar == null) {
            return;
        }
        if (uVar == null) {
            uVar = new u();
        }
        j3$a beforeBreadcrumb = this.k.getBeforeBreadcrumb();
        if (beforeBreadcrumb != null) {
            cVar = e(beforeBreadcrumb, cVar, uVar);
        }
        if (cVar == null) {
            this.k.getLogger().a(i3.INFO, "Breadcrumb was dropped by beforeBreadcrumb", new Object[0]);
            return;
        }
        this.g.add(cVar);
        if (this.k.isEnableScopeSync()) {
            Iterator it = this.k.getScopeObservers().iterator();
            while (it.hasNext()) {
                ((g0) it.next()).e(cVar);
            }
        }
    }

    public void b() {
        synchronized (this.n) {
            this.b = null;
        }
        this.c = null;
    }

    public final Queue<hk.c> c(int i) {
        return d4.e(new d(i));
    }

    public t3 d() {
        t3 t3Var;
        synchronized (this.m) {
            t3Var = null;
            if (this.l != null) {
                this.l.c();
                t3 t3VarClone = this.l.clone();
                this.l = null;
                t3Var = t3VarClone;
            }
        }
        return t3Var;
    }

    public final hk.c e(j3$a j3_a, hk.c cVar, u uVar) {
        try {
            return j3_a.a(cVar, uVar);
        } catch (Throwable th2) {
            this.k.getLogger().b(i3.ERROR, "The BeforeBreadcrumbCallback callback threw an exception. Exception details will be added to the breadcrumb.", th2);
            if (th2.getMessage() == null) {
                return cVar;
            }
            cVar.m("sentry:message", th2.getMessage());
            return cVar;
        }
    }

    public List<hk.b> f() {
        return new CopyOnWriteArrayList(this.p);
    }

    public Queue<hk.c> g() {
        return this.g;
    }

    public pk.c h() {
        return this.o;
    }

    public List<s> i() {
        return this.j;
    }

    public Map<String, Object> j() {
        return this.i;
    }

    public List<String> k() {
        return this.f;
    }

    public i3 l() {
        return this.a;
    }

    public pk.j m() {
        return this.e;
    }

    public k0 n() {
        w3 w3VarE;
        l0 l0Var = this.b;
        return (l0Var == null || (w3VarE = l0Var.e()) == null) ? l0Var : w3VarE;
    }

    @ApiStatus.Internal
    public Map<String, String> o() {
        return rk.a.b(this.h);
    }

    public l0 p() {
        return this.b;
    }

    public String q() {
        l0 l0Var = this.b;
        return l0Var != null ? l0Var.getName() : this.c;
    }

    public pk.u r() {
        return this.d;
    }

    public void s(l0 l0Var) {
        synchronized (this.n) {
            this.b = l0Var;
        }
    }

    public c t() {
        c cVar;
        synchronized (this.m) {
            if (this.l != null) {
                this.l.c();
            }
            t3 t3Var = this.l;
            cVar = null;
            if (this.k.getRelease() != null) {
                this.l = new t3(this.k.getDistinctId(), this.d, this.k.getEnvironment(), this.k.getRelease());
                cVar = new c(this.l.clone(), t3Var != null ? t3Var.clone() : null);
            } else {
                this.k.getLogger().a(i3.WARNING, "Release is not set on SentryOptions. Session could not be started", new Object[0]);
            }
        }
        return cVar;
    }

    public t3 u(a aVar) {
        t3 t3VarClone;
        synchronized (this.m) {
            aVar.a(this.l);
            t3VarClone = this.l != null ? this.l.clone() : null;
        }
        return t3VarClone;
    }

    @ApiStatus.Internal
    public void v(b bVar) {
        synchronized (this.n) {
            bVar.a(this.b);
        }
    }

    public w1(w1 w1Var) {
        this.f = new ArrayList();
        this.h = new ConcurrentHashMap();
        this.i = new ConcurrentHashMap();
        this.j = new CopyOnWriteArrayList();
        this.m = new Object();
        this.n = new Object();
        this.o = new pk.c();
        this.p = new CopyOnWriteArrayList();
        this.b = w1Var.b;
        this.c = w1Var.c;
        this.l = w1Var.l;
        this.k = w1Var.k;
        this.a = w1Var.a;
        pk.u uVar = w1Var.d;
        this.d = uVar != null ? new pk.u(uVar) : null;
        pk.j jVar = w1Var.e;
        this.e = jVar != null ? new pk.j(jVar) : null;
        this.f = new ArrayList(w1Var.f);
        this.j = new CopyOnWriteArrayList(w1Var.j);
        Queue<hk.c> queue = w1Var.g;
        Queue<hk.c> queueC = c(w1Var.k.getMaxBreadcrumbs());
        Iterator<hk.c> it = queue.iterator();
        while (it.hasNext()) {
            queueC.add(new hk.c(it.next()));
        }
        this.g = queueC;
        Map<String, String> map = w1Var.h;
        ConcurrentHashMap concurrentHashMap = new ConcurrentHashMap();
        for (Map.Entry<String, String> entry : map.entrySet()) {
            if (entry != null) {
                concurrentHashMap.put(entry.getKey(), entry.getValue());
            }
        }
        this.h = concurrentHashMap;
        Map<String, Object> map2 = w1Var.i;
        ConcurrentHashMap concurrentHashMap2 = new ConcurrentHashMap();
        for (Map.Entry<String, Object> entry2 : map2.entrySet()) {
            if (entry2 != null) {
                concurrentHashMap2.put(entry2.getKey(), entry2.getValue());
            }
        }
        this.i = concurrentHashMap2;
        this.o = new pk.c(w1Var.o);
        this.p = new CopyOnWriteArrayList(w1Var.p);
    }
}
