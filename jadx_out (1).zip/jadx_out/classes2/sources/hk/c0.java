package hk;

/* JADX INFO: compiled from: IEnvelopeSender.java */
/* JADX INFO: loaded from: /home/kali/Desktop/bunt/agah/dex_files/classes2.dex */
public interface c0 {
    void a(String str, u uVar);
}
