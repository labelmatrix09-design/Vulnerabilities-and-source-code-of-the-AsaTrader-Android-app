package hk;

import org.jetbrains.annotations.ApiStatus;

/* JADX INFO: compiled from: AsyncHttpTransportFactory.java */
/* JADX INFO: loaded from: /home/kali/Desktop/bunt/agah/dex_files/classes2.dex */
@ApiStatus.Internal
public final class a implements n0 {
    @Override // hk.n0
    public qk.p a(j3 j3Var, t1 t1Var) {
        rk.j.a(j3Var, "options is required");
        rk.j.a(t1Var, "requestDetails is required");
        return new qk.d(j3Var, new qk.y(j3Var), j3Var.getTransportGate(), t1Var);
    }
}
