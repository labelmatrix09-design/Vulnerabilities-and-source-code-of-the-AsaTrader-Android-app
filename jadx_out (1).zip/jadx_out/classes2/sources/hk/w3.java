package hk;

import java.util.Date;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicBoolean;
import org.jetbrains.annotations.ApiStatus;
import org.jetbrains.annotations.VisibleForTesting;

/* JADX INFO: compiled from: Span.java */
/* JADX INFO: loaded from: /home/kali/Desktop/bunt/agah/dex_files/classes2.dex */
@ApiStatus.Internal
public final class w3 implements k0 {
    public final Date a;
    public final Long b;
    public Long c;
    public Double d;
    public final x3 e;
    public final r3 f;
    public Throwable g;
    public final e0 h;
    public final AtomicBoolean i;
    public y3 j;
    public final Map<String, Object> k;

    public w3(pk.m mVar, z3 z3Var, r3 r3Var, String str, e0 e0Var, Date date, y3 y3Var) {
        this.i = new AtomicBoolean(false);
        this.k = new ConcurrentHashMap();
        this.e = new x3(mVar, new z3(), str, z3Var, r3Var.x());
        this.f = (r3) rk.j.a(r3Var, "transaction is required");
        this.h = (e0) rk.j.a(e0Var, "hub is required");
        this.j = y3Var;
        if (date != null) {
            this.a = date;
            this.b = null;
        } else {
            this.a = g.b();
            this.b = Long.valueOf(System.nanoTime());
        }
    }

    public void A(y3 y3Var) {
        this.j = y3Var;
    }

    @Override // hk.k0
    public boolean b() {
        return this.i.get();
    }

    @Override // hk.k0
    public void c() {
        d(this.e.f());
    }

    @Override // hk.k0
    public void d(a4 a4Var) {
        k(a4Var, Double.valueOf(g.a(g.b())), null);
    }

    @Override // hk.k0
    public x3 h() {
        return this.e;
    }

    @Override // hk.k0
    public k0 i(String str, String str2, Date date) {
        return this.i.get() ? j1.k() : this.f.C(this.e.e(), str, str2, date);
    }

    @Override // hk.k0
    public a4 j() {
        return this.e.f();
    }

    public void k(a4 a4Var, Double d, Long l) {
        if (this.i.compareAndSet(false, true)) {
            this.e.k(a4Var);
            this.d = d;
            Throwable th2 = this.g;
            if (th2 != null) {
                this.h.s(th2, this, this.f.getName());
            }
            y3 y3Var = this.j;
            if (y3Var != null) {
                y3Var.a(this);
            }
            this.c = Long.valueOf(l == null ? System.nanoTime() : l.longValue());
        }
    }

    public Map<String, Object> l() {
        return this.k;
    }

    public String m() {
        return this.e.a();
    }

    public final Double n(Long l) {
        if (this.b == null || l == null) {
            return null;
        }
        return Double.valueOf(g.h(l.longValue() - this.b.longValue()));
    }

    public Long o() {
        return this.c;
    }

    public Double p() {
        return q(this.c);
    }

    public Double q(Long l) {
        Double dN = n(l);
        if (dN != null) {
            double time = this.a.getTime();
            double dDoubleValue = dN.doubleValue();
            Double.isNaN(time);
            return Double.valueOf(g.g(time + dDoubleValue));
        }
        Double d = this.d;
        if (d != null) {
            return d;
        }
        return null;
    }

    public String r() {
        return this.e.b();
    }

    public z3 s() {
        return this.e.c();
    }

    public z3 t() {
        return this.e.e();
    }

    public Date u() {
        return this.a;
    }

    public Map<String, String> v() {
        return this.e.g();
    }

    public Double w() {
        return this.d;
    }

    public pk.m x() {
        return this.e.h();
    }

    public Boolean y() {
        return this.e.d();
    }

    public void z(String str) {
        if (this.i.get()) {
            return;
        }
        this.e.i(str);
    }

    @VisibleForTesting
    public w3(h4 h4Var, r3 r3Var, e0 e0Var, Date date) {
        this.i = new AtomicBoolean(false);
        this.k = new ConcurrentHashMap();
        this.e = (x3) rk.j.a(h4Var, "context is required");
        this.f = (r3) rk.j.a(r3Var, "sentryTracer is required");
        this.h = (e0) rk.j.a(e0Var, "hub is required");
        this.j = null;
        if (date != null) {
            this.a = date;
            this.b = null;
        } else {
            this.a = g.b();
            this.b = Long.valueOf(System.nanoTime());
        }
    }
}
