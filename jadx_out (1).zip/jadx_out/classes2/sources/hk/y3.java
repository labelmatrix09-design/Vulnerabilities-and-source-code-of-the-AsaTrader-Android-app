package hk;

/* JADX INFO: compiled from: SpanFinishedCallback.java */
/* JADX INFO: loaded from: /home/kali/Desktop/bunt/agah/dex_files/classes2.dex */
public interface y3 {
    void a(w3 w3Var);
}
