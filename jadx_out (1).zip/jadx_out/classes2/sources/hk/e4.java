package hk;

import java.io.PrintWriter;
import java.io.StringWriter;

/* JADX INFO: compiled from: SystemOutLogger.java */
/* JADX INFO: loaded from: /home/kali/Desktop/bunt/agah/dex_files/classes2.dex */
public final class e4 implements f0 {
    @Override // hk.f0
    public void a(i3 i3Var, String str, Object... objArr) {
        System.out.println(String.format("%s: %s", i3Var, String.format(str, objArr)));
    }

    @Override // hk.f0
    public void b(i3 i3Var, String str, Throwable th2) {
        if (th2 == null) {
            a(i3Var, str, new Object[0]);
        } else {
            System.out.println(String.format("%s: %s\n%s", i3Var, String.format(str, th2.toString()), e(th2)));
        }
    }

    @Override // hk.f0
    public boolean c(i3 i3Var) {
        return true;
    }

    @Override // hk.f0
    public void d(i3 i3Var, Throwable th2, String str, Object... objArr) {
        if (th2 == null) {
            a(i3Var, str, objArr);
        } else {
            System.out.println(String.format("%s: %s \n %s\n%s", i3Var, String.format(str, objArr), th2.toString(), e(th2)));
        }
    }

    public final String e(Throwable th2) {
        StringWriter stringWriter = new StringWriter();
        th2.printStackTrace(new PrintWriter(stringWriter));
        return stringWriter.toString();
    }
}
