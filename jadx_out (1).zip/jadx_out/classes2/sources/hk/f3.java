package hk;

import io.github.inflationx.calligraphy3.BuildConfig;
import io.sentry.exception.ExceptionMechanismException;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Deque;
import java.util.HashSet;
import java.util.List;

/* JADX INFO: compiled from: SentryExceptionFactory.java */
/* JADX INFO: loaded from: /home/kali/Desktop/bunt/agah/dex_files/classes2.dex */
public final class f3 {
    public final l3 a;

    public f3(l3 l3Var) {
        this.a = (l3) rk.j.a(l3Var, "The SentryStackTraceFactory is required.");
    }

    public Deque<pk.l> a(Throwable th2) {
        Thread threadCurrentThread;
        pk.g gVarA;
        boolean zD;
        ArrayDeque arrayDeque = new ArrayDeque();
        HashSet hashSet = new HashSet();
        while (th2 != null && hashSet.add(th2)) {
            if (th2 instanceof ExceptionMechanismException) {
                ExceptionMechanismException exceptionMechanismException = (ExceptionMechanismException) th2;
                gVarA = exceptionMechanismException.a();
                Throwable thC = exceptionMechanismException.c();
                threadCurrentThread = exceptionMechanismException.b();
                zD = exceptionMechanismException.d();
                th2 = thC;
            } else {
                threadCurrentThread = Thread.currentThread();
                gVarA = null;
                zD = false;
            }
            arrayDeque.addFirst(b(th2, gVarA, threadCurrentThread, zD));
            th2 = th2.getCause();
        }
        return arrayDeque;
    }

    public final pk.l b(Throwable th2, pk.g gVar, Thread thread, boolean z) {
        Package r0 = th2.getClass().getPackage();
        String name = th2.getClass().getName();
        pk.l lVar = new pk.l();
        String message = th2.getMessage();
        if (r0 != null) {
            name = name.replace(r0.getName() + ".", BuildConfig.FLAVOR);
        }
        String name2 = r0 != null ? r0.getName() : null;
        List<pk.q> listA = this.a.a(th2.getStackTrace());
        if (listA != null && !listA.isEmpty()) {
            pk.r rVar = new pk.r(listA);
            if (z) {
                rVar.d(Boolean.TRUE);
            }
            lVar.l(rVar);
        }
        if (thread != null) {
            lVar.m(Long.valueOf(thread.getId()));
        }
        lVar.n(name);
        lVar.j(gVar);
        lVar.k(name2);
        lVar.p(message);
        return lVar;
    }

    public List<pk.l> c(Throwable th2) {
        return d(a(th2));
    }

    public final List<pk.l> d(Deque<pk.l> deque) {
        return new ArrayList(deque);
    }
}
