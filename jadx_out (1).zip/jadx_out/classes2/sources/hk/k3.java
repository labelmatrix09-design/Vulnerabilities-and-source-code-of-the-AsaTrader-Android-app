package hk;

/* JADX INFO: compiled from: SentryRuntimeEventProcessor.java */
/* JADX INFO: loaded from: /home/kali/Desktop/bunt/agah/dex_files/classes2.dex */
public final class k3 implements s {
    public final String o;
    public final String p;

    public k3(String str, String str2) {
        this.o = str;
        this.p = str2;
    }

    @Override // hk.s
    public e3 a(e3 e3Var, u uVar) {
        return c(e3Var);
    }

    @Override // hk.s
    public pk.t b(pk.t tVar, u uVar) {
        return (pk.t) c(tVar);
    }

    public final <T extends g2> T c(T t) {
        if (t.B().e() == null) {
            t.B().m(new pk.o());
        }
        pk.o oVarE = t.B().e();
        if (oVarE != null && oVarE.d() == null && oVarE.e() == null) {
            oVarE.f(this.p);
            oVarE.h(this.o);
        }
        return t;
    }

    public k3() {
        this(System.getProperty("java.version"), System.getProperty("java.vendor"));
    }
}
