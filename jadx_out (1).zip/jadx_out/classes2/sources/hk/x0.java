package hk;

import java.io.Writer;

/* JADX INFO: compiled from: JsonObjectWriter.java */
/* JADX INFO: loaded from: /home/kali/Desktop/bunt/agah/dex_files/classes2.dex */
public final class x0 extends uk.c {
    public final w0 z;

    public x0(Writer writer, int i) {
        super(writer);
        this.z = new w0(i);
    }

    public x0 b0(String str) {
        super.o(str);
        return this;
    }

    public x0 d0(f0 f0Var, Object obj) {
        this.z.a(this, f0Var, obj);
        return this;
    }
}
