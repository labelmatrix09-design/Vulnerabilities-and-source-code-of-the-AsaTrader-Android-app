package hk;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.WeakHashMap;

/* JADX INFO: compiled from: DuplicateEventDetectionEventProcessor.java */
/* JADX INFO: loaded from: /home/kali/Desktop/bunt/agah/dex_files/classes2.dex */
public final class l implements s {
    public final Map<Throwable, Object> o = Collections.synchronizedMap(new WeakHashMap());
    public final j3 p;

    public l(j3 j3Var) {
        this.p = (j3) rk.j.a(j3Var, "options are required");
    }

    public static List<Throwable> c(Throwable th2) {
        ArrayList arrayList = new ArrayList();
        while (th2.getCause() != null) {
            arrayList.add(th2.getCause());
            th2 = th2.getCause();
        }
        return arrayList;
    }

    public static <T> boolean d(Map<T, Object> map, List<T> list) {
        Iterator<T> it = list.iterator();
        while (it.hasNext()) {
            if (map.containsKey(it.next())) {
                return true;
            }
        }
        return false;
    }

    @Override // hk.s
    public e3 a(e3 e3Var, u uVar) {
        if (this.p.isEnableDeduplication()) {
            Throwable thM = e3Var.M();
            if (thM != null) {
                if (this.o.containsKey(thM) || d(this.o, c(thM))) {
                    this.p.getLogger().a(i3.DEBUG, "Duplicate Exception detected. Event %s will be discarded.", e3Var.E());
                    return null;
                }
                this.o.put(thM, null);
            }
        } else {
            this.p.getLogger().a(i3.DEBUG, "Event deduplication is disabled.", new Object[0]);
        }
        return e3Var;
    }

    @Override // hk.s
    public /* synthetic */ pk.t b(pk.t tVar, u uVar) {
        return r.a(this, tVar, uVar);
    }
}
