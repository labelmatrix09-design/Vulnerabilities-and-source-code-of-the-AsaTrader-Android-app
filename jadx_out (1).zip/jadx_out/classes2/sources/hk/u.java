package hk;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/* JADX INFO: compiled from: Hint.java */
/* JADX INFO: loaded from: /home/kali/Desktop/bunt/agah/dex_files/classes2.dex */
public final class u {
    public static final Map<String, Class<?>> d;
    public final Map<String, Object> a = new HashMap();
    public final List<b> b = new ArrayList();
    public b c = null;

    static {
        HashMap map = new HashMap();
        d = map;
        map.put("boolean", Boolean.class);
        map.put("char", Character.class);
        map.put("byte", Byte.class);
        map.put("short", Short.class);
        map.put("int", Integer.class);
        map.put("long", Long.class);
        map.put("float", Float.class);
        map.put("double", Double.class);
    }

    public void a(List<b> list) {
        if (list != null) {
            this.b.addAll(list);
        }
    }

    public Object b(String str) {
        return this.a.get(str);
    }

    public List<b> c() {
        return new ArrayList(this.b);
    }

    public b d() {
        return this.c;
    }

    public void e(String str, Object obj) {
        this.a.put(str, obj);
    }

    public void f(b bVar) {
        this.c = bVar;
    }
}
