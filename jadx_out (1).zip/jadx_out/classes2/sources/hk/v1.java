package hk;

/* JADX INFO: compiled from: SamplingContext.java */
/* JADX INFO: loaded from: /home/kali/Desktop/bunt/agah/dex_files/classes2.dex */
public final class v1 {
    public final h4 a;

    public v1(h4 h4Var, e eVar) {
        this.a = (h4) rk.j.a(h4Var, "transactionContexts is required");
    }

    public h4 a() {
        return this.a;
    }
}
