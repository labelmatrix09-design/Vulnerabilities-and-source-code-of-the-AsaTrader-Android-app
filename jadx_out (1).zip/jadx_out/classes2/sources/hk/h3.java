package hk;

import java.io.IOException;
import java.util.Locale;
import org.jetbrains.annotations.ApiStatus;

/* JADX INFO: compiled from: SentryItemType.java */
/* JADX INFO: loaded from: /home/kali/Desktop/bunt/agah/dex_files/classes2.dex */
@ApiStatus.Internal
public enum h3 implements z0 {
    Session("session"),
    Event("event"),
    UserFeedback("user_report"),
    Attachment("attachment"),
    Transaction("transaction"),
    Profile("profile"),
    ClientReport("client_report"),
    Unknown("__unknown__");

    private final String itemType;

    /* JADX INFO: compiled from: SentryItemType.java */
    public static final class a implements p0<h3> {
        @Override // hk.p0
        /* JADX INFO: renamed from: b, reason: merged with bridge method [inline-methods] */
        public h3 a(v0 v0Var, f0 f0Var) {
            return h3.valueOfLabel(v0Var.N().toLowerCase(Locale.ROOT));
        }
    }

    h3(String str) {
        this.itemType = str;
    }

    public static h3 resolve(Object obj) {
        if (obj instanceof e3) {
            return Event;
        }
        if (obj instanceof pk.t) {
            return Transaction;
        }
        if (obj instanceof t3) {
            return Session;
        }
        return obj instanceof mk.b ? ClientReport : Attachment;
    }

    public static h3 valueOfLabel(String str) {
        for (h3 h3Var : values()) {
            if (h3Var.itemType.equals(str)) {
                return h3Var;
            }
        }
        return Unknown;
    }

    public String getItemType() {
        return this.itemType;
    }

    public void serialize(x0 x0Var, f0 f0Var) throws IOException {
        x0Var.V(this.itemType);
    }
}
