package jb;

import tb.b;

/* JADX INFO: compiled from: R8$$SyntheticClass */
/* JADX INFO: loaded from: /home/kali/Desktop/bunt/agah/dex_files/classes2.dex */
public final /* synthetic */ class e implements b.a {
    public static final /* synthetic */ e a = new e();

    public final boolean a(int i, int i3, int i5, int i6, int i7) {
        return f.d(i, i3, i5, i6, i7);
    }
}
