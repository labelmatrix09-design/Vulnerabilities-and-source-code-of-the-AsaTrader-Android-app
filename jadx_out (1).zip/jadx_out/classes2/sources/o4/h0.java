package o4;

import android.view.View;

/* JADX INFO: compiled from: R8$$SyntheticClass */
/* JADX INFO: loaded from: /home/kali/Desktop/bunt/agah/dex_files/classes2.dex */
public final /* synthetic */ class h0 implements View.OnClickListener {
    public final /* synthetic */ i0 o;

    @Override // android.view.View.OnClickListener
    public final void onClick(View view) {
        i0.E2(this.o, view);
    }
}
