package o4;

/* JADX INFO: compiled from: R8$$SyntheticClass */
/* JADX INFO: loaded from: /home/kali/Desktop/bunt/agah/dex_files/classes2.dex */
public final /* synthetic */ class o0 implements Runnable {
    public final /* synthetic */ p0 o;

    @Override // java.lang.Runnable
    public final void run() {
        p0.t2(this.o);
    }
}
