package o4;

import android.app.Activity;
import android.app.Dialog;
import android.view.View;

/* JADX INFO: compiled from: R8$$SyntheticClass */
/* JADX INFO: loaded from: /home/kali/Desktop/bunt/agah/dex_files/classes2.dex */
public final /* synthetic */ class o implements View.OnClickListener {
    public final /* synthetic */ s7.v o;
    public final /* synthetic */ Activity p;
    public final /* synthetic */ String q;
    public final /* synthetic */ Dialog r;
    public final /* synthetic */ il.l s;
    public final /* synthetic */ String t;
    public final /* synthetic */ String u;
    public final /* synthetic */ String v;
    public final /* synthetic */ boolean w;

    public /* synthetic */ o(s7.v vVar, Activity activity, String str, Dialog dialog, il.l lVar, String str2, String str3, String str4, boolean z) {
        this.o = vVar;
        this.p = activity;
        this.q = str;
        this.r = dialog;
        this.s = lVar;
        this.t = str2;
        this.u = str3;
        this.v = str4;
        this.w = z;
    }

    @Override // android.view.View.OnClickListener
    public final void onClick(View view) {
        r.a.i(this.o, this.p, this.q, this.r, this.s, this.t, this.u, this.v, this.w, view);
    }
}
