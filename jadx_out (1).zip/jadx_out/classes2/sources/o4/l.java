package o4;

import android.app.Dialog;
import android.view.View;

/* JADX INFO: compiled from: R8$$SyntheticClass */
/* JADX INFO: loaded from: /home/kali/Desktop/bunt/agah/dex_files/classes2.dex */
public final /* synthetic */ class l implements View.OnClickListener {
    public final /* synthetic */ Dialog o;
    public final /* synthetic */ il.a p;

    public /* synthetic */ l(Dialog dialog, il.a aVar) {
        this.o = dialog;
        this.p = aVar;
    }

    @Override // android.view.View.OnClickListener
    public final void onClick(View view) {
        r.a.l(this.o, this.p, view);
    }
}
