package o4;

import android.app.Activity;

/* JADX INFO: compiled from: R8$$SyntheticClass */
/* JADX INFO: loaded from: /home/kali/Desktop/bunt/agah/dex_files/classes2.dex */
public final /* synthetic */ class p implements Runnable {
    public final /* synthetic */ Activity o;
    public final /* synthetic */ il.a p;

    public /* synthetic */ p(Activity activity, il.a aVar) {
        this.o = activity;
        this.p = aVar;
    }

    @Override // java.lang.Runnable
    public final void run() {
        r.a.j(this.o, this.p);
    }
}
