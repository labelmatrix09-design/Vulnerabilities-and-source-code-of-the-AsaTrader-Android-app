package o4;

import android.app.Activity;
import android.app.Dialog;
import android.view.View;

/* JADX INFO: compiled from: R8$$SyntheticClass */
/* JADX INFO: loaded from: /home/kali/Desktop/bunt/agah/dex_files/classes2.dex */
public final /* synthetic */ class j implements View.OnClickListener {
    public final /* synthetic */ Activity o;
    public final /* synthetic */ Dialog p;

    public /* synthetic */ j(Activity activity, Dialog dialog) {
        this.o = activity;
        this.p = dialog;
    }

    @Override // android.view.View.OnClickListener
    public final void onClick(View view) {
        r.a.n(this.o, this.p, view);
    }
}
