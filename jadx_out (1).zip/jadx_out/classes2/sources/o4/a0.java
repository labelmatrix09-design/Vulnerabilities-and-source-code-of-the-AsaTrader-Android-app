package o4;

import android.view.View;

/* JADX INFO: compiled from: R8$$SyntheticClass */
/* JADX INFO: loaded from: /home/kali/Desktop/bunt/agah/dex_files/classes2.dex */
public final /* synthetic */ class a0 implements View.OnClickListener {
    public final /* synthetic */ String o;
    public final /* synthetic */ String p;
    public final /* synthetic */ s7.v q;
    public final /* synthetic */ i0 r;

    public /* synthetic */ a0(String str, String str2, s7.v vVar, i0 i0Var) {
        this.o = str;
        this.p = str2;
        this.q = vVar;
        this.r = i0Var;
    }

    @Override // android.view.View.OnClickListener
    public final void onClick(View view) {
        i0.q2(this.o, this.p, this.q, this.r, view);
    }
}
