package o4;

import android.content.DialogInterface;

/* JADX INFO: compiled from: R8$$SyntheticClass */
/* JADX INFO: loaded from: /home/kali/Desktop/bunt/agah/dex_files/classes2.dex */
public final /* synthetic */ class i implements DialogInterface.OnCancelListener {
    public final /* synthetic */ jl.z o;

    @Override // android.content.DialogInterface.OnCancelListener
    public final void onCancel(DialogInterface dialogInterface) {
        r.a.m(this.o, dialogInterface);
    }
}
