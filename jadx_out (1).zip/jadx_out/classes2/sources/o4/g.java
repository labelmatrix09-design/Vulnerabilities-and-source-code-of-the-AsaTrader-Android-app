package o4;

import android.app.Activity;
import android.app.Dialog;
import javax.crypto.Cipher;

/* JADX INFO: compiled from: R8$$SyntheticClass */
/* JADX INFO: loaded from: /home/kali/Desktop/bunt/agah/dex_files/classes2.dex */
public final /* synthetic */ class g implements Runnable {
    public final /* synthetic */ il.l o;
    public final /* synthetic */ Cipher p;
    public final /* synthetic */ Activity q;
    public final /* synthetic */ Dialog r;
    public final /* synthetic */ jl.z s;

    public /* synthetic */ g(il.l lVar, Cipher cipher, Activity activity, Dialog dialog, jl.z zVar) {
        this.o = lVar;
        this.p = cipher;
        this.q = activity;
        this.r = dialog;
        this.s = zVar;
    }

    @Override // java.lang.Runnable
    public final void run() {
        r.a.k(this.o, this.p, this.q, this.r, this.s);
    }
}
