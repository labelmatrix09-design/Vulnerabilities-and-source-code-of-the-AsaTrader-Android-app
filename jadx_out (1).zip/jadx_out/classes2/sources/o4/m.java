package o4;

import android.app.Activity;
import android.app.Dialog;
import android.view.View;

/* JADX INFO: compiled from: R8$$SyntheticClass */
/* JADX INFO: loaded from: /home/kali/Desktop/bunt/agah/dex_files/classes2.dex */
public final /* synthetic */ class m implements View.OnClickListener {
    public final /* synthetic */ Dialog o;
    public final /* synthetic */ il.l p;
    public final /* synthetic */ Activity q;
    public final /* synthetic */ String r;
    public final /* synthetic */ String s;
    public final /* synthetic */ String t;
    public final /* synthetic */ String u;
    public final /* synthetic */ boolean v;

    public /* synthetic */ m(Dialog dialog, il.l lVar, Activity activity, String str, String str2, String str3, String str4, boolean z) {
        this.o = dialog;
        this.p = lVar;
        this.q = activity;
        this.r = str;
        this.s = str2;
        this.t = str3;
        this.u = str4;
        this.v = z;
    }

    @Override // android.view.View.OnClickListener
    public final void onClick(View view) {
        r.a.h(this.o, this.p, this.q, this.r, this.s, this.t, this.u, this.v, view);
    }
}
