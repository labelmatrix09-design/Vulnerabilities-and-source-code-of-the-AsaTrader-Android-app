package o4;

import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

/* JADX INFO: compiled from: R8$$SyntheticClass */
/* JADX INFO: loaded from: /home/kali/Desktop/bunt/agah/dex_files/classes2.dex */
public final /* synthetic */ class w implements SwipeRefreshLayout.j {
    public final /* synthetic */ i0 a;

    public final void a() {
        i0.y2(this.a);
    }
}
