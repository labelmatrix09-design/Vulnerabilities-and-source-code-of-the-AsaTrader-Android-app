package o4;

/* JADX INFO: compiled from: R8$$SyntheticClass */
/* JADX INFO: loaded from: /home/kali/Desktop/bunt/agah/dex_files/classes2.dex */
public final /* synthetic */ class x implements Runnable {
    public final /* synthetic */ i0 o;

    @Override // java.lang.Runnable
    public final void run() {
        i0.r2(this.o);
    }
}
