package o4;

import android.app.Dialog;
import android.view.View;

/* JADX INFO: compiled from: R8$$SyntheticClass */
/* JADX INFO: loaded from: /home/kali/Desktop/bunt/agah/dex_files/classes2.dex */
public final /* synthetic */ class u implements View.OnClickListener {
    public final /* synthetic */ s7.l o;
    public final /* synthetic */ i0 p;
    public final /* synthetic */ Dialog q;

    public /* synthetic */ u(s7.l lVar, i0 i0Var, Dialog dialog) {
        this.o = lVar;
        this.p = i0Var;
        this.q = dialog;
    }

    @Override // android.view.View.OnClickListener
    public final void onClick(View view) {
        i0.u2(this.o, this.p, this.q, view);
    }
}
