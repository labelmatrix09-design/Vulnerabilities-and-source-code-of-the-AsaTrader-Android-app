package o4;

import android.app.Dialog;
import android.view.View;

/* JADX INFO: compiled from: R8$$SyntheticClass */
/* JADX INFO: loaded from: /home/kali/Desktop/bunt/agah/dex_files/classes2.dex */
public final /* synthetic */ class s implements View.OnClickListener {
    public final /* synthetic */ Dialog o;

    @Override // android.view.View.OnClickListener
    public final void onClick(View view) {
        i0.D2(this.o, view);
    }
}
