package o4;

import android.content.Context;
import android.view.View;
import v4.p5;

/* JADX INFO: compiled from: R8$$SyntheticClass */
/* JADX INFO: loaded from: /home/kali/Desktop/bunt/agah/dex_files/classes2.dex */
public final /* synthetic */ class n implements View.OnClickListener {
    public final /* synthetic */ Context o;
    public final /* synthetic */ p5 p;

    public /* synthetic */ n(Context context, p5 p5Var) {
        this.o = context;
        this.p = p5Var;
    }

    @Override // android.view.View.OnClickListener
    public final void onClick(View view) {
        r.a.d(this.o, this.p, view);
    }
}
