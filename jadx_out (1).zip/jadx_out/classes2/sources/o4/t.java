package o4;

import android.view.View;

/* JADX INFO: compiled from: R8$$SyntheticClass */
/* JADX INFO: loaded from: /home/kali/Desktop/bunt/agah/dex_files/classes2.dex */
public final /* synthetic */ class t implements View.OnClickListener {
    public final /* synthetic */ i0 o;
    public final /* synthetic */ String p;
    public final /* synthetic */ String q;

    public /* synthetic */ t(i0 i0Var, String str, String str2) {
        this.o = i0Var;
        this.p = str;
        this.q = str2;
    }

    @Override // android.view.View.OnClickListener
    public final void onClick(View view) {
        i0.w2(this.o, this.p, this.q, view);
    }
}
