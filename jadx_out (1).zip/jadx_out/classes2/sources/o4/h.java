package o4;

/* JADX INFO: compiled from: R8$$SyntheticClass */
/* JADX INFO: loaded from: /home/kali/Desktop/bunt/agah/dex_files/classes2.dex */
public final /* synthetic */ class h implements Runnable {
    public final /* synthetic */ s7.v o;

    @Override // java.lang.Runnable
    public final void run() {
        r.a.o(this.o);
    }
}
