package ni;

/* JADX INFO: compiled from: ElasticEaseIn.java */
/* JADX INFO: loaded from: /home/kali/Desktop/bunt/agah/dex_files/classes2.dex */
public class a extends fi.b {
    @Override // fi.b
    public Float b(float f, float f2, float f5, float f6) {
        if (f == 0.0f) {
            return Float.valueOf(f2);
        }
        float f7 = f / f6;
        if (f7 == 1.0f) {
            return Float.valueOf(f2 + f5);
        }
        float f8 = 0.3f * f6;
        float f9 = f7 - 1.0f;
        return Float.valueOf((-(f5 * ((float) Math.pow(2.0d, 10.0f * f9)) * ((float) Math.sin((((f9 * f6) - (f8 / 4.0f)) * 6.2831855f) / f8)))) + f2);
    }
}
