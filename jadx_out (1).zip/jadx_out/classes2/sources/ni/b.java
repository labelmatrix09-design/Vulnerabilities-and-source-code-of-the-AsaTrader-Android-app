package ni;

/* JADX INFO: compiled from: ElasticEaseOut.java */
/* JADX INFO: loaded from: /home/kali/Desktop/bunt/agah/dex_files/classes2.dex */
public class b extends fi.b {
    @Override // fi.b
    public Float b(float f, float f2, float f5, float f6) {
        if (f == 0.0f) {
            return Float.valueOf(f2);
        }
        float f7 = f / f6;
        if (f7 == 1.0f) {
            return Float.valueOf(f2 + f5);
        }
        float f8 = 0.3f * f6;
        return Float.valueOf((((float) Math.pow(2.0d, (-10.0f) * f7)) * f5 * ((float) Math.sin((((f7 * f6) - (f8 / 4.0f)) * 6.2831855f) / f8))) + f5 + f2);
    }
}
