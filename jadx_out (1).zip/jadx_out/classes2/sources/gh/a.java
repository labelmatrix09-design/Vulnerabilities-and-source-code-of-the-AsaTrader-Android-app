package gh;

import com.google.zxing.ChecksumException;

/* JADX INFO: compiled from: ErrorCorrection.java */
/* JADX INFO: loaded from: /home/kali/Desktop/bunt/agah/dex_files/classes2.dex */
public final class a {
    public final b a = b.f;

    public int a(int[] iArr, int i, int[] iArr2) throws ChecksumException {
        c cVar = new c(this.a, iArr);
        int[] iArr3 = new int[i];
        boolean z = false;
        for (int i3 = i; i3 > 0; i3--) {
            int iB = cVar.b(this.a.c(i3));
            iArr3[i - i3] = iB;
            if (iB != 0) {
                z = true;
            }
        }
        if (!z) {
            return 0;
        }
        c cVarD = this.a.d();
        if (iArr2 != null) {
            for (int i5 : iArr2) {
                int iC = this.a.c((iArr.length - 1) - i5);
                b bVar = this.a;
                cVarD = cVarD.g(new c(bVar, new int[]{bVar.j(0, iC), 1}));
            }
        }
        c[] cVarArrD = d(this.a.b(i, 1), new c(this.a, iArr3), i);
        c cVar2 = cVarArrD[0];
        c cVar3 = cVarArrD[1];
        int[] iArrB = b(cVar2);
        int[] iArrC = c(cVar3, cVar2, iArrB);
        for (int i6 = 0; i6 < iArrB.length; i6++) {
            int length = (iArr.length - 1) - this.a.h(iArrB[i6]);
            if (length < 0) {
                throw ChecksumException.a();
            }
            iArr[length] = this.a.j(iArr[length], iArrC[i6]);
        }
        return iArrB.length;
    }

    public final int[] b(c cVar) throws ChecksumException {
        int iD = cVar.d();
        int[] iArr = new int[iD];
        int i = 0;
        for (int i3 = 1; i3 < this.a.e() && i < iD; i3++) {
            if (cVar.b(i3) == 0) {
                iArr[i] = this.a.g(i3);
                i++;
            }
        }
        if (i == iD) {
            return iArr;
        }
        throw ChecksumException.a();
    }

    public final int[] c(c cVar, c cVar2, int[] iArr) {
        int iD = cVar2.d();
        int[] iArr2 = new int[iD];
        for (int i = 1; i <= iD; i++) {
            iArr2[iD - i] = this.a.i(i, cVar2.c(i));
        }
        c cVar3 = new c(this.a, iArr2);
        int length = iArr.length;
        int[] iArr3 = new int[length];
        for (int i3 = 0; i3 < length; i3++) {
            int iG = this.a.g(iArr[i3]);
            iArr3[i3] = this.a.i(this.a.j(0, cVar.b(iG)), this.a.g(cVar3.b(iG)));
        }
        return iArr3;
    }

    public final c[] d(c cVar, c cVar2, int i) throws ChecksumException {
        if (cVar.d() < cVar2.d()) {
            cVar2 = cVar;
            cVar = cVar2;
        }
        c cVarF = this.a.f();
        c cVarD = this.a.d();
        while (true) {
            c cVar3 = cVar2;
            cVar2 = cVar;
            cVar = cVar3;
            c cVar4 = cVarD;
            c cVar5 = cVarF;
            cVarF = cVar4;
            if (cVar.d() < i / 2) {
                int iC = cVarF.c(0);
                if (iC == 0) {
                    throw ChecksumException.a();
                }
                int iG = this.a.g(iC);
                return new c[]{cVarF.f(iG), cVar.f(iG)};
            }
            if (cVar.e()) {
                throw ChecksumException.a();
            }
            c cVarF2 = this.a.f();
            int iG2 = this.a.g(cVar.c(cVar.d()));
            while (cVar2.d() >= cVar.d() && !cVar2.e()) {
                int iD = cVar2.d() - cVar.d();
                int i3 = this.a.i(cVar2.c(cVar2.d()), iG2);
                cVarF2 = cVarF2.a(this.a.b(iD, i3));
                cVar2 = cVar2.j(cVar.h(iD, i3));
            }
            cVarD = cVarF2.g(cVarF).j(cVar5).i();
        }
    }
}
