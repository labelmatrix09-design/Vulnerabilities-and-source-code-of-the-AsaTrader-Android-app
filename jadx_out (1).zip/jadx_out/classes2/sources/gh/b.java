package gh;

/* JADX INFO: compiled from: ModulusGF.java */
/* JADX INFO: loaded from: /home/kali/Desktop/bunt/agah/dex_files/classes2.dex */
public final class b {
    public static final b f = new b(929, 3);
    public final int[] a;
    public final int[] b;
    public final c c;
    public final c d;
    public final int e;

    public b(int i, int i3) {
        this.e = i;
        this.a = new int[i];
        this.b = new int[i];
        int i5 = 1;
        for (int i6 = 0; i6 < i; i6++) {
            this.a[i6] = i5;
            i5 = (i5 * i3) % i;
        }
        for (int i7 = 0; i7 < i - 1; i7++) {
            this.b[this.a[i7]] = i7;
        }
        this.c = new c(this, new int[]{0});
        this.d = new c(this, new int[]{1});
    }

    public int a(int i, int i3) {
        return (i + i3) % this.e;
    }

    public c b(int i, int i3) {
        if (i < 0) {
            throw new IllegalArgumentException();
        }
        if (i3 == 0) {
            return this.c;
        }
        int[] iArr = new int[i + 1];
        iArr[0] = i3;
        return new c(this, iArr);
    }

    public int c(int i) {
        return this.a[i];
    }

    public c d() {
        return this.d;
    }

    public int e() {
        return this.e;
    }

    public c f() {
        return this.c;
    }

    public int g(int i) {
        if (i != 0) {
            return this.a[(this.e - this.b[i]) - 1];
        }
        throw new ArithmeticException();
    }

    public int h(int i) {
        if (i != 0) {
            return this.b[i];
        }
        throw new IllegalArgumentException();
    }

    public int i(int i, int i3) {
        if (i == 0 || i3 == 0) {
            return 0;
        }
        int[] iArr = this.a;
        int[] iArr2 = this.b;
        return iArr[(iArr2[i] + iArr2[i3]) % (this.e - 1)];
    }

    public int j(int i, int i3) {
        int i5 = this.e;
        return ((i + i5) - i3) % i5;
    }
}
