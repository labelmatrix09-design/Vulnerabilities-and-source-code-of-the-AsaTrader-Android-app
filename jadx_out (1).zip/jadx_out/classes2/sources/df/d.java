package df;

import com.google.errorprone.annotations.CanIgnoreReturnValue;

/* JADX INFO: compiled from: MathPreconditions.java */
/* JADX INFO: loaded from: /home/kali/Desktop/bunt/agah/dex_files/classes2.dex */
@CanIgnoreReturnValue
public final class d {
    public static void a(boolean z) {
        if (!z) {
            throw new ArithmeticException("mode was UNNECESSARY, but rounding was necessary");
        }
    }
}
