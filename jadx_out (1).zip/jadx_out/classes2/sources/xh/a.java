package xh;

import yh.b;
import yh.d;

/* JADX INFO: compiled from: OSInfluenceConstants.kt */
/* JADX INFO: loaded from: /home/kali/Desktop/bunt/agah/dex_files/classes2.dex */
public final class a {
    public static final String a;
    public static final String b;
    public static final a c = new a();

    static {
        String canonicalName = b.class.getCanonicalName();
        if (canonicalName == null) {
            throw new NullPointerException("null cannot be cast to non-null type kotlin.String");
        }
        a = canonicalName;
        String canonicalName2 = d.class.getCanonicalName();
        if (canonicalName2 == null) {
            throw new NullPointerException("null cannot be cast to non-null type kotlin.String");
        }
        b = canonicalName2;
    }

    public final String a() {
        return a;
    }

    public final String b() {
        return b;
    }
}
