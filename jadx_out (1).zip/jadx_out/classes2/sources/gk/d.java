package gk;

import tj.e;
import tj.i;

/* JADX INFO: compiled from: Subject.java */
/* JADX INFO: loaded from: /home/kali/Desktop/bunt/agah/dex_files/classes2.dex */
public abstract class d<T> extends e<T> implements i<T> {
}
