package gk;

import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicReference;
import tj.j;
import tj.k;

/* JADX INFO: compiled from: SingleSubject.java */
/* JADX INFO: loaded from: /home/kali/Desktop/bunt/agah/dex_files/classes2.dex */
public final class c<T> extends j<T> implements k<T> {
    public static final a[] s = new a[0];
    public static final a[] t = new a[0];
    public T q;
    public Throwable r;
    public final AtomicBoolean p = new AtomicBoolean();
    public final AtomicReference<a<T>[]> o = new AtomicReference<>(s);

    /* JADX INFO: compiled from: SingleSubject.java */
    public static final class a<T> extends AtomicReference<c<T>> implements uj.a {
        public final k<? super T> o;

        public a(k<? super T> kVar, c<T> cVar) {
            this.o = kVar;
            lazySet(cVar);
        }

        public boolean a() {
            return get() == null;
        }

        @Override // uj.a
        public void e() {
            c<T> andSet = getAndSet(null);
            if (andSet != null) {
                andSet.p(this);
            }
        }
    }

    public static <T> c<T> o() {
        return new c<>();
    }

    @Override // tj.k, tj.b
    public void b(Throwable th2) {
        yj.b.c(th2, "onError called with null. Null values are generally not allowed in 2.x operators and sources.");
        if (!this.p.compareAndSet(false, true)) {
            fk.a.i(th2);
            return;
        }
        this.r = th2;
        for (a<T> aVar : this.o.getAndSet(t)) {
            aVar.o.b(th2);
        }
    }

    @Override // tj.k, tj.b
    public void c(uj.a aVar) {
        if (this.o.get() == t) {
            aVar.e();
        }
    }

    @Override // tj.k
    public void d(T t2) {
        yj.b.c(t2, "onSuccess called with null. Null values are generally not allowed in 2.x operators and sources.");
        if (this.p.compareAndSet(false, true)) {
            this.q = t2;
            for (a<T> aVar : this.o.getAndSet(t)) {
                aVar.o.d(t2);
            }
        }
    }

    @Override // tj.j
    public void m(k<? super T> kVar) {
        a<T> aVar = new a<>(kVar, this);
        kVar.c(aVar);
        if (n(aVar)) {
            if (aVar.a()) {
                p(aVar);
            }
        } else {
            Throwable th2 = this.r;
            if (th2 != null) {
                kVar.b(th2);
            } else {
                kVar.d(this.q);
            }
        }
    }

    public boolean n(a<T> aVar) {
        a<T>[] aVarArr;
        a<T>[] aVarArr2;
        do {
            aVarArr = this.o.get();
            if (aVarArr == t) {
                return false;
            }
            int length = aVarArr.length;
            aVarArr2 = new a[length + 1];
            System.arraycopy(aVarArr, 0, aVarArr2, 0, length);
            aVarArr2[length] = aVar;
        } while (!this.o.compareAndSet(aVarArr, aVarArr2));
        return true;
    }

    public void p(a<T> aVar) {
        a<T>[] aVarArr;
        a<T>[] aVarArr2;
        do {
            aVarArr = this.o.get();
            int length = aVarArr.length;
            if (length == 0) {
                return;
            }
            int i = -1;
            for (int i3 = 0; i3 < length; i3++) {
                if (aVarArr[i3] == aVar) {
                    i = i3;
                    break;
                }
            }
            if (i < 0) {
                return;
            }
            if (length == 1) {
                aVarArr2 = s;
            } else {
                a<T>[] aVarArr3 = new a[length - 1];
                System.arraycopy(aVarArr, 0, aVarArr3, 0, i);
                System.arraycopy(aVarArr, i + 1, aVarArr3, i, (length - i) - 1);
                aVarArr2 = aVarArr3;
            }
        } while (!this.o.compareAndSet(aVarArr, aVarArr2));
    }
}
