package gk;

import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicReference;

/* JADX INFO: compiled from: CompletableSubject.java */
/* JADX INFO: loaded from: /home/kali/Desktop/bunt/agah/dex_files/classes2.dex */
public final class a extends tj.a implements tj.b {
    public static final C0051a[] r = new C0051a[0];
    public static final C0051a[] s = new C0051a[0];
    public Throwable q;
    public final AtomicBoolean p = new AtomicBoolean();
    public final AtomicReference<C0051a[]> o = new AtomicReference<>(r);

    /* JADX INFO: renamed from: gk.a$a, reason: collision with other inner class name */
    /* JADX INFO: compiled from: CompletableSubject.java */
    public static final class C0051a extends AtomicReference<a> implements uj.a {
        public final tj.b o;

        public C0051a(tj.b bVar, a aVar) {
            this.o = bVar;
            lazySet(aVar);
        }

        public boolean a() {
            return get() == null;
        }

        @Override // uj.a
        public void e() {
            a andSet = getAndSet(null);
            if (andSet != null) {
                andSet.x(this);
            }
        }
    }

    public static a u() {
        return new a();
    }

    @Override // tj.b
    public void a() {
        if (this.p.compareAndSet(false, true)) {
            for (C0051a c0051a : this.o.getAndSet(s)) {
                c0051a.o.a();
            }
        }
    }

    @Override // tj.b
    public void b(Throwable th2) {
        yj.b.c(th2, "onError called with null. Null values are generally not allowed in 2.x operators and sources.");
        if (!this.p.compareAndSet(false, true)) {
            fk.a.i(th2);
            return;
        }
        this.q = th2;
        for (C0051a c0051a : this.o.getAndSet(s)) {
            c0051a.o.b(th2);
        }
    }

    @Override // tj.b
    public void c(uj.a aVar) {
        if (this.o.get() == s) {
            aVar.e();
        }
    }

    @Override // tj.a
    public void p(tj.b bVar) {
        C0051a c0051a = new C0051a(bVar, this);
        bVar.c(c0051a);
        if (t(c0051a)) {
            if (c0051a.a()) {
                x(c0051a);
            }
        } else {
            Throwable th2 = this.q;
            if (th2 != null) {
                bVar.b(th2);
            } else {
                bVar.a();
            }
        }
    }

    public boolean t(C0051a c0051a) {
        C0051a[] c0051aArr;
        C0051a[] c0051aArr2;
        do {
            c0051aArr = this.o.get();
            if (c0051aArr == s) {
                return false;
            }
            int length = c0051aArr.length;
            c0051aArr2 = new C0051a[length + 1];
            System.arraycopy(c0051aArr, 0, c0051aArr2, 0, length);
            c0051aArr2[length] = c0051a;
        } while (!this.o.compareAndSet(c0051aArr, c0051aArr2));
        return true;
    }

    public boolean v() {
        return this.o.get() == s && this.q == null;
    }

    public boolean w() {
        return this.o.get() == s && this.q != null;
    }

    public void x(C0051a c0051a) {
        C0051a[] c0051aArr;
        C0051a[] c0051aArr2;
        do {
            c0051aArr = this.o.get();
            int length = c0051aArr.length;
            if (length == 0) {
                return;
            }
            int i = -1;
            for (int i3 = 0; i3 < length; i3++) {
                if (c0051aArr[i3] == c0051a) {
                    i = i3;
                    break;
                }
            }
            if (i < 0) {
                return;
            }
            if (length == 1) {
                c0051aArr2 = r;
            } else {
                C0051a[] c0051aArr3 = new C0051a[length - 1];
                System.arraycopy(c0051aArr, 0, c0051aArr3, 0, i);
                System.arraycopy(c0051aArr, i + 1, c0051aArr3, i, (length - i) - 1);
                c0051aArr2 = c0051aArr3;
            }
        } while (!this.o.compareAndSet(c0051aArr, c0051aArr2));
    }
}
