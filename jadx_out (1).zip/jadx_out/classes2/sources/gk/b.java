package gk;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicReference;
import tj.i;

/* JADX INFO: compiled from: ReplaySubject.java */
/* JADX INFO: loaded from: /home/kali/Desktop/bunt/agah/dex_files/classes2.dex */
public final class b<T> extends d<T> {
    public static final C0052b[] r = new C0052b[0];
    public static final C0052b[] s = new C0052b[0];
    public static final Object[] t = new Object[0];
    public final a<T> o;
    public final AtomicReference<C0052b<T>[]> p = new AtomicReference<>(r);
    public boolean q;

    /* JADX INFO: compiled from: ReplaySubject.java */
    public interface a<T> {
        void a(Object obj);

        void add(T t);

        void b(C0052b<T> c0052b);

        boolean compareAndSet(Object obj, Object obj2);
    }

    /* JADX INFO: renamed from: gk.b$b, reason: collision with other inner class name */
    /* JADX INFO: compiled from: ReplaySubject.java */
    public static final class C0052b<T> extends AtomicInteger implements uj.a {
        public final i<? super T> o;
        public final b<T> p;
        public Object q;
        public volatile boolean r;

        public C0052b(i<? super T> iVar, b<T> bVar) {
            this.o = iVar;
            this.p = bVar;
        }

        @Override // uj.a
        public void e() {
            if (this.r) {
                return;
            }
            this.r = true;
            this.p.s(this);
        }
    }

    /* JADX INFO: compiled from: ReplaySubject.java */
    public static final class c<T> extends AtomicReference<Object> implements a<T> {
        public final List<Object> o;
        public volatile boolean p;
        public volatile int q;

        public c(int i) {
            this.o = new ArrayList(yj.b.d(i, "capacityHint"));
        }

        @Override // gk.b.a
        public void a(Object obj) {
            this.o.add(obj);
            c();
            this.q++;
            this.p = true;
        }

        @Override // gk.b.a
        public void add(T t) {
            this.o.add(t);
            this.q++;
        }

        @Override // gk.b.a
        public void b(C0052b<T> c0052b) {
            int i;
            if (c0052b.getAndIncrement() != 0) {
                return;
            }
            List<Object> list = this.o;
            i<? super T> iVar = c0052b.o;
            Integer num = (Integer) c0052b.q;
            int iIntValue = 0;
            if (num != null) {
                iIntValue = num.intValue();
            } else {
                c0052b.q = 0;
            }
            int iAddAndGet = 1;
            while (!c0052b.r) {
                int i3 = this.q;
                while (i3 != iIntValue) {
                    if (c0052b.r) {
                        c0052b.q = null;
                        return;
                    }
                    Object obj = list.get(iIntValue);
                    if (this.p && (i = iIntValue + 1) == i3 && i == (i3 = this.q)) {
                        if (ek.c.g(obj)) {
                            iVar.a();
                        } else {
                            iVar.b(ek.c.f(obj));
                        }
                        c0052b.q = null;
                        c0052b.r = true;
                        return;
                    }
                    iVar.d(obj);
                    iIntValue++;
                }
                if (iIntValue == this.q) {
                    c0052b.q = Integer.valueOf(iIntValue);
                    iAddAndGet = c0052b.addAndGet(-iAddAndGet);
                    if (iAddAndGet == 0) {
                        return;
                    }
                }
            }
            c0052b.q = null;
        }

        public void c() {
        }
    }

    public b(a<T> aVar) {
        this.o = aVar;
    }

    public static <T> b<T> r() {
        return new b<>(new c(16));
    }

    @Override // tj.i
    public void a() {
        if (this.q) {
            return;
        }
        this.q = true;
        Object objD = ek.c.d();
        a<T> aVar = this.o;
        aVar.a(objD);
        for (C0052b<T> c0052b : t(objD)) {
            aVar.b(c0052b);
        }
    }

    @Override // tj.i
    public void b(Throwable th2) {
        yj.b.c(th2, "onError called with null. Null values are generally not allowed in 2.x operators and sources.");
        if (this.q) {
            fk.a.i(th2);
            return;
        }
        this.q = true;
        Object objE = ek.c.e(th2);
        a<T> aVar = this.o;
        aVar.a(objE);
        for (C0052b<T> c0052b : t(objE)) {
            aVar.b(c0052b);
        }
    }

    @Override // tj.i
    public void c(uj.a aVar) {
        if (this.q) {
            aVar.e();
        }
    }

    @Override // tj.i
    public void d(T t2) {
        yj.b.c(t2, "onNext called with null. Null values are generally not allowed in 2.x operators and sources.");
        if (this.q) {
            return;
        }
        a<T> aVar = this.o;
        aVar.add(t2);
        for (C0052b<T> c0052b : this.p.get()) {
            aVar.b(c0052b);
        }
    }

    @Override // tj.e
    public void p(i<? super T> iVar) {
        C0052b<T> c0052b = new C0052b<>(iVar, this);
        iVar.c(c0052b);
        if (c0052b.r) {
            return;
        }
        if (q(c0052b) && c0052b.r) {
            s(c0052b);
        } else {
            this.o.b(c0052b);
        }
    }

    public boolean q(C0052b<T> c0052b) {
        C0052b<T>[] c0052bArr;
        C0052b<T>[] c0052bArr2;
        do {
            c0052bArr = this.p.get();
            if (c0052bArr == s) {
                return false;
            }
            int length = c0052bArr.length;
            c0052bArr2 = new C0052b[length + 1];
            System.arraycopy(c0052bArr, 0, c0052bArr2, 0, length);
            c0052bArr2[length] = c0052b;
        } while (!this.p.compareAndSet(c0052bArr, c0052bArr2));
        return true;
    }

    public void s(C0052b<T> c0052b) {
        C0052b<T>[] c0052bArr;
        C0052b<T>[] c0052bArr2;
        do {
            c0052bArr = this.p.get();
            if (c0052bArr == s || c0052bArr == r) {
                return;
            }
            int length = c0052bArr.length;
            int i = -1;
            for (int i3 = 0; i3 < length; i3++) {
                if (c0052bArr[i3] == c0052b) {
                    i = i3;
                    break;
                }
            }
            if (i < 0) {
                return;
            }
            if (length == 1) {
                c0052bArr2 = r;
            } else {
                C0052b<T>[] c0052bArr3 = new C0052b[length - 1];
                System.arraycopy(c0052bArr, 0, c0052bArr3, 0, i);
                System.arraycopy(c0052bArr, i + 1, c0052bArr3, i, (length - i) - 1);
                c0052bArr2 = c0052bArr3;
            }
        } while (!this.p.compareAndSet(c0052bArr, c0052bArr2));
    }

    public C0052b<T>[] t(Object obj) {
        return this.o.compareAndSet(null, obj) ? this.p.getAndSet(s) : s;
    }
}
