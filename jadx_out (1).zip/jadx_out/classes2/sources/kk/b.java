package kk;

import pk.k;

/* JADX INFO: compiled from: SentryNdkUtil.java */
/* JADX INFO: loaded from: /home/kali/Desktop/bunt/agah/dex_files/classes2.dex */
public final class b {
    public static void a(k kVar) {
        if (kVar == null) {
            return;
        }
        kVar.c("maven:io.sentry:sentry-android-ndk", "6.1.4");
    }
}
