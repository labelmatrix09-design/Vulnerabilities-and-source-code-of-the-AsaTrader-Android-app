package kk;

/* JADX INFO: compiled from: INativeScope.java */
/* JADX INFO: loaded from: /home/kali/Desktop/bunt/agah/dex_files/classes2.dex */
public interface a {
    void a(String str, String str2, String str3, String str4, String str5, String str6);
}
