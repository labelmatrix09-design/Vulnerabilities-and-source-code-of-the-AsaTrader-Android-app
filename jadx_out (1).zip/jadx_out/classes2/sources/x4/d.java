package x4;

/* JADX INFO: compiled from: R8$$SyntheticClass */
/* JADX INFO: loaded from: /home/kali/Desktop/bunt/agah/dex_files/classes2.dex */
public final /* synthetic */ class d implements Runnable {
    public final /* synthetic */ long o;

    @Override // java.lang.Runnable
    public final void run() {
        l.a.e(this.o);
    }
}
