package x4;

import android.app.Activity;

/* JADX INFO: compiled from: R8$$SyntheticClass */
/* JADX INFO: loaded from: /home/kali/Desktop/bunt/agah/dex_files/classes2.dex */
public final /* synthetic */ class f implements Runnable {
    public final /* synthetic */ l.a.a o;
    public final /* synthetic */ int p;
    public final /* synthetic */ Activity q;

    public /* synthetic */ f(l.a.a aVar, int i, Activity activity) {
        this.o = aVar;
        this.p = i;
        this.q = activity;
    }

    @Override // java.lang.Runnable
    public final void run() {
        l.a.g(this.o, this.p, this.q);
    }
}
