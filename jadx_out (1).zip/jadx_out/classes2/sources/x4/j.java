package x4;

/* JADX INFO: compiled from: R8$$SyntheticClass */
/* JADX INFO: loaded from: /home/kali/Desktop/bunt/agah/dex_files/classes2.dex */
public final /* synthetic */ class j implements Runnable {
    public static final /* synthetic */ j o = new j();

    @Override // java.lang.Runnable
    public final void run() {
        l.a.f();
    }
}
