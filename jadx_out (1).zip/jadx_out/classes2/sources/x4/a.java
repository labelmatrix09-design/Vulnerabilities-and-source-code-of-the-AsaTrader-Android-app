package x4;

import java.util.Comparator;

/* JADX INFO: compiled from: R8$$SyntheticClass */
/* JADX INFO: loaded from: /home/kali/Desktop/bunt/agah/dex_files/classes2.dex */
public final /* synthetic */ class a implements Comparator {
    public final /* synthetic */ String o;
    public final /* synthetic */ int p;

    public /* synthetic */ a(String str, int i) {
        this.o = str;
        this.p = i;
    }

    @Override // java.util.Comparator
    public final int compare(Object obj, Object obj2) {
        return b.a.a(this.o, this.p, (b) obj, (b) obj2);
    }
}
