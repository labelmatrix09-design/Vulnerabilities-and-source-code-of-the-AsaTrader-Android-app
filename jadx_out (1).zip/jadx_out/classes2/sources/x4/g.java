package x4;

/* JADX INFO: compiled from: R8$$SyntheticClass */
/* JADX INFO: loaded from: /home/kali/Desktop/bunt/agah/dex_files/classes2.dex */
public final /* synthetic */ class g implements Runnable {
    public static final /* synthetic */ g o = new g();

    @Override // java.lang.Runnable
    public final void run() {
        l.a.a();
    }
}
