package tg;

/* JADX INFO: compiled from: GenericGF.java */
/* JADX INFO: loaded from: /home/kali/Desktop/bunt/agah/dex_files/classes2.dex */
public final class a {
    public static final a h = new a(4201, 4096, 1);
    public static final a i = new a(1033, 1024, 1);
    public static final a j;
    public static final a k;
    public static final a l;
    public static final a m;
    public static final a n;
    public static final a o;
    public final int[] a;
    public final int[] b;
    public final b c;
    public final b d;
    public final int e;
    public final int f;
    public final int g;

    static {
        a aVar = new a(67, 64, 1);
        j = aVar;
        k = new a(19, 16, 1);
        l = new a(285, 256, 0);
        a aVar2 = new a(301, 256, 1);
        m = aVar2;
        n = aVar2;
        o = aVar;
    }

    public a(int i3, int i5, int i6) {
        this.f = i3;
        this.e = i5;
        this.g = i6;
        this.a = new int[i5];
        this.b = new int[i5];
        int i7 = 1;
        for (int i8 = 0; i8 < i5; i8++) {
            this.a[i8] = i7;
            i7 <<= 1;
            if (i7 >= i5) {
                i7 = (i7 ^ i3) & (i5 - 1);
            }
        }
        for (int i9 = 0; i9 < i5 - 1; i9++) {
            this.b[this.a[i9]] = i9;
        }
        this.c = new b(this, new int[]{0});
        this.d = new b(this, new int[]{1});
    }

    public static int a(int i3, int i5) {
        return i3 ^ i5;
    }

    public b b(int i3, int i5) {
        if (i3 < 0) {
            throw new IllegalArgumentException();
        }
        if (i5 == 0) {
            return this.c;
        }
        int[] iArr = new int[i3 + 1];
        iArr[0] = i5;
        return new b(this, iArr);
    }

    public int c(int i3) {
        return this.a[i3];
    }

    public int d() {
        return this.g;
    }

    public b e() {
        return this.d;
    }

    public int f() {
        return this.e;
    }

    public b g() {
        return this.c;
    }

    public int h(int i3) {
        if (i3 != 0) {
            return this.a[(this.e - this.b[i3]) - 1];
        }
        throw new ArithmeticException();
    }

    public int i(int i3) {
        if (i3 != 0) {
            return this.b[i3];
        }
        throw new IllegalArgumentException();
    }

    public int j(int i3, int i5) {
        if (i3 == 0 || i5 == 0) {
            return 0;
        }
        int[] iArr = this.a;
        int[] iArr2 = this.b;
        return iArr[(iArr2[i3] + iArr2[i5]) % (this.e - 1)];
    }

    public String toString() {
        return "GF(0x" + Integer.toHexString(this.f) + ',' + this.e + ')';
    }
}
