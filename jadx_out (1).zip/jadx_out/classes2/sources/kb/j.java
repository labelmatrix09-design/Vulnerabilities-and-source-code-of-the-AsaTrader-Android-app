package kb;

import android.net.Uri;
import cb.l;
import cb.q;
import cb.r;
import java.util.Map;

/* JADX INFO: compiled from: R8$$SyntheticClass */
/* JADX INFO: loaded from: /home/kali/Desktop/bunt/agah/dex_files/classes2.dex */
public final /* synthetic */ class j implements r {
    public static final /* synthetic */ j b = new j();

    public final l[] a() {
        return k.k();
    }

    public /* synthetic */ l[] b(Uri uri, Map map) {
        return q.a(this, uri, map);
    }
}
