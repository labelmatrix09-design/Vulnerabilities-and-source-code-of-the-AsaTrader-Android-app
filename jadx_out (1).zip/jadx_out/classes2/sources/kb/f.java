package kb;

import android.net.Uri;
import cb.l;
import cb.q;
import cb.r;
import java.util.Map;

/* JADX INFO: compiled from: R8$$SyntheticClass */
/* JADX INFO: loaded from: /home/kali/Desktop/bunt/agah/dex_files/classes2.dex */
public final /* synthetic */ class f implements r {
    public static final /* synthetic */ f b = new f();

    public final l[] a() {
        return g.b();
    }

    public /* synthetic */ l[] b(Uri uri, Map map) {
        return q.a(this, uri, map);
    }
}
