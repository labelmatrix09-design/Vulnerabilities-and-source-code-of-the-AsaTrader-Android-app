package kb;

import bf.g;

/* JADX INFO: compiled from: R8$$SyntheticClass */
/* JADX INFO: loaded from: /home/kali/Desktop/bunt/agah/dex_files/classes2.dex */
public final /* synthetic */ class e implements g {
    public final /* synthetic */ g o;

    public final Object apply(Object obj) {
        return this.o.m((o) obj);
    }
}
