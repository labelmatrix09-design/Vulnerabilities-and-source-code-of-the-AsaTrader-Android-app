package kb;

import bf.g;

/* JADX INFO: compiled from: R8$$SyntheticClass */
/* JADX INFO: loaded from: /home/kali/Desktop/bunt/agah/dex_files/classes2.dex */
public final /* synthetic */ class i implements g {
    public static final /* synthetic */ i o = new i();

    public final Object apply(Object obj) {
        return k.j((o) obj);
    }
}
