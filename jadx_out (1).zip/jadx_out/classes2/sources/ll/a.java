package ll;

/* JADX INFO: compiled from: MathH.kt */
/* JADX INFO: loaded from: /home/kali/Desktop/bunt/agah/dex_files/classes2.dex */
public class a {
}
