package k4;

import android.view.View;
import com.agah.trader.controller.transactions.TransactionsPage;

/* JADX INFO: compiled from: R8$$SyntheticClass */
/* JADX INFO: loaded from: /home/kali/Desktop/bunt/agah/dex_files/classes2.dex */
public final /* synthetic */ class b implements View.OnClickListener {
    public final /* synthetic */ TransactionsPage o;

    @Override // android.view.View.OnClickListener
    public final void onClick(View view) {
        TransactionsPage.M0(this.o, view);
    }
}
