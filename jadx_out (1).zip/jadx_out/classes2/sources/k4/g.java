package k4;

import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;
import com.agah.trader.controller.transactions.TransactionsPage;

/* JADX INFO: compiled from: R8$$SyntheticClass */
/* JADX INFO: loaded from: /home/kali/Desktop/bunt/agah/dex_files/classes2.dex */
public final /* synthetic */ class g implements SwipeRefreshLayout.j {
    public final /* synthetic */ TransactionsPage a;

    public final void a() {
        TransactionsPage.L0(this.a);
    }
}
