package k4;

import android.app.Dialog;
import android.view.View;
import com.agah.trader.controller.transactions.TransactionsPage;
import jl.x;

/* JADX INFO: compiled from: R8$$SyntheticClass */
/* JADX INFO: loaded from: /home/kali/Desktop/bunt/agah/dex_files/classes2.dex */
public final /* synthetic */ class e implements View.OnClickListener {
    public final /* synthetic */ TransactionsPage o;
    public final /* synthetic */ x p;
    public final /* synthetic */ View q;
    public final /* synthetic */ Dialog r;

    public /* synthetic */ e(TransactionsPage transactionsPage, x xVar, View view, Dialog dialog) {
        this.o = transactionsPage;
        this.p = xVar;
        this.q = view;
        this.r = dialog;
    }

    @Override // android.view.View.OnClickListener
    public final void onClick(View view) {
        TransactionsPage.Q0(this.o, this.p, this.q, this.r, view);
    }
}
