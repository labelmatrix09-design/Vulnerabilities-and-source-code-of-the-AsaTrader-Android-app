package k4;

import android.app.Dialog;
import android.view.View;
import com.agah.trader.controller.transactions.TransactionsPage;

/* JADX INFO: compiled from: R8$$SyntheticClass */
/* JADX INFO: loaded from: /home/kali/Desktop/bunt/agah/dex_files/classes2.dex */
public final /* synthetic */ class c implements View.OnClickListener {
    public final /* synthetic */ TransactionsPage o;
    public final /* synthetic */ Dialog p;

    public /* synthetic */ c(TransactionsPage transactionsPage, Dialog dialog) {
        this.o = transactionsPage;
        this.p = dialog;
    }

    @Override // android.view.View.OnClickListener
    public final void onClick(View view) {
        TransactionsPage.N0(this.o, this.p, view);
    }
}
