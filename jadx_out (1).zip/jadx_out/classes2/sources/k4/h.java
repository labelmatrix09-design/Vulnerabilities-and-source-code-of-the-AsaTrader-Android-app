package k4;

import com.agah.trader.controller.transactions.TransactionsPage;

/* JADX INFO: compiled from: R8$$SyntheticClass */
/* JADX INFO: loaded from: /home/kali/Desktop/bunt/agah/dex_files/classes2.dex */
public final /* synthetic */ class h implements Runnable {
    public final /* synthetic */ TransactionsPage o;

    @Override // java.lang.Runnable
    public final void run() {
        TransactionsPage.a.p(this.o);
    }
}
