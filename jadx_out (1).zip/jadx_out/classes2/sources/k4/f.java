package k4;

import android.widget.CompoundButton;
import com.agah.trader.controller.transactions.TransactionsPage;

/* JADX INFO: compiled from: R8$$SyntheticClass */
/* JADX INFO: loaded from: /home/kali/Desktop/bunt/agah/dex_files/classes2.dex */
public final /* synthetic */ class f implements CompoundButton.OnCheckedChangeListener {
    public final /* synthetic */ TransactionsPage a;

    @Override // android.widget.CompoundButton.OnCheckedChangeListener
    public final void onCheckedChanged(CompoundButton compoundButton, boolean z) {
        TransactionsPage.O0(this.a, compoundButton, z);
    }
}
