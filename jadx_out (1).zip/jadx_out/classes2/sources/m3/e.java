package m3;

import android.view.View;
import v4.c0;

/* JADX INFO: compiled from: R8$$SyntheticClass */
/* JADX INFO: loaded from: /home/kali/Desktop/bunt/agah/dex_files/classes2.dex */
public final /* synthetic */ class e implements View.OnClickListener {
    public final /* synthetic */ c0 o;
    public final /* synthetic */ f p;

    public /* synthetic */ e(c0 c0Var, f fVar) {
        this.o = c0Var;
        this.p = fVar;
    }

    @Override // android.view.View.OnClickListener
    public final void onClick(View view) {
        f.a.O(this.o, this.p, view);
    }
}
