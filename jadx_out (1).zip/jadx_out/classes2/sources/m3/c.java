package m3;

import android.view.View;
import jl.y;

/* JADX INFO: compiled from: R8$$SyntheticClass */
/* JADX INFO: loaded from: /home/kali/Desktop/bunt/agah/dex_files/classes2.dex */
public final /* synthetic */ class c implements View.OnClickListener {
    public final /* synthetic */ y o;
    public final /* synthetic */ f p;

    public /* synthetic */ c(y yVar, f fVar) {
        this.o = yVar;
        this.p = fVar;
    }

    @Override // android.view.View.OnClickListener
    public final void onClick(View view) {
        f.a.P(this.o, this.p, view);
    }
}
