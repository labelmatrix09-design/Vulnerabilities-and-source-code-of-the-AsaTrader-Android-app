package lf;

import com.google.firebase.datatransport.TransportRegistrar;
import kf.e;
import kf.h;

/* JADX INFO: compiled from: com.google.firebase:firebase-datatransport@@17.0.3 */
/* JADX INFO: loaded from: /home/kali/Desktop/bunt/agah/dex_files/classes2.dex */
public final /* synthetic */ class a implements h {
    public static final a a = new a();

    public static h b() {
        return a;
    }

    @Override // kf.h
    public Object a(e eVar) {
        return TransportRegistrar.lambda$getComponents$0(eVar);
    }
}
