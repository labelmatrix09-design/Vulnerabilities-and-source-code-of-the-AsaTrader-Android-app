package di;

import android.content.ComponentName;
import android.content.Context;
import java.util.List;

/* JADX INFO: compiled from: Badger.java */
/* JADX INFO: loaded from: /home/kali/Desktop/bunt/agah/dex_files/classes2.dex */
public interface a {
    List<String> a();

    void b(Context context, ComponentName componentName, int i);
}
