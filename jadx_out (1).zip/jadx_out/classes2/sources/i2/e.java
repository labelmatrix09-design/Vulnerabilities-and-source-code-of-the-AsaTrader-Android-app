package i2;

import android.app.Dialog;
import android.view.View;

/* JADX INFO: compiled from: R8$$SyntheticClass */
/* JADX INFO: loaded from: /home/kali/Desktop/bunt/agah/dex_files/classes2.dex */
public final /* synthetic */ class e implements View.OnClickListener {
    public final /* synthetic */ i.a o;
    public final /* synthetic */ int p;
    public final /* synthetic */ Dialog q;

    public /* synthetic */ e(i.a aVar, int i, Dialog dialog) {
        this.o = aVar;
        this.p = i;
        this.q = dialog;
    }

    @Override // android.view.View.OnClickListener
    public final void onClick(View view) {
        i.a(this.o, this.p, this.q, view);
    }
}
