package i2;

import java.io.File;
import java.io.FilenameFilter;

/* JADX INFO: compiled from: R8$$SyntheticClass */
/* JADX INFO: loaded from: /home/kali/Desktop/bunt/agah/dex_files/classes2.dex */
public final /* synthetic */ class p implements FilenameFilter {
    public final /* synthetic */ String a;
    public final /* synthetic */ String b;

    public /* synthetic */ p(String str, String str2) {
        this.a = str;
        this.b = str2;
    }

    @Override // java.io.FilenameFilter
    public final boolean accept(File file, String str) {
        return q.a(this.a, this.b, file, str);
    }
}
