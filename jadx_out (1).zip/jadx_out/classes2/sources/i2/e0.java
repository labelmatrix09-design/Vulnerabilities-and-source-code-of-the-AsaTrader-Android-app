package i2;

import android.widget.EditText;

/* JADX INFO: compiled from: R8$$SyntheticClass */
/* JADX INFO: loaded from: /home/kali/Desktop/bunt/agah/dex_files/classes2.dex */
public final /* synthetic */ class e0 implements Runnable {
    public final /* synthetic */ EditText o;

    @Override // java.lang.Runnable
    public final void run() {
        f0.a(this.o);
    }
}
