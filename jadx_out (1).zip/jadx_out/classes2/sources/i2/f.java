package i2;

import android.app.Dialog;
import android.view.View;

/* JADX INFO: compiled from: R8$$SyntheticClass */
/* JADX INFO: loaded from: /home/kali/Desktop/bunt/agah/dex_files/classes2.dex */
public final /* synthetic */ class f implements View.OnClickListener {
    public final /* synthetic */ Runnable o;
    public final /* synthetic */ Dialog p;

    public /* synthetic */ f(Runnable runnable, Dialog dialog) {
        this.o = runnable;
        this.p = dialog;
    }

    @Override // android.view.View.OnClickListener
    public final void onClick(View view) {
        i.e(this.o, this.p, view);
    }
}
