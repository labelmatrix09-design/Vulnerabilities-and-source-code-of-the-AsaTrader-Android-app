package i2;

import android.app.Dialog;
import android.view.View;

/* JADX INFO: compiled from: R8$$SyntheticClass */
/* JADX INFO: loaded from: /home/kali/Desktop/bunt/agah/dex_files/classes2.dex */
public final /* synthetic */ class c implements View.OnClickListener {
    public final /* synthetic */ Dialog o;

    @Override // android.view.View.OnClickListener
    public final void onClick(View view) {
        i.b(this.o, view);
    }
}
