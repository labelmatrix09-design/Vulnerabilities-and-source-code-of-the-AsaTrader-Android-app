package i2;

/* JADX INFO: compiled from: R8$$SyntheticClass */
/* JADX INFO: loaded from: /home/kali/Desktop/bunt/agah/dex_files/classes2.dex */
public final /* synthetic */ class s implements Runnable {
    public static final /* synthetic */ s o = new s();

    @Override // java.lang.Runnable
    public final void run() {
        t.a();
    }
}
