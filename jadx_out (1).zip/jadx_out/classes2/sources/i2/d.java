package i2;

import android.app.Dialog;
import android.content.Context;
import android.view.View;

/* JADX INFO: compiled from: R8$$SyntheticClass */
/* JADX INFO: loaded from: /home/kali/Desktop/bunt/agah/dex_files/classes2.dex */
public final /* synthetic */ class d implements View.OnClickListener {
    public final /* synthetic */ View o;
    public final /* synthetic */ Context p;
    public final /* synthetic */ String q;
    public final /* synthetic */ int r;
    public final /* synthetic */ i.b s;
    public final /* synthetic */ Dialog t;

    public /* synthetic */ d(View view, Context context, String str, int i, i.b bVar, Dialog dialog) {
        this.o = view;
        this.p = context;
        this.q = str;
        this.r = i;
        this.s = bVar;
        this.t = dialog;
    }

    @Override // android.view.View.OnClickListener
    public final void onClick(View view) {
        i.d(this.o, this.p, this.q, this.r, this.s, this.t, view);
    }
}
