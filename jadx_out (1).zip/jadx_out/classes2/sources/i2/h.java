package i2;

import android.content.Context;
import android.view.View;

/* JADX INFO: compiled from: R8$$SyntheticClass */
/* JADX INFO: loaded from: /home/kali/Desktop/bunt/agah/dex_files/classes2.dex */
public final /* synthetic */ class h implements Runnable {
    public final /* synthetic */ View o;
    public final /* synthetic */ Context p;

    public /* synthetic */ h(View view, Context context) {
        this.o = view;
        this.p = context;
    }

    @Override // java.lang.Runnable
    public final void run() {
        i.c(this.o, this.p);
    }
}
