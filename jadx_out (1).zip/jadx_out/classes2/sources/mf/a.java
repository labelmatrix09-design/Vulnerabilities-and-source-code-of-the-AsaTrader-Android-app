package mf;

/* JADX INFO: compiled from: ComponentLoader.java */
/* JADX INFO: loaded from: /home/kali/Desktop/bunt/agah/dex_files/classes2.dex */
public interface a {
}
