package bm;

import java.util.concurrent.atomic.AtomicIntegerFieldUpdater;
import java.util.concurrent.atomic.AtomicReferenceArray;
import java.util.concurrent.atomic.AtomicReferenceFieldUpdater;

/* JADX INFO: compiled from: WorkQueue.kt */
/* JADX INFO: loaded from: /home/kali/Desktop/bunt/agah/dex_files/classes2.dex */
public final class n {
    public static final /* synthetic */ AtomicReferenceFieldUpdater b = AtomicReferenceFieldUpdater.newUpdater(n.class, Object.class, "lastScheduledTask");
    public static final /* synthetic */ AtomicIntegerFieldUpdater c = AtomicIntegerFieldUpdater.newUpdater(n.class, "producerIndex");
    public static final /* synthetic */ AtomicIntegerFieldUpdater d = AtomicIntegerFieldUpdater.newUpdater(n.class, "consumerIndex");
    public static final /* synthetic */ AtomicIntegerFieldUpdater e = AtomicIntegerFieldUpdater.newUpdater(n.class, "blockingTasksInBuffer");
    public final AtomicReferenceArray<h> a = new AtomicReferenceArray<>(128);
    private volatile /* synthetic */ Object lastScheduledTask = null;
    private volatile /* synthetic */ int producerIndex = 0;
    private volatile /* synthetic */ int consumerIndex = 0;
    private volatile /* synthetic */ int blockingTasksInBuffer = 0;

    public static /* synthetic */ h b(n nVar, h hVar, boolean z, int i, Object obj) {
        if ((i & 2) != 0) {
            z = false;
        }
        return nVar.a(hVar, z);
    }

    public final h a(h hVar, boolean z) {
        if (z) {
            return c(hVar);
        }
        h hVar2 = (h) b.getAndSet(this, hVar);
        if (hVar2 == null) {
            return null;
        }
        return c(hVar2);
    }

    public final h c(h hVar) {
        if (hVar.p.b() == 1) {
            e.incrementAndGet(this);
        }
        if (e() == 127) {
            return hVar;
        }
        int i = this.producerIndex & 127;
        while (this.a.get(i) != null) {
            Thread.yield();
        }
        this.a.lazySet(i, hVar);
        c.incrementAndGet(this);
        return null;
    }

    public final void d(h hVar) {
        if (hVar != null) {
            if (hVar.p.b() == 1) {
                e.decrementAndGet(this);
            }
        }
    }

    public final int e() {
        return this.producerIndex - this.consumerIndex;
    }

    public final int f() {
        return this.lastScheduledTask != null ? e() + 1 : e();
    }

    public final void g(d dVar) {
        h hVar = (h) b.getAndSet(this, null);
        if (hVar != null) {
            dVar.a(hVar);
        }
        while (j(dVar)) {
        }
    }

    public final h h() {
        h hVar = (h) b.getAndSet(this, null);
        return hVar == null ? i() : hVar;
    }

    public final h i() {
        h andSet;
        while (true) {
            int i = this.consumerIndex;
            if (i - this.producerIndex == 0) {
                return null;
            }
            int i3 = i & 127;
            if (d.compareAndSet(this, i, i + 1) && (andSet = this.a.getAndSet(i3, null)) != null) {
                d(andSet);
                return andSet;
            }
        }
    }

    public final boolean j(d dVar) {
        h hVarI = i();
        if (hVarI == null) {
            return false;
        }
        dVar.a(hVarI);
        return true;
    }

    public final long k(n nVar) {
        int i = nVar.consumerIndex;
        int i3 = nVar.producerIndex;
        AtomicReferenceArray<h> atomicReferenceArray = nVar.a;
        while (true) {
            if (i == i3) {
                break;
            }
            int i5 = i & 127;
            if (nVar.blockingTasksInBuffer == 0) {
                break;
            }
            h hVar = atomicReferenceArray.get(i5);
            if (hVar != null) {
                if ((hVar.p.b() == 1) && atomicReferenceArray.compareAndSet(i5, hVar, null)) {
                    e.decrementAndGet(nVar);
                    b(this, hVar, false, 2, null);
                    return -1L;
                }
            }
            i++;
        }
        return m(nVar, true);
    }

    public final long l(n nVar) {
        h hVarI = nVar.i();
        if (hVarI == null) {
            return m(nVar, false);
        }
        b(this, hVarI, false, 2, null);
        return -1L;
    }

    public final long m(n nVar, boolean z) {
        h hVar;
        do {
            hVar = (h) nVar.lastScheduledTask;
            if (hVar == null) {
                return -2L;
            }
            if (z) {
                if (!(hVar.p.b() == 1)) {
                    return -2L;
                }
            }
            long jA = l.e.a() - hVar.o;
            long j = l.a;
            if (jA < j) {
                return j - jA;
            }
        } while (!al.i.a(b, nVar, hVar, (Object) null));
        b(this, hVar, false, 2, null);
        return -1L;
    }
}
