package bm;

import ul.k0;

/* JADX INFO: compiled from: Tasks.kt */
/* JADX INFO: loaded from: /home/kali/Desktop/bunt/agah/dex_files/classes2.dex */
public final class k extends h {
    public final Runnable q;

    public k(Runnable runnable, long j, i iVar) {
        super(j, iVar);
        this.q = runnable;
    }

    @Override // java.lang.Runnable
    public void run() {
        try {
            this.q.run();
        } finally {
            this.p.a();
        }
    }

    public String toString() {
        return "Task[" + k0.a(this.q) + '@' + k0.b(this.q) + ", " + this.o + ", " + this.p + ']';
    }
}
