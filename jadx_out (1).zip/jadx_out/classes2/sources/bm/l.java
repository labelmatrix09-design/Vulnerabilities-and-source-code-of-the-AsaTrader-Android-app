package bm;

import java.util.concurrent.TimeUnit;
import zl.a0;
import zl.c0;

/* JADX INFO: compiled from: Tasks.kt */
/* JADX INFO: loaded from: /home/kali/Desktop/bunt/agah/dex_files/classes2.dex */
public final class l {
    public static final long a = c0.e("kotlinx.coroutines.scheduler.resolution.ns", 100000, 0, 0, 12, null);
    public static final int b = c0.d("kotlinx.coroutines.scheduler.core.pool.size", pl.h.b(a0.a(), 2), 1, 0, 8, null);
    public static final int c = c0.d("kotlinx.coroutines.scheduler.max.pool.size", 2097150, 0, 2097150, 4, null);
    public static final long d = TimeUnit.SECONDS.toNanos(c0.e("kotlinx.coroutines.scheduler.keep.alive.sec", 60, 0, 0, 12, null));
    public static g e = e.a;
    public static final i f = new j(0);
    public static final i g = new j(1);
}
