package bm;

import java.io.Closeable;
import java.util.ArrayList;
import java.util.concurrent.Executor;
import java.util.concurrent.RejectedExecutionException;
import java.util.concurrent.atomic.AtomicIntegerFieldUpdater;
import java.util.concurrent.atomic.AtomicLongFieldUpdater;
import java.util.concurrent.locks.LockSupport;
import ul.k0;
import wk.p;
import zl.x;
import zl.z;

/* JADX INFO: compiled from: CoroutineScheduler.kt */
/* JADX INFO: loaded from: /home/kali/Desktop/bunt/agah/dex_files/classes2.dex */
public final class a implements Executor, Closeable {
    private volatile /* synthetic */ int _isTerminated;
    public volatile /* synthetic */ long controlState;
    public final int o;
    public final int p;
    private volatile /* synthetic */ long parkedWorkersStack;
    public final long q;
    public final String r;
    public final bm.d s;
    public final bm.d t;
    public final x<c> u;
    public static final C0006a v = new C0006a(null);
    public static final z z = new z("NOT_IN_STACK");
    public static final /* synthetic */ AtomicLongFieldUpdater w = AtomicLongFieldUpdater.newUpdater(a.class, "parkedWorkersStack");
    public static final /* synthetic */ AtomicLongFieldUpdater x = AtomicLongFieldUpdater.newUpdater(a.class, "controlState");
    public static final /* synthetic */ AtomicIntegerFieldUpdater y = AtomicIntegerFieldUpdater.newUpdater(a.class, "_isTerminated");

    /* JADX INFO: renamed from: bm.a$a, reason: collision with other inner class name */
    /* JADX INFO: compiled from: CoroutineScheduler.kt */
    public static final class C0006a {
        public C0006a() {
        }

        public /* synthetic */ C0006a(jl.g gVar) {
            this();
        }
    }

    /* JADX INFO: compiled from: CoroutineScheduler.kt */
    public /* synthetic */ class b {
        public static final /* synthetic */ int[] a;

        static {
            int[] iArr = new int[d.values().length];
            iArr[d.PARKING.ordinal()] = 1;
            iArr[d.BLOCKING.ordinal()] = 2;
            iArr[d.CPU_ACQUIRED.ordinal()] = 3;
            iArr[d.DORMANT.ordinal()] = 4;
            iArr[d.TERMINATED.ordinal()] = 5;
            a = iArr;
        }
    }

    /* JADX INFO: compiled from: CoroutineScheduler.kt */
    public enum d {
        CPU_ACQUIRED,
        BLOCKING,
        PARKING,
        DORMANT,
        TERMINATED
    }

    public a(int i, int i3, long j, String str) {
        this.o = i;
        this.p = i3;
        this.q = j;
        this.r = str;
        if (!(i >= 1)) {
            throw new IllegalArgumentException(("Core pool size " + i + " should be at least 1").toString());
        }
        if (!(i3 >= i)) {
            throw new IllegalArgumentException(("Max pool size " + i3 + " should be greater than or equals to core pool size " + i).toString());
        }
        if (!(i3 <= 2097150)) {
            throw new IllegalArgumentException(("Max pool size " + i3 + " should not exceed maximal supported number of threads 2097150").toString());
        }
        if (!(j > 0)) {
            throw new IllegalArgumentException(("Idle worker keep alive time " + j + " must be positive").toString());
        }
        this.s = new bm.d();
        this.t = new bm.d();
        this.parkedWorkersStack = 0L;
        this.u = new x<>(i + 1);
        this.controlState = ((long) i) << 42;
        this._isTerminated = 0;
    }

    public static /* synthetic */ boolean L(a aVar, long j, int i, Object obj) {
        if ((i & 1) != 0) {
            j = aVar.controlState;
        }
        return aVar.I(j);
    }

    public static /* synthetic */ void j(a aVar, Runnable runnable, i iVar, boolean z4, int i, Object obj) {
        if ((i & 2) != 0) {
            iVar = l.f;
        }
        if ((i & 4) != 0) {
            z4 = false;
        }
        aVar.h(runnable, iVar, z4);
    }

    public final void A(boolean z4) {
        long jAddAndGet = x.addAndGet(this, 2097152L);
        if (z4 || M() || I(jAddAndGet)) {
            return;
        }
        M();
    }

    public final void B() {
        if (M() || L(this, 0L, 1, null)) {
            return;
        }
        M();
    }

    public final h F(c cVar, h hVar, boolean z4) {
        if (cVar == null || cVar.p == d.TERMINATED) {
            return hVar;
        }
        if (hVar.p.b() == 0 && cVar.p == d.BLOCKING) {
            return hVar;
        }
        cVar.t = true;
        return cVar.o.a(hVar, z4);
    }

    public final boolean I(long j) {
        if (pl.h.b(((int) (2097151 & j)) - ((int) ((j & 4398044413952L) >> 21)), 0) < this.o) {
            int iB = b();
            if (iB == 1 && this.o > 1) {
                b();
            }
            if (iB > 0) {
                return true;
            }
        }
        return false;
    }

    public final boolean M() {
        c cVarO;
        do {
            cVarO = o();
            if (cVarO == null) {
                return false;
            }
        } while (!c.v.compareAndSet(cVarO, -1, 0));
        LockSupport.unpark(cVarO);
        return true;
    }

    public final boolean a(h hVar) {
        return hVar.p.b() == 1 ? this.t.a(hVar) : this.s.a(hVar);
    }

    public final int b() {
        synchronized (this.u) {
            if (isTerminated()) {
                return -1;
            }
            long j = this.controlState;
            int i = (int) (j & 2097151);
            int iB = pl.h.b(i - ((int) ((j & 4398044413952L) >> 21)), 0);
            if (iB >= this.o) {
                return 0;
            }
            if (i >= this.p) {
                return 0;
            }
            int i3 = ((int) (this.controlState & 2097151)) + 1;
            if (!(i3 > 0 && this.u.b(i3) == null)) {
                throw new IllegalArgumentException("Failed requirement.".toString());
            }
            c cVar = new c(this, i3);
            this.u.c(i3, cVar);
            if (!(i3 == ((int) (2097151 & x.incrementAndGet(this))))) {
                throw new IllegalArgumentException("Failed requirement.".toString());
            }
            cVar.start();
            return iB + 1;
        }
    }

    @Override // java.io.Closeable, java.lang.AutoCloseable
    public void close() throws InterruptedException {
        z(10000L);
    }

    @Override // java.util.concurrent.Executor
    public void execute(Runnable runnable) {
        j(this, runnable, null, false, 6, null);
    }

    public final h f(Runnable runnable, i iVar) {
        long jA = l.e.a();
        if (!(runnable instanceof h)) {
            return new k(runnable, jA, iVar);
        }
        h hVar = (h) runnable;
        hVar.o = jA;
        hVar.p = iVar;
        return hVar;
    }

    public final c g() {
        Thread threadCurrentThread = Thread.currentThread();
        c cVar = threadCurrentThread instanceof c ? (c) threadCurrentThread : null;
        if (cVar == null || !jl.l.a(a.this, this)) {
            return null;
        }
        return cVar;
    }

    public final void h(Runnable runnable, i iVar, boolean z4) {
        ul.c.a();
        h hVarF = f(runnable, iVar);
        c cVarG = g();
        h hVarF2 = F(cVarG, hVarF, z4);
        if (hVarF2 != null && !a(hVarF2)) {
            throw new RejectedExecutionException(this.r + " was terminated");
        }
        boolean z5 = z4 && cVarG != null;
        if (hVarF.p.b() != 0) {
            A(z5);
        } else {
            if (z5) {
                return;
            }
            B();
        }
    }

    /* JADX WARN: Type inference failed for: r0v0, types: [boolean, int] */
    public final boolean isTerminated() {
        return this._isTerminated;
    }

    public final int m(c cVar) {
        Object objH = cVar.h();
        while (objH != z) {
            if (objH == null) {
                return 0;
            }
            c cVar2 = (c) objH;
            int iG = cVar2.g();
            if (iG != 0) {
                return iG;
            }
            objH = cVar2.h();
        }
        return -1;
    }

    public final c o() {
        while (true) {
            long j = this.parkedWorkersStack;
            c cVarB = this.u.b((int) (2097151 & j));
            if (cVarB == null) {
                return null;
            }
            long j2 = (2097152 + j) & (-2097152);
            int iM = m(cVarB);
            if (iM >= 0 && w.compareAndSet(this, j, ((long) iM) | j2)) {
                cVarB.p(z);
                return cVarB;
            }
        }
    }

    public final boolean p(c cVar) {
        long j;
        int iG;
        if (cVar.h() != z) {
            return false;
        }
        do {
            j = this.parkedWorkersStack;
            iG = cVar.g();
            cVar.p(this.u.b((int) (2097151 & j)));
        } while (!w.compareAndSet(this, j, ((2097152 + j) & (-2097152)) | ((long) iG)));
        return true;
    }

    public String toString() {
        ArrayList arrayList = new ArrayList();
        int iA = this.u.a();
        int i = 0;
        int i3 = 0;
        int i5 = 0;
        int i6 = 0;
        int i7 = 0;
        for (int i8 = 1; i8 < iA; i8++) {
            c cVarB = this.u.b(i8);
            if (cVarB != null) {
                int iF = cVarB.o.f();
                int i9 = b.a[cVarB.p.ordinal()];
                if (i9 == 1) {
                    i5++;
                } else if (i9 == 2) {
                    i3++;
                    StringBuilder sb = new StringBuilder();
                    sb.append(iF);
                    sb.append('b');
                    arrayList.add(sb.toString());
                } else if (i9 == 3) {
                    i++;
                    StringBuilder sb2 = new StringBuilder();
                    sb2.append(iF);
                    sb2.append('c');
                    arrayList.add(sb2.toString());
                } else if (i9 == 4) {
                    i6++;
                    if (iF > 0) {
                        StringBuilder sb3 = new StringBuilder();
                        sb3.append(iF);
                        sb3.append('d');
                        arrayList.add(sb3.toString());
                    }
                } else if (i9 == 5) {
                    i7++;
                }
            }
        }
        long j = this.controlState;
        return this.r + '@' + k0.b(this) + "[Pool Size {core = " + this.o + ", max = " + this.p + "}, Worker States {CPU = " + i + ", blocking = " + i3 + ", parked = " + i5 + ", dormant = " + i6 + ", terminated = " + i7 + "}, running workers queues = " + arrayList + ", global CPU queue size = " + this.s.c() + ", global blocking queue size = " + this.t.c() + ", Control State {created workers= " + ((int) (2097151 & j)) + ", blocking tasks = " + ((int) ((4398044413952L & j) >> 21)) + ", CPUs acquired = " + (this.o - ((int) ((9223367638808264704L & j) >> 42))) + "}]";
    }

    public final void u(c cVar, int i, int i3) {
        while (true) {
            long j = this.parkedWorkersStack;
            int iM = (int) (2097151 & j);
            long j2 = (2097152 + j) & (-2097152);
            if (iM == i) {
                iM = i3 == 0 ? m(cVar) : i3;
            }
            if (iM >= 0 && w.compareAndSet(this, j, j2 | ((long) iM))) {
                return;
            }
        }
    }

    public final void x(h hVar) {
        try {
            hVar.run();
        } catch (Throwable th2) {
            try {
                Thread threadCurrentThread = Thread.currentThread();
                threadCurrentThread.getUncaughtExceptionHandler().uncaughtException(threadCurrentThread, th2);
            } finally {
                ul.c.a();
            }
        }
    }

    /* JADX WARN: Code duplicated, block: B:24:0x0055  */
    public final void z(long j) throws InterruptedException {
        int i;
        h hVarD;
        if (y.compareAndSet(this, 0, 1)) {
            c cVarG = g();
            synchronized (this.u) {
                i = (int) (this.controlState & 2097151);
            }
            if (1 <= i) {
                int i3 = 1;
                while (true) {
                    c cVarB = this.u.b(i3);
                    jl.l.c(cVarB);
                    c cVar = cVarB;
                    if (cVar != cVarG) {
                        while (cVar.isAlive()) {
                            LockSupport.unpark(cVar);
                            cVar.join(j);
                        }
                        cVar.o.g(this.t);
                    }
                    if (i3 == i) {
                        break;
                    } else {
                        i3++;
                    }
                }
            }
            this.t.b();
            this.s.b();
            while (true) {
                if (cVarG == null) {
                    hVarD = this.s.d();
                    if (hVarD == null && (hVarD = this.t.d()) == null) {
                        break;
                    }
                } else {
                    hVarD = cVarG.f(true);
                    if (hVarD == null) {
                        hVarD = this.s.d();
                        if (hVarD == null) {
                            continue;
                        }
                    } else {
                        continue;
                    }
                }
                x(hVarD);
            }
            if (cVarG != null) {
                cVarG.s(d.TERMINATED);
            }
            this.parkedWorkersStack = 0L;
            this.controlState = 0L;
        }
    }

    /* JADX INFO: compiled from: CoroutineScheduler.kt */
    public final class c extends Thread {
        public static final /* synthetic */ AtomicIntegerFieldUpdater v = AtomicIntegerFieldUpdater.newUpdater(c.class, "workerCtl");
        private volatile int indexInArray;
        private volatile Object nextParkedWorker;
        public final n o;
        public d p;
        public long q;
        public long r;
        public int s;
        public boolean t;
        public volatile /* synthetic */ int workerCtl;

        public c() {
            setDaemon(true);
            this.o = new n();
            this.p = d.DORMANT;
            this.workerCtl = 0;
            this.nextParkedWorker = a.z;
            this.s = nl.c.o.c();
        }

        public final void b(int i) {
            if (i == 0) {
                return;
            }
            a.x.addAndGet(a.this, -2097152L);
            if (this.p != d.TERMINATED) {
                this.p = d.DORMANT;
            }
        }

        public final void c(int i) {
            if (i != 0 && s(d.BLOCKING)) {
                a.this.B();
            }
        }

        public final void d(h hVar) {
            int iB = hVar.p.b();
            i(iB);
            c(iB);
            a.this.x(hVar);
            b(iB);
        }

        public final h e(boolean z) {
            h hVarM;
            h hVarM2;
            if (z) {
                boolean z4 = k(a.this.o * 2) == 0;
                if (z4 && (hVarM2 = m()) != null) {
                    return hVarM2;
                }
                h hVarH = this.o.h();
                if (hVarH != null) {
                    return hVarH;
                }
                if (!z4 && (hVarM = m()) != null) {
                    return hVarM;
                }
            } else {
                h hVarM3 = m();
                if (hVarM3 != null) {
                    return hVarM3;
                }
            }
            return t(false);
        }

        public final h f(boolean z) {
            h hVarD;
            if (q()) {
                return e(z);
            }
            if (!z || (hVarD = this.o.h()) == null) {
                hVarD = a.this.t.d();
            }
            return hVarD == null ? t(true) : hVarD;
        }

        public final int g() {
            return this.indexInArray;
        }

        public final Object h() {
            return this.nextParkedWorker;
        }

        public final void i(int i) {
            this.q = 0L;
            if (this.p == d.PARKING) {
                this.p = d.BLOCKING;
            }
        }

        public final boolean j() {
            return this.nextParkedWorker != a.z;
        }

        public final int k(int i) {
            int i3 = this.s;
            int i5 = i3 ^ (i3 << 13);
            int i6 = i5 ^ (i5 >> 17);
            int i7 = i6 ^ (i6 << 5);
            this.s = i7;
            int i8 = i - 1;
            return (i8 & i) == 0 ? i7 & i8 : (i7 & Integer.MAX_VALUE) % i;
        }

        public final void l() {
            if (this.q == 0) {
                this.q = System.nanoTime() + a.this.q;
            }
            LockSupport.parkNanos(a.this.q);
            if (System.nanoTime() - this.q >= 0) {
                this.q = 0L;
                u();
            }
        }

        public final h m() {
            if (k(2) == 0) {
                h hVarD = a.this.s.d();
                return hVarD != null ? hVarD : a.this.t.d();
            }
            h hVarD2 = a.this.t.d();
            return hVarD2 != null ? hVarD2 : a.this.s.d();
        }

        public final void n() {
            loop0: while (true) {
                boolean z = false;
                while (true) {
                    if (a.this.isTerminated() || this.p == d.TERMINATED) {
                        break loop0;
                    }
                    h hVarF = f(this.t);
                    if (hVarF != null) {
                        this.r = 0L;
                        d(hVarF);
                        break;
                    }
                    this.t = false;
                    if (this.r == 0) {
                        r();
                    } else {
                        if (z) {
                            s(d.PARKING);
                            Thread.interrupted();
                            LockSupport.parkNanos(this.r);
                            this.r = 0L;
                            break;
                        }
                        z = true;
                    }
                }
            }
            s(d.TERMINATED);
        }

        public final void o(int i) {
            StringBuilder sb = new StringBuilder();
            sb.append(a.this.r);
            sb.append("-worker-");
            sb.append(i == 0 ? "TERMINATED" : String.valueOf(i));
            setName(sb.toString());
            this.indexInArray = i;
        }

        public final void p(Object obj) {
            this.nextParkedWorker = obj;
        }

        public final boolean q() {
            boolean z;
            if (this.p != d.CPU_ACQUIRED) {
                a aVar = a.this;
                while (true) {
                    long j = aVar.controlState;
                    if (((int) ((9223367638808264704L & j) >> 42)) == 0) {
                        z = false;
                        break;
                    }
                    if (a.x.compareAndSet(aVar, j, j - 4398046511104L)) {
                        z = true;
                        break;
                    }
                }
                if (!z) {
                    return false;
                }
                this.p = d.CPU_ACQUIRED;
            }
            return true;
        }

        public final void r() {
            if (!j()) {
                a.this.p(this);
                return;
            }
            this.workerCtl = -1;
            while (j() && this.workerCtl == -1 && !a.this.isTerminated() && this.p != d.TERMINATED) {
                s(d.PARKING);
                Thread.interrupted();
                l();
            }
        }

        @Override // java.lang.Thread, java.lang.Runnable
        public void run() {
            n();
        }

        public final boolean s(d dVar) {
            d dVar2 = this.p;
            boolean z = dVar2 == d.CPU_ACQUIRED;
            if (z) {
                a.x.addAndGet(a.this, 4398046511104L);
            }
            if (dVar2 != dVar) {
                this.p = dVar;
            }
            return z;
        }

        public final h t(boolean z) {
            int i = (int) (a.this.controlState & 2097151);
            if (i < 2) {
                return null;
            }
            int iK = k(i);
            a aVar = a.this;
            long jMin = Long.MAX_VALUE;
            for (int i3 = 0; i3 < i; i3++) {
                iK++;
                if (iK > i) {
                    iK = 1;
                }
                c cVarB = aVar.u.b(iK);
                if (cVarB != null && cVarB != this) {
                    long jK = z ? this.o.k(cVarB.o) : this.o.l(cVarB.o);
                    if (jK == -1) {
                        return this.o.h();
                    }
                    if (jK > 0) {
                        jMin = Math.min(jMin, jK);
                    }
                }
            }
            if (jMin == Long.MAX_VALUE) {
                jMin = 0;
            }
            this.r = jMin;
            return null;
        }

        public final void u() {
            a aVar = a.this;
            synchronized (aVar.u) {
                if (aVar.isTerminated()) {
                    return;
                }
                if (((int) (aVar.controlState & 2097151)) <= aVar.o) {
                    return;
                }
                if (v.compareAndSet(this, -1, 1)) {
                    int i = this.indexInArray;
                    o(0);
                    aVar.u(this, i, 0);
                    int andDecrement = (int) (2097151 & a.x.getAndDecrement(aVar));
                    if (andDecrement != i) {
                        c cVarB = aVar.u.b(andDecrement);
                        jl.l.c(cVarB);
                        c cVar = cVarB;
                        aVar.u.c(i, cVar);
                        cVar.o(i);
                        aVar.u(cVar, andDecrement, i);
                    }
                    aVar.u.c(andDecrement, null);
                    p pVar = p.a;
                    this.p = d.TERMINATED;
                }
            }
        }

        public c(a aVar, int i) {
            this();
            o(i);
        }
    }
}
