package bm;

import zl.o;

/* JADX INFO: compiled from: Tasks.kt */
/* JADX INFO: loaded from: /home/kali/Desktop/bunt/agah/dex_files/classes2.dex */
public final class d extends o<h> {
    public d() {
        super(false);
    }
}
