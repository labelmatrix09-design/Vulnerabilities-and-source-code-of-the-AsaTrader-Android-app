package bm;

import java.util.concurrent.Executor;
import ul.c0;
import ul.d1;
import zl.a0;

/* JADX INFO: compiled from: Dispatcher.kt */
/* JADX INFO: loaded from: /home/kali/Desktop/bunt/agah/dex_files/classes2.dex */
public final class b extends d1 implements Executor {
    public static final b r = new b();
    public static final c0 s = m.q.I(zl.c0.d("kotlinx.coroutines.io.parallelism", pl.h.b(64, a0.a()), 0, 0, 12, null));

    @Override // java.io.Closeable, java.lang.AutoCloseable
    public void close() {
        throw new IllegalStateException("Cannot be invoked on Dispatchers.IO".toString());
    }

    @Override // java.util.concurrent.Executor
    public void execute(Runnable runnable) {
        h(al.h.o, runnable);
    }

    @Override // ul.c0
    public void h(al.g gVar, Runnable runnable) {
        s.h(gVar, runnable);
    }

    @Override // ul.c0
    public String toString() {
        return "Dispatchers.IO";
    }
}
