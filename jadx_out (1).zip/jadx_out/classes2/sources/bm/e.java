package bm;

/* JADX INFO: compiled from: Tasks.kt */
/* JADX INFO: loaded from: /home/kali/Desktop/bunt/agah/dex_files/classes2.dex */
public final class e extends g {
    public static final e a = new e();

    @Override // bm.g
    public long a() {
        return System.nanoTime();
    }
}
