package bm;

/* JADX INFO: compiled from: Tasks.kt */
/* JADX INFO: loaded from: /home/kali/Desktop/bunt/agah/dex_files/classes2.dex */
public final class j implements i {
    public final int a;

    public j(int i) {
        this.a = i;
    }

    @Override // bm.i
    public void a() {
    }

    @Override // bm.i
    public int b() {
        return this.a;
    }
}
