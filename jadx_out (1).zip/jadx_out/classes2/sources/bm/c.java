package bm;

/* JADX INFO: compiled from: Dispatcher.kt */
/* JADX INFO: loaded from: /home/kali/Desktop/bunt/agah/dex_files/classes2.dex */
public final class c extends f {
    public static final c w = new c();

    public c() {
        super(l.b, l.c, l.d, "DefaultDispatcher");
    }

    @Override // java.io.Closeable, java.lang.AutoCloseable
    public void close() {
        throw new UnsupportedOperationException("Dispatchers.Default cannot be closed");
    }

    @Override // ul.c0
    public String toString() {
        return "Dispatchers.Default";
    }
}
