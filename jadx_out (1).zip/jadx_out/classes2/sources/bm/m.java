package bm;

import ul.c0;

/* JADX INFO: compiled from: Dispatcher.kt */
/* JADX INFO: loaded from: /home/kali/Desktop/bunt/agah/dex_files/classes2.dex */
public final class m extends c0 {
    public static final m q = new m();

    @Override // ul.c0
    public void h(al.g gVar, Runnable runnable) {
        c.w.d0(runnable, l.g, false);
    }
}
