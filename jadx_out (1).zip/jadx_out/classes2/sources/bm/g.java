package bm;

/* JADX INFO: compiled from: Tasks.kt */
/* JADX INFO: loaded from: /home/kali/Desktop/bunt/agah/dex_files/classes2.dex */
public abstract class g {
    public abstract long a();
}
