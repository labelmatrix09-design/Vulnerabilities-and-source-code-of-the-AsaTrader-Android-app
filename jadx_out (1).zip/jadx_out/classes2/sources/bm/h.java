package bm;

/* JADX INFO: compiled from: Tasks.kt */
/* JADX INFO: loaded from: /home/kali/Desktop/bunt/agah/dex_files/classes2.dex */
public abstract class h implements Runnable {
    public long o;
    public i p;

    public h(long j, i iVar) {
        this.o = j;
        this.p = iVar;
    }

    public h() {
        this(0L, l.f);
    }
}
