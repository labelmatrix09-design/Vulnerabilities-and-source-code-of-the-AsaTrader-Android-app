package bm;

import ul.d1;

/* JADX INFO: compiled from: Dispatcher.kt */
/* JADX INFO: loaded from: /home/kali/Desktop/bunt/agah/dex_files/classes2.dex */
public class f extends d1 {
    public final int r;
    public final int s;
    public final long t;
    public final String u;
    public a v = b0();

    public f(int i, int i3, long j, String str) {
        this.r = i;
        this.s = i3;
        this.t = j;
        this.u = str;
    }

    public final a b0() {
        return new a(this.r, this.s, this.t, this.u);
    }

    public final void d0(Runnable runnable, i iVar, boolean z) {
        this.v.h(runnable, iVar, z);
    }

    @Override // ul.c0
    public void h(al.g gVar, Runnable runnable) {
        a.j(this.v, runnable, null, false, 6, null);
    }
}
