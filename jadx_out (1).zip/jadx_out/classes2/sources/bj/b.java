package bj;

import android.view.View;
import th.i;

/* JADX INFO: compiled from: ZoomOutDown.java */
/* JADX INFO: loaded from: /home/kali/Desktop/bunt/agah/dex_files/classes2.dex */
public class b extends fi.c {
    @Override // fi.c
    public void e(View view) {
        c().r(i.L(view, "alpha", 1.0f, this.f ? 1.0f : 0.0f), i.L(view, "scaleX", 1.0f, 0.475f, 0.1f), i.L(view, "scaleY", 1.0f, 0.475f, 0.1f), i.L(view, "translationY", 0.0f, -60.0f, (int) this.e));
    }
}
