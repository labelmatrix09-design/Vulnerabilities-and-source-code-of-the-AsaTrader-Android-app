package bj;

import android.view.View;
import th.i;

/* JADX INFO: compiled from: ZoomOut.java */
/* JADX INFO: loaded from: /home/kali/Desktop/bunt/agah/dex_files/classes2.dex */
public class a extends fi.c {
    @Override // fi.c
    public void e(View view) {
        c().r(i.L(view, "alpha", 1.0f, this.f ? 1.0f : 0.0f), i.L(view, "scaleX", 1.0f, 0.3f, 0.0f), i.L(view, "scaleY", 1.0f, 0.3f, 0.0f));
    }
}
