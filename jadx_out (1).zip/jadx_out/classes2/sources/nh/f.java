package nh;

import android.os.Handler;
import android.os.HandlerThread;

/* JADX INFO: compiled from: CameraThread.java */
/* JADX INFO: loaded from: /home/kali/Desktop/bunt/agah/dex_files/classes2.dex */
public class f {
    public static f e;
    public Handler a;
    public HandlerThread b;
    public int c = 0;
    public final Object d = new Object();

    public static f d() {
        if (e == null) {
            e = new f();
        }
        return e;
    }

    public final void a() {
        synchronized (this.d) {
            if (this.a == null) {
                if (this.c <= 0) {
                    throw new IllegalStateException("CameraThread is not open");
                }
                HandlerThread handlerThread = new HandlerThread("CameraThread");
                this.b = handlerThread;
                handlerThread.start();
                this.a = new Handler(this.b.getLooper());
            }
        }
    }

    public void b() {
        synchronized (this.d) {
            int i = this.c - 1;
            this.c = i;
            if (i == 0) {
                f();
            }
        }
    }

    public void c(Runnable runnable) {
        synchronized (this.d) {
            a();
            this.a.post(runnable);
        }
    }

    public void e(Runnable runnable) {
        synchronized (this.d) {
            this.c++;
            c(runnable);
        }
    }

    public final void f() {
        synchronized (this.d) {
            this.b.quit();
            this.b = null;
            this.a = null;
        }
    }
}
