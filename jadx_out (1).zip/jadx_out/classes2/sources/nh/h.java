package nh;

import android.graphics.Rect;
import java.util.List;

/* JADX INFO: compiled from: DisplayConfiguration.java */
/* JADX INFO: loaded from: /home/kali/Desktop/bunt/agah/dex_files/classes2.dex */
public class h {
    public mh.l a;
    public int b;
    public boolean c = false;
    public l d = new i();

    public h(int i, mh.l lVar) {
        this.b = i;
        this.a = lVar;
    }

    public mh.l a(List<mh.l> list, boolean z) {
        return this.d.b(list, b(z));
    }

    public mh.l b(boolean z) {
        mh.l lVar = this.a;
        if (lVar == null) {
            return null;
        }
        return z ? lVar.e() : lVar;
    }

    public int c() {
        return this.b;
    }

    public Rect d(mh.l lVar) {
        return this.d.d(lVar, this.a);
    }

    public void e(l lVar) {
        this.d = lVar;
    }
}
