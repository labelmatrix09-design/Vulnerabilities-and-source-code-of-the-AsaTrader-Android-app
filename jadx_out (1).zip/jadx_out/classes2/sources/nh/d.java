package nh;

/* JADX INFO: compiled from: CameraSettings.java */
/* JADX INFO: loaded from: /home/kali/Desktop/bunt/agah/dex_files/classes2.dex */
public class d {
    public int a = -1;
    public boolean b = false;
    public boolean c = false;
    public boolean d = false;
    public boolean e = true;
    public boolean f = false;
    public boolean g = false;
    public boolean h = false;
    public a i = a.AUTO;

    /* JADX INFO: compiled from: CameraSettings.java */
    public enum a {
        AUTO,
        CONTINUOUS,
        INFINITY,
        MACRO
    }

    public a a() {
        return this.i;
    }

    public int b() {
        return this.a;
    }

    public boolean c() {
        return this.e;
    }

    public boolean d() {
        return this.h;
    }

    public boolean e() {
        return this.c;
    }

    public boolean f() {
        return this.g;
    }

    public boolean g() {
        return this.d;
    }

    public boolean h() {
        return this.b;
    }

    public void i(int i) {
        this.a = i;
    }
}
