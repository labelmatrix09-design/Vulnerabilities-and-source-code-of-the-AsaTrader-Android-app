package nh;

import android.graphics.Rect;

/* JADX INFO: compiled from: FitCenterStrategy.java */
/* JADX INFO: loaded from: /home/kali/Desktop/bunt/agah/dex_files/classes2.dex */
public class i extends l {
    @Override // nh.l
    public float c(mh.l lVar, mh.l lVar2) {
        if (lVar.o <= 0 || lVar.p <= 0) {
            return 0.0f;
        }
        mh.l lVarG = lVar.g(lVar2);
        float fPow = (lVarG.o * 1.0f) / lVar.o;
        if (fPow > 1.0f) {
            fPow = (float) Math.pow(1.0f / fPow, 1.1d);
        }
        float f = ((lVar2.o * 1.0f) / lVarG.o) * ((lVar2.p * 1.0f) / lVarG.p);
        return fPow * (((1.0f / f) / f) / f);
    }

    @Override // nh.l
    public Rect d(mh.l lVar, mh.l lVar2) {
        mh.l lVarG = lVar.g(lVar2);
        StringBuilder sb = new StringBuilder();
        sb.append("Preview: ");
        sb.append(lVar);
        sb.append("; Scaled: ");
        sb.append(lVarG);
        sb.append("; Want: ");
        sb.append(lVar2);
        int i = (lVarG.o - lVar2.o) / 2;
        int i3 = (lVarG.p - lVar2.p) / 2;
        return new Rect(-i, -i3, lVarG.o - i, lVarG.p - i3);
    }
}
