package nh;

import android.content.Context;
import android.hardware.Camera;
import android.os.Build;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import mh.m;

/* JADX INFO: compiled from: CameraManager.java */
/* JADX INFO: loaded from: /home/kali/Desktop/bunt/agah/dex_files/classes2.dex */
public final class c {
    public static final String n = "c";
    public Camera a;
    public Camera.CameraInfo b;
    public nh.a c;
    public og.a d;
    public boolean e;
    public String f;
    public h h;
    public mh.l i;
    public mh.l j;
    public Context l;
    public d g = new d();
    public int k = -1;
    public final a m = new a();

    /* JADX INFO: compiled from: CameraManager.java */
    public final class a implements Camera.PreviewCallback {
        public k a;
        public mh.l b;

        public a() {
        }

        public void a(k kVar) {
            this.a = kVar;
        }

        public void b(mh.l lVar) {
            this.b = lVar;
        }

        @Override // android.hardware.Camera.PreviewCallback
        public void onPreviewFrame(byte[] bArr, Camera camera) {
            mh.l lVar = this.b;
            k kVar = this.a;
            if (lVar == null || kVar == null) {
                String unused = c.n;
                if (kVar != null) {
                    kVar.b(new Exception("No resolution available"));
                    return;
                }
                return;
            }
            try {
                if (bArr == null) {
                    throw new NullPointerException("No preview data received");
                }
                kVar.a(new m(bArr, lVar.o, lVar.p, camera.getParameters().getPreviewFormat(), c.this.e()));
            } catch (RuntimeException e) {
                String unused2 = c.n;
                kVar.b(e);
            }
        }
    }

    public c(Context context) {
        this.l = context;
    }

    public static List<mh.l> h(Camera.Parameters parameters) {
        List<Camera.Size> supportedPreviewSizes = parameters.getSupportedPreviewSizes();
        ArrayList arrayList = new ArrayList();
        if (supportedPreviewSizes == null) {
            Camera.Size previewSize = parameters.getPreviewSize();
            if (previewSize != null) {
                arrayList.add(new mh.l(previewSize.width, previewSize.height));
            }
            return arrayList;
        }
        for (Camera.Size size : supportedPreviewSizes) {
            arrayList.add(new mh.l(size.width, size.height));
        }
        return arrayList;
    }

    public final int b() {
        int iC = this.h.c();
        int i = 0;
        if (iC != 0) {
            if (iC == 1) {
                i = 90;
            } else if (iC == 2) {
                i = 180;
            } else if (iC == 3) {
                i = 270;
            }
        }
        Camera.CameraInfo cameraInfo = this.b;
        int i3 = cameraInfo.facing == 1 ? (360 - ((cameraInfo.orientation + i) % 360)) % 360 : ((cameraInfo.orientation - i) + 360) % 360;
        StringBuilder sb = new StringBuilder();
        sb.append("Camera Display Orientation: ");
        sb.append(i3);
        return i3;
    }

    public void c() {
        Camera camera = this.a;
        if (camera != null) {
            camera.release();
            this.a = null;
        }
    }

    public void d() {
        if (this.a == null) {
            throw new RuntimeException("Camera not open");
        }
        q();
    }

    public int e() {
        return this.k;
    }

    public final Camera.Parameters f() {
        Camera.Parameters parameters = this.a.getParameters();
        String str = this.f;
        if (str == null) {
            this.f = parameters.flatten();
        } else {
            parameters.unflatten(str);
        }
        return parameters;
    }

    public mh.l g() {
        if (this.j == null) {
            return null;
        }
        return i() ? this.j.e() : this.j;
    }

    public boolean i() {
        int i = this.k;
        if (i != -1) {
            return i % 180 != 0;
        }
        throw new IllegalStateException("Rotation not calculated yet. Call configure() first.");
    }

    public boolean j() {
        String flashMode;
        Camera.Parameters parameters = this.a.getParameters();
        if (parameters == null || (flashMode = parameters.getFlashMode()) == null) {
            return false;
        }
        return "on".equals(flashMode) || "torch".equals(flashMode);
    }

    public void k() {
        Camera cameraB = qg.a.b(this.g.b());
        this.a = cameraB;
        if (cameraB == null) {
            throw new RuntimeException("Failed to open camera");
        }
        int iA = qg.a.a(this.g.b());
        Camera.CameraInfo cameraInfo = new Camera.CameraInfo();
        this.b = cameraInfo;
        Camera.getCameraInfo(iA, cameraInfo);
    }

    public void l(k kVar) {
        Camera camera = this.a;
        if (camera == null || !this.e) {
            return;
        }
        this.m.a(kVar);
        camera.setOneShotPreviewCallback(this.m);
    }

    public final void m(int i) {
        this.a.setDisplayOrientation(i);
    }

    public void n(d dVar) {
        this.g = dVar;
    }

    public final void o(boolean z) {
        Camera.Parameters parametersF = f();
        if (parametersF == null) {
            return;
        }
        StringBuilder sb = new StringBuilder();
        sb.append("Initial camera parameters: ");
        sb.append(parametersF.flatten());
        pg.a.g(parametersF, this.g.a(), z);
        if (!z) {
            pg.a.k(parametersF, false);
            if (this.g.h()) {
                pg.a.i(parametersF);
            }
            if (this.g.e()) {
                pg.a.c(parametersF);
            }
            if (this.g.g()) {
                pg.a.l(parametersF);
                pg.a.h(parametersF);
                pg.a.j(parametersF);
            }
        }
        List<mh.l> listH = h(parametersF);
        if (listH.size() == 0) {
            this.i = null;
        } else {
            mh.l lVarA = this.h.a(listH, i());
            this.i = lVarA;
            parametersF.setPreviewSize(lVarA.o, lVarA.p);
        }
        if (Build.DEVICE.equals("glass-1")) {
            pg.a.e(parametersF);
        }
        StringBuilder sb2 = new StringBuilder();
        sb2.append("Final camera parameters: ");
        sb2.append(parametersF.flatten());
        this.a.setParameters(parametersF);
    }

    public void p(h hVar) {
        this.h = hVar;
    }

    public final void q() {
        try {
            int iB = b();
            this.k = iB;
            m(iB);
        } catch (Exception unused) {
        }
        try {
            o(false);
        } catch (Exception unused2) {
            try {
                o(true);
            } catch (Exception unused3) {
            }
        }
        Camera.Size previewSize = this.a.getParameters().getPreviewSize();
        if (previewSize == null) {
            this.j = this.i;
        } else {
            this.j = new mh.l(previewSize.width, previewSize.height);
        }
        this.m.b(this.j);
    }

    public void r(e eVar) throws IOException {
        eVar.a(this.a);
    }

    public void s(boolean z) {
        if (this.a != null) {
            try {
                if (z != j()) {
                    nh.a aVar = this.c;
                    if (aVar != null) {
                        aVar.j();
                    }
                    Camera.Parameters parameters = this.a.getParameters();
                    pg.a.k(parameters, z);
                    if (this.g.f()) {
                        pg.a.d(parameters, z);
                    }
                    this.a.setParameters(parameters);
                    nh.a aVar2 = this.c;
                    if (aVar2 != null) {
                        aVar2.i();
                    }
                }
            } catch (RuntimeException unused) {
            }
        }
    }

    public void t() {
        Camera camera = this.a;
        if (camera == null || this.e) {
            return;
        }
        camera.startPreview();
        this.e = true;
        this.c = new nh.a(this.a, this.g);
        og.a aVar = new og.a(this.l, this, this.g);
        this.d = aVar;
        aVar.c();
    }

    public void u() {
        nh.a aVar = this.c;
        if (aVar != null) {
            aVar.j();
            this.c = null;
        }
        og.a aVar2 = this.d;
        if (aVar2 != null) {
            aVar2.d();
            this.d = null;
        }
        Camera camera = this.a;
        if (camera == null || !this.e) {
            return;
        }
        camera.stopPreview();
        this.m.a(null);
        this.e = false;
    }
}
