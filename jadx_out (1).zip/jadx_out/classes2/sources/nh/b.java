package nh;

import android.content.Context;
import android.os.Handler;
import mh.n;

/* JADX INFO: compiled from: CameraInstance.java */
/* JADX INFO: loaded from: /home/kali/Desktop/bunt/agah/dex_files/classes2.dex */
public class b {
    public static final String n = "b";
    public nh.f a;
    public nh.e b;
    public nh.c c;
    public Handler d;
    public h e;
    public Handler h;
    public boolean f = false;
    public boolean g = true;
    public nh.d i = new nh.d();
    public Runnable j = new c();
    public Runnable k = new d();
    public Runnable l = new e();
    public Runnable m = new f();

    /* JADX INFO: compiled from: CameraInstance.java */
    public class a implements Runnable {
        public final /* synthetic */ boolean o;

        public a(boolean z) {
            this.o = z;
        }

        @Override // java.lang.Runnable
        public void run() {
            b.this.c.s(this.o);
        }
    }

    /* JADX INFO: renamed from: nh.b$b, reason: collision with other inner class name */
    /* JADX INFO: compiled from: CameraInstance.java */
    public class RunnableC0070b implements Runnable {
        public final /* synthetic */ k o;

        /* JADX INFO: renamed from: nh.b$b$a */
        /* JADX INFO: compiled from: CameraInstance.java */
        public class a implements Runnable {
            public a() {
            }

            @Override // java.lang.Runnable
            public void run() {
                b.this.c.l(RunnableC0070b.this.o);
            }
        }

        public RunnableC0070b(k kVar) {
            this.o = kVar;
        }

        @Override // java.lang.Runnable
        public void run() {
            if (b.this.f) {
                b.this.a.c(new a());
            } else {
                String unused = b.n;
            }
        }
    }

    /* JADX INFO: compiled from: CameraInstance.java */
    public class c implements Runnable {
        public c() {
        }

        @Override // java.lang.Runnable
        public void run() {
            try {
                String unused = b.n;
                b.this.c.k();
            } catch (Exception e) {
                b.this.o(e);
                String unused2 = b.n;
            }
        }
    }

    /* JADX INFO: compiled from: CameraInstance.java */
    public class d implements Runnable {
        public d() {
        }

        @Override // java.lang.Runnable
        public void run() {
            try {
                String unused = b.n;
                b.this.c.d();
                if (b.this.d != null) {
                    b.this.d.obtainMessage(og.g.zxing_prewiew_size_ready, b.this.m()).sendToTarget();
                }
            } catch (Exception e) {
                b.this.o(e);
                String unused2 = b.n;
            }
        }
    }

    /* JADX INFO: compiled from: CameraInstance.java */
    public class e implements Runnable {
        public e() {
        }

        @Override // java.lang.Runnable
        public void run() {
            try {
                String unused = b.n;
                b.this.c.r(b.this.b);
                b.this.c.t();
            } catch (Exception e) {
                b.this.o(e);
                String unused2 = b.n;
            }
        }
    }

    /* JADX INFO: compiled from: CameraInstance.java */
    public class f implements Runnable {
        public f() {
        }

        @Override // java.lang.Runnable
        public void run() {
            try {
                String unused = b.n;
                b.this.c.u();
                b.this.c.c();
            } catch (Exception unused2) {
                String unused3 = b.n;
            }
            b.this.g = true;
            b.this.d.sendEmptyMessage(og.g.zxing_camera_closed);
            b.this.a.b();
        }
    }

    public b(Context context) {
        n.a();
        this.a = nh.f.d();
        nh.c cVar = new nh.c(context);
        this.c = cVar;
        cVar.n(this.i);
        this.h = new Handler();
    }

    public void j() {
        n.a();
        if (this.f) {
            this.a.c(this.m);
        } else {
            this.g = true;
        }
        this.f = false;
    }

    public void k() {
        n.a();
        x();
        this.a.c(this.k);
    }

    public h l() {
        return this.e;
    }

    public final mh.l m() {
        return this.c.g();
    }

    public boolean n() {
        return this.g;
    }

    public final void o(Exception exc) {
        Handler handler = this.d;
        if (handler != null) {
            handler.obtainMessage(og.g.zxing_camera_error, exc).sendToTarget();
        }
    }

    public void p() {
        n.a();
        this.f = true;
        this.g = false;
        this.a.e(this.j);
    }

    public void q(k kVar) {
        this.h.post(new RunnableC0070b(kVar));
    }

    public void r(nh.d dVar) {
        if (this.f) {
            return;
        }
        this.i = dVar;
        this.c.n(dVar);
    }

    public void s(h hVar) {
        this.e = hVar;
        this.c.p(hVar);
    }

    public void t(Handler handler) {
        this.d = handler;
    }

    public void u(nh.e eVar) {
        this.b = eVar;
    }

    public void v(boolean z) {
        n.a();
        if (this.f) {
            this.a.c(new a(z));
        }
    }

    public void w() {
        n.a();
        x();
        this.a.c(this.l);
    }

    public final void x() {
        if (!this.f) {
            throw new IllegalStateException("CameraInstance is not open");
        }
    }
}
