package nh;

import android.graphics.Rect;

/* JADX INFO: compiled from: CenterCropStrategy.java */
/* JADX INFO: loaded from: /home/kali/Desktop/bunt/agah/dex_files/classes2.dex */
public class g extends l {
    @Override // nh.l
    public float c(mh.l lVar, mh.l lVar2) {
        if (lVar.o <= 0 || lVar.p <= 0) {
            return 0.0f;
        }
        mh.l lVarF = lVar.f(lVar2);
        float fPow = (lVarF.o * 1.0f) / lVar.o;
        if (fPow > 1.0f) {
            fPow = (float) Math.pow(1.0f / fPow, 1.1d);
        }
        float f = ((lVarF.o * 1.0f) / lVar2.o) + ((lVarF.p * 1.0f) / lVar2.p);
        return fPow * ((1.0f / f) / f);
    }

    @Override // nh.l
    public Rect d(mh.l lVar, mh.l lVar2) {
        mh.l lVarF = lVar.f(lVar2);
        StringBuilder sb = new StringBuilder();
        sb.append("Preview: ");
        sb.append(lVar);
        sb.append("; Scaled: ");
        sb.append(lVarF);
        sb.append("; Want: ");
        sb.append(lVar2);
        int i = (lVarF.o - lVar2.o) / 2;
        int i3 = (lVarF.p - lVar2.p) / 2;
        return new Rect(-i, -i3, lVarF.o - i, lVarF.p - i3);
    }
}
