package nh;

import mh.m;

/* JADX INFO: compiled from: PreviewCallback.java */
/* JADX INFO: loaded from: /home/kali/Desktop/bunt/agah/dex_files/classes2.dex */
public interface k {
    void a(m mVar);

    void b(Exception exc);
}
