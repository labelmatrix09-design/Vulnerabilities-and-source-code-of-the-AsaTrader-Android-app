package nh;

import android.graphics.Rect;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

/* JADX INFO: compiled from: PreviewScalingStrategy.java */
/* JADX INFO: loaded from: /home/kali/Desktop/bunt/agah/dex_files/classes2.dex */
public abstract class l {

    /* JADX INFO: compiled from: PreviewScalingStrategy.java */
    public class a implements Comparator<mh.l> {
        public final /* synthetic */ mh.l o;

        public a(mh.l lVar) {
            this.o = lVar;
        }

        @Override // java.util.Comparator
        /* JADX INFO: renamed from: a, reason: merged with bridge method [inline-methods] */
        public int compare(mh.l lVar, mh.l lVar2) {
            return Float.compare(l.this.c(lVar2, this.o), l.this.c(lVar, this.o));
        }
    }

    public List<mh.l> a(List<mh.l> list, mh.l lVar) {
        if (lVar == null) {
            return list;
        }
        Collections.sort(list, new a(lVar));
        return list;
    }

    public mh.l b(List<mh.l> list, mh.l lVar) {
        List<mh.l> listA = a(list, lVar);
        StringBuilder sb = new StringBuilder();
        sb.append("Viewfinder size: ");
        sb.append(lVar);
        StringBuilder sb2 = new StringBuilder();
        sb2.append("Preview in order of preference: ");
        sb2.append(listA);
        return listA.get(0);
    }

    public abstract float c(mh.l lVar, mh.l lVar2);

    public abstract Rect d(mh.l lVar, mh.l lVar2);
}
