package nh;

import android.hardware.Camera;
import android.os.Handler;
import android.os.Message;
import java.util.ArrayList;
import java.util.Collection;

/* JADX INFO: compiled from: AutoFocusManager.java */
/* JADX INFO: loaded from: /home/kali/Desktop/bunt/agah/dex_files/classes2.dex */
public final class a {
    public static final Collection<String> i;
    public boolean a;
    public boolean b;
    public final boolean c;
    public final Camera d;
    public Handler e;
    public int f = 1;
    public final Handler.Callback g;
    public final Camera.AutoFocusCallback h;

    /* JADX INFO: renamed from: nh.a$a, reason: collision with other inner class name */
    /* JADX INFO: compiled from: AutoFocusManager.java */
    public class C0068a implements Handler.Callback {
        public C0068a() {
        }

        @Override // android.os.Handler.Callback
        public boolean handleMessage(Message message) {
            if (message.what != a.this.f) {
                return false;
            }
            a.this.h();
            return true;
        }
    }

    /* JADX INFO: compiled from: AutoFocusManager.java */
    public class b implements Camera.AutoFocusCallback {

        /* JADX INFO: renamed from: nh.a$b$a, reason: collision with other inner class name */
        /* JADX INFO: compiled from: AutoFocusManager.java */
        public class RunnableC0069a implements Runnable {
            public RunnableC0069a() {
            }

            @Override // java.lang.Runnable
            public void run() {
                a.this.b = false;
                a.this.f();
            }
        }

        public b() {
        }

        @Override // android.hardware.Camera.AutoFocusCallback
        public void onAutoFocus(boolean z, Camera camera) {
            a.this.e.post(new RunnableC0069a());
        }
    }

    static {
        ArrayList arrayList = new ArrayList(2);
        i = arrayList;
        arrayList.add("auto");
        arrayList.add("macro");
    }

    public a(Camera camera, d dVar) {
        C0068a c0068a = new C0068a();
        this.g = c0068a;
        this.h = new b();
        this.e = new Handler(c0068a);
        this.d = camera;
        String focusMode = camera.getParameters().getFocusMode();
        boolean z = dVar.c() && i.contains(focusMode);
        this.c = z;
        StringBuilder sb = new StringBuilder();
        sb.append("Current focus mode '");
        sb.append(focusMode);
        sb.append("'; use auto focus? ");
        sb.append(z);
        i();
    }

    public final synchronized void f() {
        if (!this.a && !this.e.hasMessages(this.f)) {
            Handler handler = this.e;
            handler.sendMessageDelayed(handler.obtainMessage(this.f), 2000L);
        }
    }

    public final void g() {
        this.e.removeMessages(this.f);
    }

    public final void h() {
        if (!this.c || this.a || this.b) {
            return;
        }
        try {
            this.d.autoFocus(this.h);
            this.b = true;
        } catch (RuntimeException unused) {
            f();
        }
    }

    public void i() {
        this.a = false;
        h();
    }

    public void j() {
        this.a = true;
        this.b = false;
        g();
        if (this.c) {
            try {
                this.d.cancelAutoFocus();
            } catch (RuntimeException unused) {
            }
        }
    }
}
