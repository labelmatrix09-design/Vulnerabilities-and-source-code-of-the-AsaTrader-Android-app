package nh;

import android.graphics.Rect;

/* JADX INFO: compiled from: FitXYStrategy.java */
/* JADX INFO: loaded from: /home/kali/Desktop/bunt/agah/dex_files/classes2.dex */
public class j extends l {
    public static float e(float f) {
        return f < 1.0f ? 1.0f / f : f;
    }

    @Override // nh.l
    public float c(mh.l lVar, mh.l lVar2) {
        int i = lVar.o;
        if (i <= 0 || lVar.p <= 0) {
            return 0.0f;
        }
        float fE = (1.0f / e((i * 1.0f) / lVar2.o)) / e((lVar.p * 1.0f) / lVar2.p);
        float fE2 = e(((lVar.o * 1.0f) / lVar.p) / ((lVar2.o * 1.0f) / lVar2.p));
        return fE * (((1.0f / fE2) / fE2) / fE2);
    }

    @Override // nh.l
    public Rect d(mh.l lVar, mh.l lVar2) {
        return new Rect(0, 0, lVar2.o, lVar2.p);
    }
}
