package ge;

import android.graphics.Canvas;
import android.os.Build;

/* JADX INFO: compiled from: CanvasCompat.java */
/* JADX INFO: loaded from: /home/kali/Desktop/bunt/agah/dex_files/classes2.dex */
public class a {
    public static int a(Canvas canvas, float f, float f2, float f5, float f6, int i) {
        return Build.VERSION.SDK_INT > 21 ? canvas.saveLayerAlpha(f, f2, f5, f6, i) : canvas.saveLayerAlpha(f, f2, f5, f6, i, 31);
    }
}
