package xi;

import android.view.View;
import io.github.inflationx.calligraphy3.BuildConfig;
import th.i;

/* JADX INFO: compiled from: SlideInDown.java */
/* JADX INFO: loaded from: /home/kali/Desktop/bunt/agah/dex_files/classes2.dex */
public class a extends fi.c {
    @Override // fi.c
    public void e(View view) {
        int i = (int) this.e;
        float f = this.a;
        float f2 = this.b;
        int i3 = !this.f ? 1 : 0;
        StringBuilder sb = new StringBuilder();
        sb.append(BuildConfig.FLAVOR);
        sb.append(i);
        sb.append(" ");
        sb.append(view.getHeight());
        sb.append(" ");
        sb.append(view.getTop());
        c().r(i.L(view, "alpha", i3, 1.0f), i.L(view, "translationY", -i, 0.0f), i.L(view, "pivotX", f, f), i.L(view, "pivotY", f2, f2));
    }
}
