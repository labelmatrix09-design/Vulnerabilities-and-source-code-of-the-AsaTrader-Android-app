package xi;

import android.view.View;
import th.i;

/* JADX INFO: compiled from: SlideOutLeft.java */
/* JADX INFO: loaded from: /home/kali/Desktop/bunt/agah/dex_files/classes2.dex */
public class f extends fi.c {
    @Override // fi.c
    public void e(View view) {
        float f = this.a;
        float f2 = this.b;
        c().r(i.L(view, "alpha", 1.0f, !this.f ? 1 : 0), i.L(view, "translationX", 0.0f, -((int) this.e)), i.L(view, "pivotX", f, f), i.L(view, "pivotY", f2, f2));
    }
}
