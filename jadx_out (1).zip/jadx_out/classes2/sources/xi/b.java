package xi;

import android.view.View;
import th.i;

/* JADX INFO: compiled from: SlideInLeft.java */
/* JADX INFO: loaded from: /home/kali/Desktop/bunt/agah/dex_files/classes2.dex */
public class b extends fi.c {
    @Override // fi.c
    public void e(View view) {
        int i = (int) this.e;
        float f = this.a;
        float f2 = this.b;
        c().r(i.L(view, "alpha", !this.f ? 1 : 0, 1.0f), i.L(view, "translationX", -i, 0.0f), i.L(view, "pivotX", f, f), i.L(view, "pivotY", f2, f2));
    }
}
