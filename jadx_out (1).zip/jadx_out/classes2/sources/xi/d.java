package xi;

import android.view.View;
import th.i;

/* JADX INFO: compiled from: SlideInUp.java */
/* JADX INFO: loaded from: /home/kali/Desktop/bunt/agah/dex_files/classes2.dex */
public class d extends fi.c {
    @Override // fi.c
    public void e(View view) {
        float f = this.a;
        float f2 = this.b;
        c().r(i.L(view, "alpha", !this.f ? 1 : 0, 1.0f), i.L(view, "translationY", (int) this.e, 0.0f), i.L(view, "pivotX", f, f), i.L(view, "pivotY", f2, f2));
    }
}
