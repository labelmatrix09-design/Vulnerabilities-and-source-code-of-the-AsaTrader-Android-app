package rc;

import java.util.Comparator;
import java.util.List;

/* JADX INFO: compiled from: R8$$SyntheticClass */
/* JADX INFO: loaded from: /home/kali/Desktop/bunt/agah/dex_files/classes2.dex */
public final /* synthetic */ class i implements Comparator {
    public static final /* synthetic */ i o = new i();

    @Override // java.util.Comparator
    public final int compare(Object obj, Object obj2) {
        return m.i.j((List) obj, (List) obj2);
    }
}
