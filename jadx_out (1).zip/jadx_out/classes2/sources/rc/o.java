package rc;

import android.os.Bundle;

/* JADX INFO: compiled from: R8$$SyntheticClass */
/* JADX INFO: loaded from: /home/kali/Desktop/bunt/agah/dex_files/classes2.dex */
public final /* synthetic */ class o implements com.google.android.exoplayer2.f.a {
    public static final /* synthetic */ o a = new o();

    public final com.google.android.exoplayer2.f a(Bundle bundle) {
        return m.e.b(bundle);
    }
}
