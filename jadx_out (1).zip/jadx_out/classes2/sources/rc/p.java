package rc;

import android.os.Handler;
import java.util.concurrent.Executor;

/* JADX INFO: compiled from: R8$$SyntheticClass */
/* JADX INFO: loaded from: /home/kali/Desktop/bunt/agah/dex_files/classes2.dex */
public final /* synthetic */ class p implements Executor {
    public final /* synthetic */ Handler o;

    @Override // java.util.concurrent.Executor
    public final void execute(Runnable runnable) {
        this.o.post(runnable);
    }
}
