package rc;

import java.util.Comparator;
import java.util.List;

/* JADX INFO: compiled from: R8$$SyntheticClass */
/* JADX INFO: loaded from: /home/kali/Desktop/bunt/agah/dex_files/classes2.dex */
public final /* synthetic */ class g implements Comparator {
    public static final /* synthetic */ g o = new g();

    @Override // java.util.Comparator
    public final int compare(Object obj, Object obj2) {
        return m.b.f((List) obj, (List) obj2);
    }
}
