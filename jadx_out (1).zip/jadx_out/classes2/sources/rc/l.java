package rc;

import java.util.List;
import xb.i0;

/* JADX INFO: compiled from: R8$$SyntheticClass */
/* JADX INFO: loaded from: /home/kali/Desktop/bunt/agah/dex_files/classes2.dex */
public final /* synthetic */ class l implements m.h.a {
    public final /* synthetic */ m a;
    public final /* synthetic */ m.d b;
    public final /* synthetic */ boolean c;

    public /* synthetic */ l(m mVar, m.d dVar, boolean z) {
        this.a = mVar;
        this.b = dVar;
        this.c = z;
    }

    public final List a(int i, i0 i0Var, int[] iArr) {
        return m.q(this.a, this.b, this.c, i, i0Var, iArr);
    }
}
