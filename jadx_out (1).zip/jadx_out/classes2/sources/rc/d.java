package rc;

import com.google.android.exoplayer2.m;

/* JADX INFO: compiled from: R8$$SyntheticClass */
/* JADX INFO: loaded from: /home/kali/Desktop/bunt/agah/dex_files/classes2.dex */
public final /* synthetic */ class d implements bf.p {
    public final /* synthetic */ m o;

    @Override // bf.p
    public final boolean apply(Object obj) {
        return m.n(this.o, (m) obj);
    }
}
