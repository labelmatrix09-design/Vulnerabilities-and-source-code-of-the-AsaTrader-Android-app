package rc;

import com.google.android.exoplayer2.m;
import java.util.Comparator;

/* JADX INFO: compiled from: R8$$SyntheticClass */
/* JADX INFO: loaded from: /home/kali/Desktop/bunt/agah/dex_files/classes2.dex */
public final /* synthetic */ class b implements Comparator {
    public static final /* synthetic */ b o = new b();

    @Override // java.util.Comparator
    public final int compare(Object obj, Object obj2) {
        return c.v((m) obj, (m) obj2);
    }
}
