package rc;

import java.util.List;
import xb.i0;

/* JADX INFO: compiled from: R8$$SyntheticClass */
/* JADX INFO: loaded from: /home/kali/Desktop/bunt/agah/dex_files/classes2.dex */
public final /* synthetic */ class j implements m.h.a {
    public final /* synthetic */ m.d a;
    public final /* synthetic */ String b;

    public /* synthetic */ j(m.d dVar, String str) {
        this.a = dVar;
        this.b = str;
    }

    public final List a(int i, i0 i0Var, int[] iArr) {
        return m.p(this.a, this.b, i, i0Var, iArr);
    }
}
