package rc;

import java.util.Comparator;

/* JADX INFO: compiled from: R8$$SyntheticClass */
/* JADX INFO: loaded from: /home/kali/Desktop/bunt/agah/dex_files/classes2.dex */
public final /* synthetic */ class q implements Comparator {
    public static final /* synthetic */ q o = new q();

    @Override // java.util.Comparator
    public final int compare(Object obj, Object obj2) {
        return m.i.f((m.i) obj, (m.i) obj2);
    }
}
