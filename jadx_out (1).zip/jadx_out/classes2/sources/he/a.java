package he;

import android.R;
import android.content.res.ColorStateList;
import android.graphics.RectF;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import android.widget.Checkable;
import android.widget.FrameLayout;
import androidx.cardview.widget.CardView;
import de.b;
import de.k;
import we.n;

/* JADX INFO: compiled from: MaterialCardView.java */
/* JADX INFO: loaded from: /home/kali/Desktop/bunt/agah/dex_files/classes2.dex */
public class a extends CardView implements Checkable, n {
    public static final int[] B = {R.attr.state_checkable};
    public static final int[] C = {R.attr.state_checked};
    public static final int[] D = {b.state_dragged};
    public static final int E = k.Widget_MaterialComponents_CardView;
    public InterfaceC0055a A;
    public boolean x;
    public boolean y;
    public boolean z;

    /* JADX INFO: renamed from: he.a$a, reason: collision with other inner class name */
    /* JADX INFO: compiled from: MaterialCardView.java */
    public interface InterfaceC0055a {
        void a(a aVar, boolean z);
    }

    private RectF getBoundsAsRectF() {
        new RectF();
        throw null;
    }

    public final void g() {
        if (Build.VERSION.SDK_INT > 26) {
            throw null;
        }
    }

    public ColorStateList getCardBackgroundColor() {
        throw null;
    }

    public ColorStateList getCardForegroundColor() {
        throw null;
    }

    public float getCardViewRadius() {
        return super.getRadius();
    }

    public Drawable getCheckedIcon() {
        throw null;
    }

    public int getCheckedIconMargin() {
        throw null;
    }

    public int getCheckedIconSize() {
        throw null;
    }

    public ColorStateList getCheckedIconTint() {
        throw null;
    }

    public int getContentPaddingBottom() {
        throw null;
    }

    public int getContentPaddingLeft() {
        throw null;
    }

    public int getContentPaddingRight() {
        throw null;
    }

    public int getContentPaddingTop() {
        throw null;
    }

    public float getProgress() {
        throw null;
    }

    public float getRadius() {
        throw null;
    }

    public ColorStateList getRippleColor() {
        throw null;
    }

    public we.k getShapeAppearanceModel() {
        throw null;
    }

    @Deprecated
    public int getStrokeColor() {
        throw null;
    }

    public ColorStateList getStrokeColorStateList() {
        throw null;
    }

    public int getStrokeWidth() {
        throw null;
    }

    public boolean h() {
        return false;
    }

    public boolean i() {
        return this.z;
    }

    @Override // android.widget.Checkable
    public boolean isChecked() {
        return this.y;
    }

    /* JADX WARN: Multi-variable type inference failed */
    public void onAttachedToWindow() {
        super/*android.widget.FrameLayout*/.onAttachedToWindow();
        throw null;
    }

    /* JADX WARN: Multi-variable type inference failed */
    public int[] onCreateDrawableState(int i) {
        int[] iArrOnCreateDrawableState = super/*android.widget.FrameLayout*/.onCreateDrawableState(i + 3);
        if (h()) {
            FrameLayout.mergeDrawableStates(iArrOnCreateDrawableState, B);
        }
        if (isChecked()) {
            FrameLayout.mergeDrawableStates(iArrOnCreateDrawableState, C);
        }
        if (i()) {
            FrameLayout.mergeDrawableStates(iArrOnCreateDrawableState, D);
        }
        return iArrOnCreateDrawableState;
    }

    /* JADX WARN: Multi-variable type inference failed */
    public void onInitializeAccessibilityEvent(AccessibilityEvent accessibilityEvent) {
        super/*android.widget.FrameLayout*/.onInitializeAccessibilityEvent(accessibilityEvent);
        accessibilityEvent.setClassName("androidx.cardview.widget.CardView");
        accessibilityEvent.setChecked(isChecked());
    }

    /* JADX WARN: Multi-variable type inference failed */
    public void onInitializeAccessibilityNodeInfo(AccessibilityNodeInfo accessibilityNodeInfo) {
        super/*android.widget.FrameLayout*/.onInitializeAccessibilityNodeInfo(accessibilityNodeInfo);
        accessibilityNodeInfo.setClassName("androidx.cardview.widget.CardView");
        accessibilityNodeInfo.setCheckable(h());
        accessibilityNodeInfo.setClickable(isClickable());
        accessibilityNodeInfo.setChecked(isChecked());
    }

    /* JADX WARN: Multi-variable type inference failed */
    public void onMeasure(int i, int i3) {
        super.onMeasure(i, i3);
        getMeasuredWidth();
        getMeasuredHeight();
        throw null;
    }

    public void setBackground(Drawable drawable) {
        setBackgroundDrawable(drawable);
    }

    public void setBackgroundDrawable(Drawable drawable) {
        if (this.x) {
            throw null;
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    public void setBackgroundInternal(Drawable drawable) {
        super/*android.widget.FrameLayout*/.setBackgroundDrawable(drawable);
    }

    public void setCardBackgroundColor(int i) {
        ColorStateList.valueOf(i);
        throw null;
    }

    public void setCardElevation(float f) {
        super.setCardElevation(f);
        throw null;
    }

    public void setCardForegroundColor(ColorStateList colorStateList) {
        throw null;
    }

    public void setCheckable(boolean z) {
        throw null;
    }

    @Override // android.widget.Checkable
    public void setChecked(boolean z) {
        if (this.y != z) {
            toggle();
        }
    }

    public void setCheckedIcon(Drawable drawable) {
        throw null;
    }

    public void setCheckedIconMargin(int i) {
        throw null;
    }

    /* JADX WARN: Multi-variable type inference failed */
    public void setCheckedIconMarginResource(int i) {
        if (i == -1) {
            return;
        }
        getResources().getDimensionPixelSize(i);
        throw null;
    }

    /* JADX WARN: Multi-variable type inference failed */
    public void setCheckedIconResource(int i) {
        d.a.b(getContext(), i);
        throw null;
    }

    public void setCheckedIconSize(int i) {
        throw null;
    }

    /* JADX WARN: Multi-variable type inference failed */
    public void setCheckedIconSizeResource(int i) {
        if (i == 0) {
            return;
        }
        getResources().getDimensionPixelSize(i);
        throw null;
    }

    public void setCheckedIconTint(ColorStateList colorStateList) {
        throw null;
    }

    /* JADX WARN: Multi-variable type inference failed */
    public void setClickable(boolean z) {
        super/*android.widget.FrameLayout*/.setClickable(z);
    }

    /* JADX WARN: Multi-variable type inference failed */
    public void setDragged(boolean z) {
        if (this.z != z) {
            this.z = z;
            refreshDrawableState();
            g();
            invalidate();
        }
    }

    public void setMaxCardElevation(float f) {
        super.setMaxCardElevation(f);
        throw null;
    }

    public void setOnCheckedChangeListener(InterfaceC0055a interfaceC0055a) {
        this.A = interfaceC0055a;
    }

    public void setPreventCornerOverlap(boolean z) {
        super.setPreventCornerOverlap(z);
        throw null;
    }

    public void setProgress(float f) {
        throw null;
    }

    public void setRadius(float f) {
        super.setRadius(f);
        throw null;
    }

    public void setRippleColor(ColorStateList colorStateList) {
        throw null;
    }

    /* JADX WARN: Multi-variable type inference failed */
    public void setRippleColorResource(int i) {
        d.a.a(getContext(), i);
        throw null;
    }

    /* JADX WARN: Multi-variable type inference failed */
    @Override // we.n
    public void setShapeAppearanceModel(we.k kVar) {
        if (Build.VERSION.SDK_INT >= 21) {
            setClipToOutline(kVar.u(getBoundsAsRectF()));
        }
        throw null;
    }

    public void setStrokeColor(int i) {
        ColorStateList.valueOf(i);
        throw null;
    }

    public void setStrokeWidth(int i) {
        throw null;
    }

    public void setUseCompatPadding(boolean z) {
        super.setUseCompatPadding(z);
        throw null;
    }

    /* JADX WARN: Multi-variable type inference failed */
    @Override // android.widget.Checkable
    public void toggle() {
        if (h() && isEnabled()) {
            this.y = !this.y;
            refreshDrawableState();
            g();
            InterfaceC0055a interfaceC0055a = this.A;
            if (interfaceC0055a != null) {
                interfaceC0055a.a(this, this.y);
            }
        }
    }

    public void setCardBackgroundColor(ColorStateList colorStateList) {
        throw null;
    }

    public void setStrokeColor(ColorStateList colorStateList) {
        throw null;
    }
}
