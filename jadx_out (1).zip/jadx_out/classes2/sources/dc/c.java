package dc;

import android.net.Uri;
import com.google.android.exoplayer2.source.hls.playlist.a;

/* JADX INFO: compiled from: R8$$SyntheticClass */
/* JADX INFO: loaded from: /home/kali/Desktop/bunt/agah/dex_files/classes2.dex */
public final /* synthetic */ class c implements Runnable {
    public final /* synthetic */ a.c o;
    public final /* synthetic */ Uri p;

    public /* synthetic */ c(a.c cVar, Uri uri) {
        this.o = cVar;
        this.p = uri;
    }

    @Override // java.lang.Runnable
    public final void run() {
        a.c.a(this.o, this.p);
    }
}
