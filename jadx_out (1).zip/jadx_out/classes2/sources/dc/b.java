package dc;

import cc.g;
import com.google.android.exoplayer2.source.hls.playlist.HlsPlaylistTracker;
import com.google.android.exoplayer2.source.hls.playlist.a;

/* JADX INFO: compiled from: R8$$SyntheticClass */
/* JADX INFO: loaded from: /home/kali/Desktop/bunt/agah/dex_files/classes2.dex */
public final /* synthetic */ class b implements HlsPlaylistTracker.a {
    public static final /* synthetic */ b a = new b();

    public final HlsPlaylistTracker a(g gVar, com.google.android.exoplayer2.upstream.c cVar, f fVar) {
        return new a(gVar, cVar, fVar);
    }
}
