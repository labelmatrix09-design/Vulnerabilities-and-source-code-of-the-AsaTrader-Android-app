package dj;

import android.R;
import ej.f;

/* JADX INFO: loaded from: /home/kali/Desktop/bunt/agah/dex_files/classes2.dex */
public final class b {
    public static final int FontFamilyFont_android_font = 0;
    public static final int FontFamilyFont_android_fontStyle = 2;
    public static final int FontFamilyFont_android_fontVariationSettings = 4;
    public static final int FontFamilyFont_android_fontWeight = 1;
    public static final int FontFamilyFont_android_ttcIndex = 3;
    public static final int FontFamilyFont_font = 5;
    public static final int FontFamilyFont_fontStyle = 6;
    public static final int FontFamilyFont_fontVariationSettings = 7;
    public static final int FontFamilyFont_fontWeight = 8;
    public static final int FontFamilyFont_ttcIndex = 9;
    public static final int FontFamily_fontProviderAuthority = 0;
    public static final int FontFamily_fontProviderCerts = 1;
    public static final int FontFamily_fontProviderFetchStrategy = 2;
    public static final int FontFamily_fontProviderFetchTimeout = 3;
    public static final int FontFamily_fontProviderPackage = 4;
    public static final int FontFamily_fontProviderQuery = 5;
    public static final int FontFamily_fontProviderSystemFontFamily = 6;
    public static final int RecyclerView_android_clipToPadding = 1;
    public static final int RecyclerView_android_descendantFocusability = 2;
    public static final int RecyclerView_android_orientation = 0;
    public static final int RecyclerView_fastScrollEnabled = 3;
    public static final int RecyclerView_fastScrollHorizontalThumbDrawable = 4;
    public static final int RecyclerView_fastScrollHorizontalTrackDrawable = 5;
    public static final int RecyclerView_fastScrollVerticalThumbDrawable = 6;
    public static final int RecyclerView_fastScrollVerticalTrackDrawable = 7;
    public static final int RecyclerView_layoutManager = 8;
    public static final int RecyclerView_reverseLayout = 9;
    public static final int RecyclerView_spanCount = 10;
    public static final int RecyclerView_stackFromEnd = 11;
    public static final int SlidingUpPanelLayout_umanoAnchorPoint = 0;
    public static final int SlidingUpPanelLayout_umanoClipPanel = 1;
    public static final int SlidingUpPanelLayout_umanoDragView = 2;
    public static final int SlidingUpPanelLayout_umanoFadeColor = 3;
    public static final int SlidingUpPanelLayout_umanoFlingVelocity = 4;
    public static final int SlidingUpPanelLayout_umanoInitialState = 5;
    public static final int SlidingUpPanelLayout_umanoOverlay = 6;
    public static final int SlidingUpPanelLayout_umanoPanelHeight = 7;
    public static final int SlidingUpPanelLayout_umanoParallaxOffset = 8;
    public static final int SlidingUpPanelLayout_umanoScrollInterpolator = 9;
    public static final int SlidingUpPanelLayout_umanoScrollableView = 10;
    public static final int SlidingUpPanelLayout_umanoShadowHeight = 11;
    public static final int[] FontFamily = {f.fontProviderAuthority, f.fontProviderCerts, f.fontProviderFetchStrategy, f.fontProviderFetchTimeout, f.fontProviderPackage, f.fontProviderQuery, 2130969045};
    public static final int[] FontFamilyFont = {R.attr.font, R.attr.fontWeight, R.attr.fontStyle, R.attr.ttcIndex, R.attr.fontVariationSettings, f.font, f.fontStyle, f.fontVariationSettings, f.fontWeight, f.ttcIndex};
    public static final int[] RecyclerView = {R.attr.orientation, R.attr.clipToPadding, R.attr.descendantFocusability, 2130969005, 2130969006, 2130969007, 2130969008, 2130969009, 2130969151, 2130969418, 2130969490, 2130969496};
    public static final int[] SlidingUpPanelLayout = {2130969695, 2130969696, 2130969697, 2130969698, 2130969699, 2130969700, 2130969701, 2130969702, 2130969703, 2130969704, 2130969705, 2130969706};
}
