package dj;

/* JADX INFO: loaded from: /home/kali/Desktop/bunt/agah/dex_files/classes2.dex */
public final class a {
    public static final int above_shadow = 2131230805;
    public static final int below_shadow = 2131230811;
    public static final int notification_action_background = 2131231188;
    public static final int notification_bg = 2131231189;
    public static final int notification_bg_low = 2131231190;
    public static final int notification_bg_low_normal = 2131231191;
    public static final int notification_bg_low_pressed = 2131231192;
    public static final int notification_bg_normal = 2131231193;
    public static final int notification_bg_normal_pressed = 2131231194;
    public static final int notification_icon_background = 2131231195;
    public static final int notification_template_icon_bg = 2131231196;
    public static final int notification_template_icon_low_bg = 2131231197;
    public static final int notification_tile_bg = 2131231198;
    public static final int notify_panel_notification_icon_bg = 2131231199;
}
