package cg;

import java.math.BigInteger;

/* JADX INFO: compiled from: JsonPrimitive.java */
/* JADX INFO: loaded from: /home/kali/Desktop/bunt/agah/dex_files/classes2.dex */
public final class p extends l {
    public final Object a;

    public p(Boolean bool) {
        this.a = eg.a.b(bool);
    }

    public static boolean t(p pVar) {
        Object obj = pVar.a;
        if (!(obj instanceof Number)) {
            return false;
        }
        Number number = (Number) obj;
        return (number instanceof BigInteger) || (number instanceof Long) || (number instanceof Integer) || (number instanceof Short) || (number instanceof Byte);
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null || p.class != obj.getClass()) {
            return false;
        }
        p pVar = (p) obj;
        if (this.a == null) {
            return pVar.a == null;
        }
        if (t(this) && t(pVar)) {
            return q().longValue() == pVar.q().longValue();
        }
        Object obj2 = this.a;
        if (!(obj2 instanceof Number) || !(pVar.a instanceof Number)) {
            return obj2.equals(pVar.a);
        }
        double dDoubleValue = q().doubleValue();
        double dDoubleValue2 = pVar.q().doubleValue();
        if (dDoubleValue != dDoubleValue2) {
            return Double.isNaN(dDoubleValue) && Double.isNaN(dDoubleValue2);
        }
        return true;
    }

    public int hashCode() {
        long jDoubleToLongBits;
        if (this.a == null) {
            return 31;
        }
        if (t(this)) {
            jDoubleToLongBits = q().longValue();
        } else {
            Object obj = this.a;
            if (!(obj instanceof Number)) {
                return obj.hashCode();
            }
            jDoubleToLongBits = Double.doubleToLongBits(q().doubleValue());
        }
        return (int) ((jDoubleToLongBits >>> 32) ^ jDoubleToLongBits);
    }

    public boolean l() {
        return s() ? ((Boolean) this.a).booleanValue() : Boolean.parseBoolean(r());
    }

    public double n() {
        return u() ? q().doubleValue() : Double.parseDouble(r());
    }

    public int o() {
        return u() ? q().intValue() : Integer.parseInt(r());
    }

    public long p() {
        return u() ? q().longValue() : Long.parseLong(r());
    }

    public Number q() {
        Object obj = this.a;
        return obj instanceof String ? new eg.g((String) obj) : (Number) obj;
    }

    public String r() {
        if (u()) {
            return q().toString();
        }
        return s() ? ((Boolean) this.a).toString() : (String) this.a;
    }

    public boolean s() {
        return this.a instanceof Boolean;
    }

    public boolean u() {
        return this.a instanceof Number;
    }

    public boolean v() {
        return this.a instanceof String;
    }

    public p(Number number) {
        this.a = eg.a.b(number);
    }

    public p(String str) {
        this.a = eg.a.b(str);
    }
}
