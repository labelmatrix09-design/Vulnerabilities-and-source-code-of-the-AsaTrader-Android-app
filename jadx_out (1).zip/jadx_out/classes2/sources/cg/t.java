package cg;

import com.google.gson.JsonIOException;
import java.io.IOException;
import java.io.Reader;
import java.io.StringReader;
import java.io.StringWriter;
import java.io.Writer;

/* JADX INFO: compiled from: TypeAdapter.java */
/* JADX INFO: loaded from: /home/kali/Desktop/bunt/agah/dex_files/classes2.dex */
public abstract class t<T> {

    /* JADX INFO: compiled from: TypeAdapter.java */
    public class a extends t<T> {
        public a() {
        }

        @Override // cg.t
        public T d(jg.a aVar) throws IOException {
            if (aVar.Z() != jg.b.NULL) {
                return (T) t.this.d(aVar);
            }
            aVar.N();
            return null;
        }

        @Override // cg.t
        public void h(jg.c cVar, T t) throws IOException {
            if (t == null) {
                cVar.A();
            } else {
                t.this.h(cVar, t);
            }
        }
    }

    public final T a(Reader reader) {
        return d(new jg.a(reader));
    }

    public final T b(String str) {
        return a(new StringReader(str));
    }

    public final t<T> c() {
        return new a();
    }

    public abstract T d(jg.a aVar);

    public final String e(T t) {
        StringWriter stringWriter = new StringWriter();
        try {
            f(stringWriter, t);
            return stringWriter.toString();
        } catch (IOException e) {
            throw new AssertionError(e);
        }
    }

    public final void f(Writer writer, T t) {
        h(new jg.c(writer), t);
    }

    public final l g(T t) {
        try {
            fg.f fVar = new fg.f();
            h(fVar, t);
            return fVar.r0();
        } catch (IOException e) {
            throw new JsonIOException(e);
        }
    }

    public abstract void h(jg.c cVar, T t);
}
