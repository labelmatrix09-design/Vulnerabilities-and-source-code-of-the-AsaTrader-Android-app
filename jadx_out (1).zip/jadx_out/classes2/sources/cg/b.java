package cg;

/* JADX INFO: compiled from: ExclusionStrategy.java */
/* JADX INFO: loaded from: /home/kali/Desktop/bunt/agah/dex_files/classes2.dex */
public interface b {
    boolean a(Class<?> cls);

    boolean b(c cVar);
}
