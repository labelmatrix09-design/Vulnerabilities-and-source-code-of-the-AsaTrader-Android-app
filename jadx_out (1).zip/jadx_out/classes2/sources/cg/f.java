package cg;

import com.google.gson.JsonIOException;
import com.google.gson.JsonSyntaxException;
import com.google.gson.stream.MalformedJsonException;
import java.io.EOFException;
import java.io.IOException;
import java.io.Reader;
import java.io.StringReader;
import java.io.StringWriter;
import java.io.Writer;
import java.lang.reflect.Type;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicLong;
import java.util.concurrent.atomic.AtomicLongArray;

/* JADX INFO: compiled from: Gson.java */
/* JADX INFO: loaded from: /home/kali/Desktop/bunt/agah/dex_files/classes2.dex */
public final class f {
    public static final ig.a<?> v = ig.a.a(Object.class);
    public final ThreadLocal<Map<ig.a<?>, C0008f<?>>> a;
    public final Map<ig.a<?>, t<?>> b;
    public final eg.c c;
    public final fg.d d;
    public final List<u> e;
    public final eg.d f;
    public final cg.e g;
    public final Map<Type, h<?>> h;
    public final boolean i;
    public final boolean j;
    public final boolean k;
    public final boolean l;
    public final boolean m;
    public final boolean n;
    public final boolean o;
    public final String p;
    public final int q;
    public final int r;
    public final s s;
    public final List<u> t;
    public final List<u> u;

    /* JADX INFO: compiled from: Gson.java */
    public class a extends t<Number> {
        public a() {
        }

        @Override // cg.t
        /* JADX INFO: renamed from: i, reason: merged with bridge method [inline-methods] */
        public Double d(jg.a aVar) throws IOException {
            if (aVar.Z() != jg.b.NULL) {
                return Double.valueOf(aVar.B());
            }
            aVar.N();
            return null;
        }

        @Override // cg.t
        /* JADX INFO: renamed from: j, reason: merged with bridge method [inline-methods] */
        public void h(jg.c cVar, Number number) throws IOException {
            if (number == null) {
                cVar.A();
            } else {
                f.d(number.doubleValue());
                cVar.d0(number);
            }
        }
    }

    /* JADX INFO: compiled from: Gson.java */
    public class b extends t<Number> {
        public b() {
        }

        @Override // cg.t
        /* JADX INFO: renamed from: i, reason: merged with bridge method [inline-methods] */
        public Float d(jg.a aVar) throws IOException {
            if (aVar.Z() != jg.b.NULL) {
                return Float.valueOf((float) aVar.B());
            }
            aVar.N();
            return null;
        }

        @Override // cg.t
        /* JADX INFO: renamed from: j, reason: merged with bridge method [inline-methods] */
        public void h(jg.c cVar, Number number) throws IOException {
            if (number == null) {
                cVar.A();
            } else {
                f.d(number.floatValue());
                cVar.d0(number);
            }
        }
    }

    /* JADX INFO: compiled from: Gson.java */
    public class c extends t<Number> {
        @Override // cg.t
        /* JADX INFO: renamed from: i, reason: merged with bridge method [inline-methods] */
        public Number d(jg.a aVar) throws IOException {
            if (aVar.Z() != jg.b.NULL) {
                return Long.valueOf(aVar.I());
            }
            aVar.N();
            return null;
        }

        @Override // cg.t
        /* JADX INFO: renamed from: j, reason: merged with bridge method [inline-methods] */
        public void h(jg.c cVar, Number number) throws IOException {
            if (number == null) {
                cVar.A();
            } else {
                cVar.i0(number.toString());
            }
        }
    }

    /* JADX INFO: compiled from: Gson.java */
    public class d extends t<AtomicLong> {
        public final /* synthetic */ t a;

        public d(t tVar) {
            this.a = tVar;
        }

        @Override // cg.t
        /* JADX INFO: renamed from: i, reason: merged with bridge method [inline-methods] */
        public AtomicLong d(jg.a aVar) {
            return new AtomicLong(((Number) this.a.d(aVar)).longValue());
        }

        @Override // cg.t
        /* JADX INFO: renamed from: j, reason: merged with bridge method [inline-methods] */
        public void h(jg.c cVar, AtomicLong atomicLong) {
            this.a.h(cVar, Long.valueOf(atomicLong.get()));
        }
    }

    /* JADX INFO: compiled from: Gson.java */
    public class e extends t<AtomicLongArray> {
        public final /* synthetic */ t a;

        public e(t tVar) {
            this.a = tVar;
        }

        @Override // cg.t
        /* JADX INFO: renamed from: i, reason: merged with bridge method [inline-methods] */
        public AtomicLongArray d(jg.a aVar) throws IOException {
            ArrayList arrayList = new ArrayList();
            aVar.a();
            while (aVar.p()) {
                arrayList.add(Long.valueOf(((Number) this.a.d(aVar)).longValue()));
            }
            aVar.j();
            int size = arrayList.size();
            AtomicLongArray atomicLongArray = new AtomicLongArray(size);
            for (int i = 0; i < size; i++) {
                atomicLongArray.set(i, ((Long) arrayList.get(i)).longValue());
            }
            return atomicLongArray;
        }

        @Override // cg.t
        /* JADX INFO: renamed from: j, reason: merged with bridge method [inline-methods] */
        public void h(jg.c cVar, AtomicLongArray atomicLongArray) throws IOException {
            cVar.f();
            int length = atomicLongArray.length();
            for (int i = 0; i < length; i++) {
                this.a.h(cVar, Long.valueOf(atomicLongArray.get(i)));
            }
            cVar.j();
        }
    }

    /* JADX INFO: renamed from: cg.f$f, reason: collision with other inner class name */
    /* JADX INFO: compiled from: Gson.java */
    public static class C0008f<T> extends t<T> {
        public t<T> a;

        @Override // cg.t
        public T d(jg.a aVar) {
            t<T> tVar = this.a;
            if (tVar != null) {
                return tVar.d(aVar);
            }
            throw new IllegalStateException();
        }

        @Override // cg.t
        public void h(jg.c cVar, T t) {
            t<T> tVar = this.a;
            if (tVar == null) {
                throw new IllegalStateException();
            }
            tVar.h(cVar, t);
        }

        public void i(t<T> tVar) {
            if (this.a != null) {
                throw new AssertionError();
            }
            this.a = tVar;
        }
    }

    public f() {
        this(eg.d.u, cg.d.o, Collections.emptyMap(), false, false, false, true, false, false, false, s.o, null, 2, 2, Collections.emptyList(), Collections.emptyList(), Collections.emptyList());
    }

    public static void a(Object obj, jg.a aVar) {
        if (obj != null) {
            try {
                if (aVar.Z() == jg.b.END_DOCUMENT) {
                } else {
                    throw new JsonIOException("JSON document was not fully consumed.");
                }
            } catch (MalformedJsonException e2) {
                throw new JsonSyntaxException(e2);
            } catch (IOException e5) {
                throw new JsonIOException(e5);
            }
        }
    }

    public static t<AtomicLong> b(t<Number> tVar) {
        return new d(tVar).c();
    }

    public static t<AtomicLongArray> c(t<Number> tVar) {
        return new e(tVar).c();
    }

    public static void d(double d2) {
        if (Double.isNaN(d2) || Double.isInfinite(d2)) {
            throw new IllegalArgumentException(d2 + " is not a valid double value as per JSON specification. To override this behavior, use GsonBuilder.serializeSpecialFloatingPointValues() method.");
        }
    }

    public static t<Number> p(s sVar) {
        return sVar == s.o ? fg.n.t : new c();
    }

    public l A(Object obj, Type type) {
        fg.f fVar = new fg.f();
        y(obj, type, fVar);
        return fVar.r0();
    }

    public final t<Number> e(boolean z) {
        return z ? fg.n.v : new a();
    }

    public final t<Number> f(boolean z) {
        return z ? fg.n.u : new b();
    }

    public <T> T g(l lVar, Class<T> cls) {
        return (T) eg.k.b(cls).cast(h(lVar, cls));
    }

    public <T> T h(l lVar, Type type) {
        if (lVar == null) {
            return null;
        }
        return (T) l(new fg.e(lVar), type);
    }

    public <T> T i(Reader reader, Type type) {
        jg.a aVarQ = q(reader);
        T t = (T) l(aVarQ, type);
        a(t, aVarQ);
        return t;
    }

    public <T> T j(String str, Class<T> cls) {
        return (T) eg.k.b(cls).cast(k(str, cls));
    }

    public <T> T k(String str, Type type) {
        if (str == null) {
            return null;
        }
        return (T) i(new StringReader(str), type);
    }

    public <T> T l(jg.a aVar, Type type) {
        boolean zU = aVar.u();
        boolean z = true;
        aVar.n0(true);
        try {
            try {
                try {
                    aVar.Z();
                    z = false;
                    T tD = m(ig.a.b(type)).d(aVar);
                    aVar.n0(zU);
                    return tD;
                } catch (AssertionError e2) {
                    AssertionError assertionError = new AssertionError("AssertionError (GSON 2.8.8): " + e2.getMessage());
                    assertionError.initCause(e2);
                    throw assertionError;
                } catch (IllegalStateException e5) {
                    throw new JsonSyntaxException(e5);
                }
            } catch (EOFException e6) {
                if (!z) {
                    throw new JsonSyntaxException(e6);
                }
                aVar.n0(zU);
                return null;
            } catch (IOException e7) {
                throw new JsonSyntaxException(e7);
            }
        } catch (Throwable th2) {
            aVar.n0(zU);
            throw th2;
        }
    }

    public <T> t<T> m(ig.a<T> aVar) {
        t<T> tVar = (t) this.b.get(aVar == null ? v : aVar);
        if (tVar != null) {
            return tVar;
        }
        Map<ig.a<?>, C0008f<?>> map = this.a.get();
        boolean z = false;
        if (map == null) {
            map = new HashMap<>();
            this.a.set(map);
            z = true;
        }
        C0008f<?> c0008f = map.get(aVar);
        if (c0008f != null) {
            return c0008f;
        }
        try {
            C0008f<?> c0008f2 = new C0008f<>();
            map.put(aVar, c0008f2);
            Iterator<u> it = this.e.iterator();
            while (it.hasNext()) {
                t<T> tVarA = it.next().a(this, aVar);
                if (tVarA != null) {
                    c0008f2.i(tVarA);
                    this.b.put(aVar, tVarA);
                    map.remove(aVar);
                    if (z) {
                        this.a.remove();
                    }
                    return tVarA;
                }
            }
            throw new IllegalArgumentException("GSON (2.8.8) cannot handle " + aVar);
        } catch (Throwable th2) {
            map.remove(aVar);
            if (z) {
                this.a.remove();
            }
            throw th2;
        }
    }

    public <T> t<T> n(Class<T> cls) {
        return m(ig.a.a(cls));
    }

    public <T> t<T> o(u uVar, ig.a<T> aVar) {
        if (!this.e.contains(uVar)) {
            uVar = this.d;
        }
        boolean z = false;
        for (u uVar2 : this.e) {
            if (z) {
                t<T> tVarA = uVar2.a(this, aVar);
                if (tVarA != null) {
                    return tVarA;
                }
            } else if (uVar2 == uVar) {
                z = true;
            }
        }
        throw new IllegalArgumentException("GSON cannot serialize " + aVar);
    }

    public jg.a q(Reader reader) {
        jg.a aVar = new jg.a(reader);
        aVar.n0(this.n);
        return aVar;
    }

    public jg.c r(Writer writer) throws IOException {
        if (this.k) {
            writer.write(")]}'\n");
        }
        jg.c cVar = new jg.c(writer);
        if (this.m) {
            cVar.N("  ");
        }
        cVar.V(this.i);
        return cVar;
    }

    public String s(l lVar) {
        StringWriter stringWriter = new StringWriter();
        v(lVar, stringWriter);
        return stringWriter.toString();
    }

    public String t(Object obj) {
        return obj == null ? s(m.a) : u(obj, obj.getClass());
    }

    public String toString() {
        return "{serializeNulls:" + this.i + ",factories:" + this.e + ",instanceCreators:" + this.c + "}";
    }

    public String u(Object obj, Type type) {
        StringWriter stringWriter = new StringWriter();
        x(obj, type, stringWriter);
        return stringWriter.toString();
    }

    public void v(l lVar, Appendable appendable) {
        try {
            w(lVar, r(eg.l.c(appendable)));
        } catch (IOException e2) {
            throw new JsonIOException(e2);
        }
    }

    public void w(l lVar, jg.c cVar) {
        boolean zU = cVar.u();
        cVar.Q(true);
        boolean zP = cVar.p();
        cVar.M(this.l);
        boolean zO = cVar.o();
        cVar.V(this.i);
        try {
            try {
                eg.l.b(lVar, cVar);
                cVar.Q(zU);
                cVar.M(zP);
                cVar.V(zO);
            } catch (IOException e2) {
                throw new JsonIOException(e2);
            } catch (AssertionError e5) {
                AssertionError assertionError = new AssertionError("AssertionError (GSON 2.8.8): " + e5.getMessage());
                assertionError.initCause(e5);
                throw assertionError;
            }
        } catch (Throwable th2) {
            cVar.Q(zU);
            cVar.M(zP);
            cVar.V(zO);
            throw th2;
        }
    }

    public void x(Object obj, Type type, Appendable appendable) {
        try {
            y(obj, type, r(eg.l.c(appendable)));
        } catch (IOException e2) {
            throw new JsonIOException(e2);
        }
    }

    public void y(Object obj, Type type, jg.c cVar) {
        t tVarM = m(ig.a.b(type));
        boolean zU = cVar.u();
        cVar.Q(true);
        boolean zP = cVar.p();
        cVar.M(this.l);
        boolean zO = cVar.o();
        cVar.V(this.i);
        try {
            try {
                tVarM.h(cVar, obj);
                cVar.Q(zU);
                cVar.M(zP);
                cVar.V(zO);
            } catch (IOException e2) {
                throw new JsonIOException(e2);
            } catch (AssertionError e5) {
                AssertionError assertionError = new AssertionError("AssertionError (GSON 2.8.8): " + e5.getMessage());
                assertionError.initCause(e5);
                throw assertionError;
            }
        } catch (Throwable th2) {
            cVar.Q(zU);
            cVar.M(zP);
            cVar.V(zO);
            throw th2;
        }
    }

    public l z(Object obj) {
        return obj == null ? m.a : A(obj, obj.getClass());
    }

    public f(eg.d dVar, cg.e eVar, Map<Type, h<?>> map, boolean z, boolean z4, boolean z5, boolean z6, boolean z7, boolean z8, boolean z9, s sVar, String str, int i, int i3, List<u> list, List<u> list2, List<u> list3) {
        this.a = new ThreadLocal<>();
        this.b = new ConcurrentHashMap();
        this.f = dVar;
        this.g = eVar;
        this.h = map;
        eg.c cVar = new eg.c(map);
        this.c = cVar;
        this.i = z;
        this.j = z4;
        this.k = z5;
        this.l = z6;
        this.m = z7;
        this.n = z8;
        this.o = z9;
        this.s = sVar;
        this.p = str;
        this.q = i;
        this.r = i3;
        this.t = list;
        this.u = list2;
        ArrayList arrayList = new ArrayList();
        arrayList.add(fg.n.Y);
        arrayList.add(fg.h.b);
        arrayList.add(dVar);
        arrayList.addAll(list3);
        arrayList.add(fg.n.D);
        arrayList.add(fg.n.m);
        arrayList.add(fg.n.g);
        arrayList.add(fg.n.i);
        arrayList.add(fg.n.k);
        t<Number> tVarP = p(sVar);
        arrayList.add(fg.n.b(Long.TYPE, Long.class, tVarP));
        arrayList.add(fg.n.b(Double.TYPE, Double.class, e(z9)));
        arrayList.add(fg.n.b(Float.TYPE, Float.class, f(z9)));
        arrayList.add(fg.n.x);
        arrayList.add(fg.n.o);
        arrayList.add(fg.n.q);
        arrayList.add(fg.n.a(AtomicLong.class, b(tVarP)));
        arrayList.add(fg.n.a(AtomicLongArray.class, c(tVarP)));
        arrayList.add(fg.n.s);
        arrayList.add(fg.n.z);
        arrayList.add(fg.n.F);
        arrayList.add(fg.n.H);
        arrayList.add(fg.n.a(BigDecimal.class, fg.n.B));
        arrayList.add(fg.n.a(BigInteger.class, fg.n.C));
        arrayList.add(fg.n.J);
        arrayList.add(fg.n.L);
        arrayList.add(fg.n.P);
        arrayList.add(fg.n.R);
        arrayList.add(fg.n.W);
        arrayList.add(fg.n.N);
        arrayList.add(fg.n.d);
        arrayList.add(fg.c.b);
        arrayList.add(fg.n.U);
        arrayList.add(fg.k.b);
        arrayList.add(fg.j.b);
        arrayList.add(fg.n.S);
        arrayList.add(fg.a.c);
        arrayList.add(fg.n.b);
        arrayList.add(new fg.b(cVar));
        arrayList.add(new fg.g(cVar, z4));
        fg.d dVar2 = new fg.d(cVar);
        this.d = dVar2;
        arrayList.add(dVar2);
        arrayList.add(fg.n.Z);
        arrayList.add(new fg.i(cVar, eVar, dVar, dVar2));
        this.e = Collections.unmodifiableList(arrayList);
    }
}
