package cg;

/* JADX INFO: compiled from: TypeAdapterFactory.java */
/* JADX INFO: loaded from: /home/kali/Desktop/bunt/agah/dex_files/classes2.dex */
public interface u {
    <T> t<T> a(f fVar, ig.a<T> aVar);
}
