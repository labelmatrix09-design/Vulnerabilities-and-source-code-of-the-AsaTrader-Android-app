package cg;

import java.lang.reflect.Type;

/* JADX INFO: compiled from: JsonSerializer.java */
/* JADX INFO: loaded from: /home/kali/Desktop/bunt/agah/dex_files/classes2.dex */
public interface r<T> {
    l a(T t, Type type, q qVar);
}
