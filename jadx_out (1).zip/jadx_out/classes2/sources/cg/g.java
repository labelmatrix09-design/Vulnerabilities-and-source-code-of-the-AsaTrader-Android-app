package cg;

import io.github.inflationx.calligraphy3.BuildConfig;
import java.lang.reflect.Type;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/* JADX INFO: compiled from: GsonBuilder.java */
/* JADX INFO: loaded from: /home/kali/Desktop/bunt/agah/dex_files/classes2.dex */
public final class g {
    public String h;
    public eg.d a = eg.d.u;
    public s b = s.o;
    public e c = d.o;
    public final Map<Type, h<?>> d = new HashMap();
    public final List<u> e = new ArrayList();
    public final List<u> f = new ArrayList();
    public boolean g = false;
    public int i = 2;
    public int j = 2;
    public boolean k = false;
    public boolean l = false;
    public boolean m = true;
    public boolean n = false;
    public boolean o = false;
    public boolean p = false;

    public final void a(String str, int i, int i3, List<u> list) {
        a aVar;
        a aVar2;
        a aVar3;
        if (str != null && !BuildConfig.FLAVOR.equals(str.trim())) {
            aVar = new a(Date.class, str);
            aVar2 = new a(Timestamp.class, str);
            aVar3 = new a(java.sql.Date.class, str);
        } else {
            if (i == 2 || i3 == 2) {
                return;
            }
            a aVar4 = new a(Date.class, i, i3);
            a aVar5 = new a(Timestamp.class, i, i3);
            a aVar6 = new a(java.sql.Date.class, i, i3);
            aVar = aVar4;
            aVar2 = aVar5;
            aVar3 = aVar6;
        }
        list.add(fg.n.a(Date.class, aVar));
        list.add(fg.n.a(Timestamp.class, aVar2));
        list.add(fg.n.a(java.sql.Date.class, aVar3));
    }

    public f b() {
        List<u> arrayList = new ArrayList<>(this.e.size() + this.f.size() + 3);
        arrayList.addAll(this.e);
        Collections.reverse(arrayList);
        ArrayList arrayList2 = new ArrayList(this.f);
        Collections.reverse(arrayList2);
        arrayList.addAll(arrayList2);
        a(this.h, this.i, this.j, arrayList);
        return new f(this.a, this.c, this.d, this.g, this.k, this.o, this.m, this.n, this.p, this.l, this.b, this.h, this.i, this.j, this.e, this.f, arrayList);
    }

    public g c(String str) {
        this.h = str;
        return this;
    }

    public g d(d dVar) {
        this.c = dVar;
        return this;
    }
}
