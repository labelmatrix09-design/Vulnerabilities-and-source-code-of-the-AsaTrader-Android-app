package cg;

import java.lang.reflect.Field;

/* JADX INFO: compiled from: FieldNamingStrategy.java */
/* JADX INFO: loaded from: /home/kali/Desktop/bunt/agah/dex_files/classes2.dex */
public interface e {
    String d(Field field);
}
