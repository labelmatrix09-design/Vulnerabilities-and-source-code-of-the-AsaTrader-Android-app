package cg;

import com.google.gson.JsonSyntaxException;
import java.io.IOException;
import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.ParsePosition;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;

/* JADX INFO: compiled from: DefaultDateTypeAdapter.java */
/* JADX INFO: loaded from: /home/kali/Desktop/bunt/agah/dex_files/classes2.dex */
public final class a extends t<Date> {
    public final Class<? extends Date> a;
    public final List<DateFormat> b;

    public a(Class<? extends Date> cls, String str) {
        ArrayList arrayList = new ArrayList();
        this.b = arrayList;
        this.a = k(cls);
        Locale locale = Locale.US;
        arrayList.add(new SimpleDateFormat(str, locale));
        if (Locale.getDefault().equals(locale)) {
            return;
        }
        arrayList.add(new SimpleDateFormat(str));
    }

    public static Class<? extends Date> k(Class<? extends Date> cls) {
        if (cls == Date.class || cls == java.sql.Date.class || cls == Timestamp.class) {
            return cls;
        }
        throw new IllegalArgumentException("Date type must be one of " + Date.class + ", " + Timestamp.class + ", or " + java.sql.Date.class + " but was " + cls);
    }

    public final Date i(String str) {
        synchronized (this.b) {
            Iterator<DateFormat> it = this.b.iterator();
            while (it.hasNext()) {
                try {
                    return it.next().parse(str);
                } catch (ParseException unused) {
                }
            }
            try {
                return gg.a.c(str, new ParsePosition(0));
            } catch (ParseException e) {
                throw new JsonSyntaxException(str, e);
            }
        }
    }

    @Override // cg.t
    /* JADX INFO: renamed from: j, reason: merged with bridge method [inline-methods] */
    public Date d(jg.a aVar) throws IOException {
        if (aVar.Z() == jg.b.NULL) {
            aVar.N();
            return null;
        }
        Date dateI = i(aVar.V());
        Class<? extends Date> cls = this.a;
        if (cls == Date.class) {
            return dateI;
        }
        if (cls == Timestamp.class) {
            return new Timestamp(dateI.getTime());
        }
        if (cls == java.sql.Date.class) {
            return new java.sql.Date(dateI.getTime());
        }
        throw new AssertionError();
    }

    @Override // cg.t
    /* JADX INFO: renamed from: l, reason: merged with bridge method [inline-methods] */
    public void h(jg.c cVar, Date date) throws IOException {
        if (date == null) {
            cVar.A();
            return;
        }
        synchronized (this.b) {
            cVar.i0(this.b.get(0).format(date));
        }
    }

    public String toString() {
        DateFormat dateFormat = this.b.get(0);
        if (dateFormat instanceof SimpleDateFormat) {
            return "DefaultDateTypeAdapter(" + ((SimpleDateFormat) dateFormat).toPattern() + ')';
        }
        return "DefaultDateTypeAdapter(" + dateFormat.getClass().getSimpleName() + ')';
    }

    public a(Class<? extends Date> cls, int i, int i3) {
        ArrayList arrayList = new ArrayList();
        this.b = arrayList;
        this.a = k(cls);
        Locale locale = Locale.US;
        arrayList.add(DateFormat.getDateTimeInstance(i, i3, locale));
        if (!Locale.getDefault().equals(locale)) {
            arrayList.add(DateFormat.getDateTimeInstance(i, i3));
        }
        if (eg.e.e()) {
            arrayList.add(eg.j.c(i, i3));
        }
    }
}
