package cg;

/* JADX INFO: compiled from: JsonNull.java */
/* JADX INFO: loaded from: /home/kali/Desktop/bunt/agah/dex_files/classes2.dex */
public final class m extends l {
    public static final m a = new m();

    @Deprecated
    public m() {
    }

    public boolean equals(Object obj) {
        return this == obj || (obj instanceof m);
    }

    public int hashCode() {
        return m.class.hashCode();
    }
}
