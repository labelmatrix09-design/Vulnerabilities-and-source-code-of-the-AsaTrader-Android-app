package cg;

import java.lang.reflect.Type;

/* JADX INFO: compiled from: JsonDeserializer.java */
/* JADX INFO: loaded from: /home/kali/Desktop/bunt/agah/dex_files/classes2.dex */
public interface k<T> {
    T a(l lVar, Type type, j jVar);
}
