package cg;

import java.lang.reflect.Type;

/* JADX INFO: compiled from: InstanceCreator.java */
/* JADX INFO: loaded from: /home/kali/Desktop/bunt/agah/dex_files/classes2.dex */
public interface h<T> {
    T a(Type type);
}
