package cg;

/* JADX WARN: Failed to restore enum class, 'enum' modifier and super class removed */
/* JADX WARN: Unknown enum class pattern. Please report as an issue! */
/* JADX INFO: compiled from: LongSerializationPolicy.java */
/* JADX INFO: loaded from: /home/kali/Desktop/bunt/agah/dex_files/classes2.dex */
public abstract class s {
    public static final s o;
    public static final s p;
    public static final /* synthetic */ s[] q;

    /* JADX INFO: compiled from: LongSerializationPolicy.java */
    public final enum a extends s {
        public a(String str, int i) {
            super(str, i, null);
        }
    }

    static {
        a aVar = new a("DEFAULT", 0);
        o = aVar;
        s sVar = new s("STRING", 1) { // from class: cg.s.b
            {
                a aVar2 = null;
            }
        };
        p = sVar;
        q = new s[]{aVar, sVar};
    }

    public s(String str, int i) {
        super(str, i);
    }

    public static s valueOf(String str) {
        return (s) Enum.valueOf(s.class, str);
    }

    public static s[] values() {
        return (s[]) q.clone();
    }

    public /* synthetic */ s(String str, int i, a aVar) {
        this(str, i);
    }
}
