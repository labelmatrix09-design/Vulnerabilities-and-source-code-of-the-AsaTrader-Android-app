package cg;

import com.google.gson.JsonParseException;

/* JADX INFO: compiled from: JsonParser.java */
/* JADX INFO: loaded from: /home/kali/Desktop/bunt/agah/dex_files/classes2.dex */
public final class o {
    @Deprecated
    public o() {
    }

    public static l b(jg.a aVar) {
        boolean zU = aVar.u();
        aVar.n0(true);
        try {
            try {
                l lVarA = eg.l.a(aVar);
                aVar.n0(zU);
                return lVarA;
            } catch (OutOfMemoryError e) {
                throw new JsonParseException("Failed parsing JSON source: " + aVar + " to Json", e);
            } catch (StackOverflowError e2) {
                throw new JsonParseException("Failed parsing JSON source: " + aVar + " to Json", e2);
            }
        } catch (Throwable th2) {
            aVar.n0(zU);
            throw th2;
        }
    }

    @Deprecated
    public l a(jg.a aVar) {
        return b(aVar);
    }
}
