package cg;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/* JADX INFO: compiled from: JsonArray.java */
/* JADX INFO: loaded from: /home/kali/Desktop/bunt/agah/dex_files/classes2.dex */
public final class i extends l implements Iterable<l> {
    public final List<l> o = new ArrayList();

    public boolean equals(Object obj) {
        return obj == this || ((obj instanceof i) && ((i) obj).o.equals(this.o));
    }

    public int hashCode() {
        return this.o.hashCode();
    }

    @Override // java.lang.Iterable
    public Iterator<l> iterator() {
        return this.o.iterator();
    }

    public void l(l lVar) {
        if (lVar == null) {
            lVar = m.a;
        }
        this.o.add(lVar);
    }

    public l n(int i) {
        return this.o.get(i);
    }

    public int size() {
        return this.o.size();
    }
}
