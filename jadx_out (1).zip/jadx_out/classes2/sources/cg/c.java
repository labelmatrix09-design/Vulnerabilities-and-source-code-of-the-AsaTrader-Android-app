package cg;

import java.lang.reflect.Field;

/* JADX INFO: compiled from: FieldAttributes.java */
/* JADX INFO: loaded from: /home/kali/Desktop/bunt/agah/dex_files/classes2.dex */
public final class c {
    public final Field a;

    public c(Field field) {
        eg.a.b(field);
        this.a = field;
    }
}
