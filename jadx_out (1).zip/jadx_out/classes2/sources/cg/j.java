package cg;

/* JADX INFO: compiled from: JsonDeserializationContext.java */
/* JADX INFO: loaded from: /home/kali/Desktop/bunt/agah/dex_files/classes2.dex */
public interface j {
}
