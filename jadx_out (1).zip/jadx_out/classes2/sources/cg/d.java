package cg;

import java.lang.reflect.Field;
import java.util.Locale;

/* JADX WARN: Failed to restore enum class, 'enum' modifier and super class removed */
/* JADX WARN: Unknown enum class pattern. Please report as an issue! */
/* JADX INFO: compiled from: FieldNamingPolicy.java */
/* JADX INFO: loaded from: /home/kali/Desktop/bunt/agah/dex_files/classes2.dex */
public abstract class d implements cg.e {
    public static final d o;
    public static final d p;
    public static final d q;
    public static final d r;
    public static final d s;
    public static final d t;
    public static final /* synthetic */ d[] u;

    /* JADX INFO: compiled from: FieldNamingPolicy.java */
    public final enum a extends d {
        public a(String str, int i) {
            super(str, i, null);
        }

        @Override // cg.e
        public String d(Field field) {
            return field.getName();
        }
    }

    static {
        a aVar = new a("IDENTITY", 0);
        o = aVar;
        d dVar = new d("UPPER_CAMEL_CASE", 1) { // from class: cg.d.b
            {
                a aVar2 = null;
            }

            @Override // cg.e
            public String d(Field field) {
                return d.f(field.getName());
            }
        };
        p = dVar;
        d dVar2 = new d("UPPER_CAMEL_CASE_WITH_SPACES", 2) { // from class: cg.d.c
            {
                a aVar2 = null;
            }

            @Override // cg.e
            public String d(Field field) {
                return d.f(d.e(field.getName(), " "));
            }
        };
        q = dVar2;
        d dVar3 = new d("LOWER_CASE_WITH_UNDERSCORES", 3) { // from class: cg.d.d
            {
                a aVar2 = null;
            }

            @Override // cg.e
            public String d(Field field) {
                return d.e(field.getName(), "_").toLowerCase(Locale.ENGLISH);
            }
        };
        r = dVar3;
        d dVar4 = new d("LOWER_CASE_WITH_DASHES", 4) { // from class: cg.d.e
            {
                a aVar2 = null;
            }

            @Override // cg.e
            public String d(Field field) {
                return d.e(field.getName(), "-").toLowerCase(Locale.ENGLISH);
            }
        };
        s = dVar4;
        d dVar5 = new d("LOWER_CASE_WITH_DOTS", 5) { // from class: cg.d.f
            {
                a aVar2 = null;
            }

            @Override // cg.e
            public String d(Field field) {
                return d.e(field.getName(), ".").toLowerCase(Locale.ENGLISH);
            }
        };
        t = dVar5;
        u = new d[]{aVar, dVar, dVar2, dVar3, dVar4, dVar5};
    }

    public d(String str, int i) {
        super(str, i);
    }

    public static String e(String str, String str2) {
        StringBuilder sb = new StringBuilder();
        int length = str.length();
        for (int i = 0; i < length; i++) {
            char cCharAt = str.charAt(i);
            if (Character.isUpperCase(cCharAt) && sb.length() != 0) {
                sb.append(str2);
            }
            sb.append(cCharAt);
        }
        return sb.toString();
    }

    public static String f(String str) {
        int length = str.length() - 1;
        int i = 0;
        while (!Character.isLetter(str.charAt(i)) && i < length) {
            i++;
        }
        char cCharAt = str.charAt(i);
        if (Character.isUpperCase(cCharAt)) {
            return str;
        }
        char upperCase = Character.toUpperCase(cCharAt);
        if (i == 0) {
            return upperCase + str.substring(1);
        }
        return str.substring(0, i) + upperCase + str.substring(i + 1);
    }

    public static d valueOf(String str) {
        return (d) Enum.valueOf(d.class, str);
    }

    public static d[] values() {
        return (d[]) u.clone();
    }

    public /* synthetic */ d(String str, int i, a aVar) {
        this(str, i);
    }
}
