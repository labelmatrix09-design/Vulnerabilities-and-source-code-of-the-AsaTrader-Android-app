package mm;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.PointF;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffXfermode;
import android.graphics.RectF;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.os.Parcelable;
import android.text.TextPaint;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.util.SparseArray;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.widget.FrameLayout;
import android.widget.RelativeLayout;
import io.github.inflationx.calligraphy3.BuildConfig;
import java.util.ArrayList;
import java.util.List;

/* JADX INFO: compiled from: QBadgeView.java */
/* JADX INFO: loaded from: /home/kali/Desktop/bunt/agah/dex_files/classes2.dex */
public class e extends View implements mm.a {
    public boolean A;
    public boolean B;
    public boolean C;
    public int D;
    public float E;
    public float F;
    public float G;
    public float H;
    public int I;
    public boolean J;
    public RectF K;
    public RectF L;
    public Path M;
    public Paint.FontMetrics N;
    public PointF O;
    public PointF P;
    public PointF Q;
    public PointF R;
    public List<PointF> S;
    public View T;
    public int U;
    public int V;
    public TextPaint W;
    public Paint a0;
    public Paint b0;
    public b c0;
    public mm.a.InterfaceC0065a d0;
    public ViewGroup e0;
    public int o;
    public int p;
    public int q;
    public Drawable r;
    public Bitmap s;
    public boolean t;
    public float u;
    public float v;
    public float w;
    public int x;
    public String y;
    public boolean z;

    /* JADX INFO: compiled from: QBadgeView.java */
    public class a extends ViewGroup {
        public a(Context context) {
            super(context);
        }

        @Override // android.view.ViewGroup, android.view.View
        public void dispatchRestoreInstanceState(SparseArray<Parcelable> sparseArray) {
            if (getParent() instanceof RelativeLayout) {
                return;
            }
            super.dispatchRestoreInstanceState(sparseArray);
        }

        @Override // android.view.ViewGroup, android.view.View
        public void onLayout(boolean z, int i, int i3, int i5, int i6) {
            for (int i7 = 0; i7 < getChildCount(); i7++) {
                View childAt = getChildAt(i7);
                childAt.layout(0, 0, childAt.getMeasuredWidth(), childAt.getMeasuredHeight());
            }
        }

        @Override // android.view.View
        public void onMeasure(int i, int i3) {
            View view = null;
            View view2 = null;
            for (int i5 = 0; i5 < getChildCount(); i5++) {
                View childAt = getChildAt(i5);
                if (childAt instanceof e) {
                    view2 = childAt;
                } else {
                    view = childAt;
                }
            }
            if (view == null) {
                super.onMeasure(i, i3);
                return;
            }
            view.measure(i, i3);
            if (view2 != null) {
                view2.measure(View.MeasureSpec.makeMeasureSpec(view.getMeasuredWidth(), 1073741824), View.MeasureSpec.makeMeasureSpec(view.getMeasuredHeight(), 1073741824));
            }
            setMeasuredDimension(view.getMeasuredWidth(), view.getMeasuredHeight());
        }
    }

    public e(Context context) {
        this(context, null);
    }

    private float getBadgeCircleRadius() {
        float fWidth;
        float f;
        if (this.y.isEmpty()) {
            return this.w;
        }
        if (this.y.length() != 1) {
            return this.L.height() / 2.0f;
        }
        if (this.K.height() > this.K.width()) {
            fWidth = this.K.height() / 2.0f;
            f = this.w;
        } else {
            fWidth = this.K.width() / 2.0f;
            f = this.w;
        }
        return fWidth + (f * 0.5f);
    }

    @Override // mm.a
    public mm.a a(View view) {
        if (view == null) {
            throw new IllegalStateException("targetView can not be null");
        }
        if (getParent() != null) {
            ((ViewGroup) getParent()).removeView(this);
        }
        ViewParent parent = view.getParent();
        if (parent == null || !(parent instanceof ViewGroup)) {
            throw new IllegalStateException("targetView must have a parent");
        }
        this.T = view;
        if (parent instanceof a) {
            ((a) parent).addView(this);
        } else {
            ViewGroup viewGroup = (ViewGroup) parent;
            int iIndexOfChild = viewGroup.indexOfChild(view);
            ViewGroup.LayoutParams layoutParams = view.getLayoutParams();
            viewGroup.removeView(view);
            a aVar = new a(getContext());
            if (viewGroup instanceof RelativeLayout) {
                aVar.setId(view.getId());
            }
            viewGroup.addView(aVar, iIndexOfChild, layoutParams);
            aVar.addView(view);
            aVar.addView(this);
        }
        return this;
    }

    @Override // mm.a
    public mm.a b(String str) {
        this.y = str;
        this.x = 1;
        p();
        invalidate();
        return this;
    }

    @Override // mm.a
    public mm.a c(float f, float f2, boolean z) {
        if (z) {
            f = c.a(getContext(), f);
        }
        this.E = f;
        if (z) {
            f2 = c.a(getContext(), f2);
        }
        this.F = f2;
        invalidate();
        return this;
    }

    public void d(PointF pointF) {
        if (this.y == null) {
            return;
        }
        b bVar = this.c0;
        if (bVar == null || !bVar.isRunning()) {
            s(true);
            b bVar2 = new b(e(), pointF, this);
            this.c0 = bVar2;
            bVar2.start();
            u(0);
        }
    }

    public Bitmap e() {
        Bitmap bitmapCreateBitmap = Bitmap.createBitmap(((int) this.L.width()) + c.a(getContext(), 3.0f), ((int) this.L.height()) + c.a(getContext(), 3.0f), Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(bitmapCreateBitmap);
        g(canvas, new PointF(canvas.getWidth() / 2.0f, canvas.getHeight() / 2.0f), getBadgeCircleRadius());
        return bitmapCreateBitmap;
    }

    public final void f() {
        if (this.y != null && this.t) {
            Bitmap bitmap = this.s;
            if (bitmap != null && !bitmap.isRecycled()) {
                this.s.recycle();
            }
            float badgeCircleRadius = getBadgeCircleRadius();
            if (this.y.isEmpty() || this.y.length() == 1) {
                int i = ((int) badgeCircleRadius) * 2;
                this.s = Bitmap.createBitmap(i, i, Bitmap.Config.ARGB_4444);
                Canvas canvas = new Canvas(this.s);
                canvas.drawCircle(canvas.getWidth() / 2.0f, canvas.getHeight() / 2.0f, canvas.getWidth() / 2.0f, this.a0);
                return;
            }
            this.s = Bitmap.createBitmap((int) (this.K.width() + (this.w * 2.0f)), (int) (this.K.height() + this.w), Bitmap.Config.ARGB_4444);
            Canvas canvas2 = new Canvas(this.s);
            if (Build.VERSION.SDK_INT >= 21) {
                canvas2.drawRoundRect(0.0f, 0.0f, canvas2.getWidth(), canvas2.getHeight(), canvas2.getHeight() / 2.0f, canvas2.getHeight() / 2.0f, this.a0);
            } else {
                canvas2.drawRoundRect(new RectF(0.0f, 0.0f, canvas2.getWidth(), canvas2.getHeight()), canvas2.getHeight() / 2.0f, canvas2.getHeight() / 2.0f, this.a0);
            }
        }
    }

    public final void g(Canvas canvas, PointF pointF, float f) {
        if (pointF.x == -1000.0f && pointF.y == -1000.0f) {
            return;
        }
        if (this.y.isEmpty() || this.y.length() == 1) {
            RectF rectF = this.L;
            float f2 = pointF.x;
            float f5 = (int) f;
            rectF.left = f2 - f5;
            float f6 = pointF.y;
            rectF.top = f6 - f5;
            rectF.right = f2 + f5;
            rectF.bottom = f5 + f6;
            if (this.r != null) {
                h(canvas);
            } else {
                canvas.drawCircle(f2, f6, f, this.a0);
                if (this.p != 0 && this.u > 0.0f) {
                    canvas.drawCircle(pointF.x, pointF.y, f, this.b0);
                }
            }
        } else {
            this.L.left = pointF.x - ((this.K.width() / 2.0f) + this.w);
            this.L.top = pointF.y - ((this.K.height() / 2.0f) + (this.w * 0.5f));
            this.L.right = pointF.x + (this.K.width() / 2.0f) + this.w;
            this.L.bottom = pointF.y + (this.K.height() / 2.0f) + (this.w * 0.5f);
            float fHeight = this.L.height() / 2.0f;
            if (this.r != null) {
                h(canvas);
            } else {
                canvas.drawRoundRect(this.L, fHeight, fHeight, this.a0);
                if (this.p != 0 && this.u > 0.0f) {
                    canvas.drawRoundRect(this.L, fHeight, fHeight, this.b0);
                }
            }
        }
        if (this.y.isEmpty()) {
            return;
        }
        String str = this.y;
        float f7 = pointF.x;
        RectF rectF2 = this.L;
        float f8 = rectF2.bottom + rectF2.top;
        Paint.FontMetrics fontMetrics = this.N;
        canvas.drawText(str, f7, ((f8 - fontMetrics.bottom) - fontMetrics.top) / 2.0f, this.W);
    }

    public Drawable getBadgeBackground() {
        return this.r;
    }

    public int getBadgeBackgroundColor() {
        return this.o;
    }

    public int getBadgeGravity() {
        return this.D;
    }

    public int getBadgeNumber() {
        return this.x;
    }

    public String getBadgeText() {
        return this.y;
    }

    public int getBadgeTextColor() {
        return this.q;
    }

    public PointF getDragCenter() {
        if (this.z && this.A) {
            return this.P;
        }
        return null;
    }

    public View getTargetView() {
        return this.T;
    }

    public final void h(Canvas canvas) {
        this.a0.setShadowLayer(0.0f, 0.0f, 0.0f, 0);
        RectF rectF = this.L;
        int i = (int) rectF.left;
        int i3 = (int) rectF.top;
        int width = (int) rectF.right;
        int height = (int) rectF.bottom;
        if (this.t) {
            width = i + this.s.getWidth();
            height = this.s.getHeight() + i3;
            canvas.saveLayer(i, i3, width, height, null, 31);
        }
        this.r.setBounds(i, i3, width, height);
        this.r.draw(canvas);
        if (!this.t) {
            canvas.drawRect(this.L, this.b0);
            return;
        }
        this.a0.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.DST_IN));
        canvas.drawBitmap(this.s, i, i3, this.a0);
        canvas.restore();
        this.a0.setXfermode(null);
        if (this.y.isEmpty() || this.y.length() == 1) {
            canvas.drawCircle(this.L.centerX(), this.L.centerY(), this.L.width() / 2.0f, this.b0);
        } else {
            RectF rectF2 = this.L;
            canvas.drawRoundRect(rectF2, rectF2.height() / 2.0f, this.L.height() / 2.0f, this.b0);
        }
    }

    public final void i(Canvas canvas, float f, float f2) {
        float f5;
        float f6;
        float f7;
        PointF pointF = this.P;
        float f8 = pointF.y;
        PointF pointF2 = this.Q;
        float f9 = f8 - pointF2.y;
        float f10 = pointF.x - pointF2.x;
        this.S.clear();
        if (f10 != 0.0f) {
            double d = f9 / f10;
            Double.isNaN(d);
            double d2 = (-1.0d) / d;
            d.a(this.P, f2, Double.valueOf(d2), this.S);
            d.a(this.Q, f, Double.valueOf(d2), this.S);
        } else {
            d.a(this.P, f2, Double.valueOf(0.0d), this.S);
            d.a(this.Q, f, Double.valueOf(0.0d), this.S);
        }
        this.M.reset();
        Path path = this.M;
        PointF pointF3 = this.Q;
        float f11 = pointF3.x;
        float f12 = pointF3.y;
        int i = this.I;
        path.addCircle(f11, f12, f, (i == 1 || i == 2) ? Path.Direction.CCW : Path.Direction.CW);
        PointF pointF4 = this.R;
        PointF pointF5 = this.Q;
        float f13 = pointF5.x;
        PointF pointF6 = this.P;
        pointF4.x = (f13 + pointF6.x) / 2.0f;
        pointF4.y = (pointF5.y + pointF6.y) / 2.0f;
        this.M.moveTo(this.S.get(2).x, this.S.get(2).y);
        Path path2 = this.M;
        PointF pointF7 = this.R;
        path2.quadTo(pointF7.x, pointF7.y, this.S.get(0).x, this.S.get(0).y);
        this.M.lineTo(this.S.get(1).x, this.S.get(1).y);
        Path path3 = this.M;
        PointF pointF8 = this.R;
        path3.quadTo(pointF8.x, pointF8.y, this.S.get(3).x, this.S.get(3).y);
        this.M.lineTo(this.S.get(2).x, this.S.get(2).y);
        this.M.close();
        canvas.drawPath(this.M, this.a0);
        if (this.p == 0 || this.u <= 0.0f) {
            return;
        }
        this.M.reset();
        this.M.moveTo(this.S.get(2).x, this.S.get(2).y);
        Path path4 = this.M;
        PointF pointF9 = this.R;
        path4.quadTo(pointF9.x, pointF9.y, this.S.get(0).x, this.S.get(0).y);
        this.M.moveTo(this.S.get(1).x, this.S.get(1).y);
        Path path5 = this.M;
        PointF pointF10 = this.R;
        path5.quadTo(pointF10.x, pointF10.y, this.S.get(3).x, this.S.get(3).y);
        int i3 = this.I;
        if (i3 == 1 || i3 == 2) {
            float f14 = this.S.get(2).x;
            PointF pointF11 = this.Q;
            f5 = f14 - pointF11.x;
            f6 = pointF11.y;
            f7 = this.S.get(2).y;
        } else {
            float f15 = this.S.get(3).x;
            PointF pointF12 = this.Q;
            f5 = f15 - pointF12.x;
            f6 = pointF12.y;
            f7 = this.S.get(3).y;
        }
        double dAtan = Math.atan((f6 - f7) / f5);
        int i5 = this.I;
        float fE = 360.0f - ((float) d.e(d.d(dAtan, i5 + (-1) == 0 ? 4 : i5 - 1)));
        if (Build.VERSION.SDK_INT >= 21) {
            Path path6 = this.M;
            PointF pointF13 = this.Q;
            float f16 = pointF13.x;
            float f17 = pointF13.y;
            path6.addArc(f16 - f, f17 - f, f16 + f, f17 + f, fE, 180.0f);
        } else {
            Path path7 = this.M;
            PointF pointF14 = this.Q;
            float f18 = pointF14.x;
            float f19 = pointF14.y;
            path7.addArc(new RectF(f18 - f, f19 - f, f18 + f, f19 + f), fE, 180.0f);
        }
        canvas.drawPath(this.M, this.b0);
    }

    public final void j(View view) {
        if (view.getParent() != null && (view.getParent() instanceof View)) {
            j((View) view.getParent());
        } else if (view instanceof ViewGroup) {
            this.e0 = (ViewGroup) view;
        }
    }

    public final void k() {
        float fHeight = this.K.height() > this.K.width() ? this.K.height() : this.K.width();
        switch (this.D) {
            case 17:
                PointF pointF = this.O;
                pointF.x = this.U / 2.0f;
                pointF.y = this.V / 2.0f;
                break;
            case 49:
                PointF pointF2 = this.O;
                pointF2.x = this.U / 2.0f;
                pointF2.y = this.F + this.w + (this.K.height() / 2.0f);
                break;
            case 81:
                PointF pointF3 = this.O;
                pointF3.x = this.U / 2.0f;
                pointF3.y = this.V - ((this.F + this.w) + (this.K.height() / 2.0f));
                break;
            case 8388627:
                PointF pointF4 = this.O;
                pointF4.x = this.E + this.w + (fHeight / 2.0f);
                pointF4.y = this.V / 2.0f;
                break;
            case 8388629:
                PointF pointF5 = this.O;
                pointF5.x = this.U - ((this.E + this.w) + (fHeight / 2.0f));
                pointF5.y = this.V / 2.0f;
                break;
            case 8388659:
                PointF pointF6 = this.O;
                float f = this.E;
                float f2 = this.w;
                pointF6.x = f + f2 + (fHeight / 2.0f);
                pointF6.y = this.F + f2 + (this.K.height() / 2.0f);
                break;
            case 8388661:
                PointF pointF7 = this.O;
                float f5 = this.U;
                float f6 = this.E;
                float f7 = this.w;
                pointF7.x = f5 - ((f6 + f7) + (fHeight / 2.0f));
                pointF7.y = this.F + f7 + (this.K.height() / 2.0f);
                break;
            case 8388691:
                PointF pointF8 = this.O;
                float f8 = this.E;
                float f9 = this.w;
                pointF8.x = f8 + f9 + (fHeight / 2.0f);
                pointF8.y = this.V - ((this.F + f9) + (this.K.height() / 2.0f));
                break;
            case 8388693:
                PointF pointF9 = this.O;
                float f10 = this.U;
                float f11 = this.E;
                float f12 = this.w;
                pointF9.x = f10 - ((f11 + f12) + (fHeight / 2.0f));
                pointF9.y = this.V - ((this.F + f12) + (this.K.height() / 2.0f));
                break;
        }
        o();
    }

    public final void l(View view) {
        ViewGroup viewGroup = (ViewGroup) view.getRootView();
        this.e0 = viewGroup;
        if (viewGroup == null) {
            j(view);
        }
    }

    public final void m() {
        setLayerType(1, null);
        this.K = new RectF();
        this.L = new RectF();
        this.M = new Path();
        this.O = new PointF();
        this.P = new PointF();
        this.Q = new PointF();
        this.R = new PointF();
        this.S = new ArrayList();
        TextPaint textPaint = new TextPaint();
        this.W = textPaint;
        textPaint.setAntiAlias(true);
        this.W.setSubpixelText(true);
        this.W.setFakeBoldText(true);
        this.W.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.SRC_IN));
        Paint paint = new Paint();
        this.a0 = paint;
        paint.setAntiAlias(true);
        this.a0.setStyle(Paint.Style.FILL);
        Paint paint2 = new Paint();
        this.b0 = paint2;
        paint2.setAntiAlias(true);
        this.b0.setStyle(Paint.Style.STROKE);
        this.o = -1552832;
        this.q = -1;
        this.v = c.a(getContext(), 11.0f);
        this.w = c.a(getContext(), 5.0f);
        this.x = 0;
        this.D = 8388661;
        this.E = c.a(getContext(), 1.0f);
        this.F = c.a(getContext(), 1.0f);
        this.H = c.a(getContext(), 90.0f);
        this.C = true;
        this.t = false;
        if (Build.VERSION.SDK_INT >= 21) {
            setTranslationZ(1000.0f);
        }
    }

    public final void n() {
        v(this.C);
        this.a0.setColor(this.o);
        this.b0.setColor(this.p);
        this.b0.setStrokeWidth(this.u);
        this.W.setColor(this.q);
        this.W.setTextAlign(Paint.Align.CENTER);
    }

    public final void o() {
        int[] iArr = new int[2];
        getLocationOnScreen(iArr);
        PointF pointF = this.Q;
        PointF pointF2 = this.O;
        pointF.x = pointF2.x + iArr[0];
        pointF.y = pointF2.y + iArr[1];
    }

    @Override // android.view.View
    public void onAttachedToWindow() {
        super.onAttachedToWindow();
        if (this.e0 == null) {
            l(this.T);
        }
    }

    @Override // android.view.View
    public void onDraw(Canvas canvas) {
        b bVar = this.c0;
        if (bVar != null && bVar.isRunning()) {
            this.c0.b(canvas);
            return;
        }
        if (this.y != null) {
            n();
            float badgeCircleRadius = getBadgeCircleRadius();
            float fB = this.G * (1.0f - (d.b(this.Q, this.P) / this.H));
            if (!this.z || !this.A) {
                k();
                g(canvas, this.O, badgeCircleRadius);
                return;
            }
            this.I = d.c(this.P, this.Q);
            v(this.C);
            boolean z = fB < ((float) c.a(getContext(), 1.5f));
            this.J = z;
            if (z) {
                w(3);
                g(canvas, this.P, badgeCircleRadius);
            } else {
                w(2);
                i(canvas, fB, badgeCircleRadius);
                g(canvas, this.P, badgeCircleRadius);
            }
        }
    }

    @Override // android.view.View
    public void onSizeChanged(int i, int i3, int i5, int i6) {
        super.onSizeChanged(i, i3, i5, i6);
        this.U = i;
        this.V = i3;
    }

    /* JADX WARN: Code duplicated, block: B:17:0x0031  */
    /* JADX WARN: Code duplicated, block: B:19:0x003b  */
    /* JADX WARN: Code duplicated, block: B:22:0x0045  */
    @Override // android.view.View
    public boolean onTouchEvent(MotionEvent motionEvent) {
        float x;
        RectF rectF;
        int actionMasked = motionEvent.getActionMasked();
        if (actionMasked == 0) {
            x = motionEvent.getX();
            float y = motionEvent.getY();
            if (this.z && motionEvent.getPointerId(motionEvent.getActionIndex()) == 0) {
                rectF = this.L;
                if (x > rectF.left && x < rectF.right && y > rectF.top && y < rectF.bottom && this.y != null) {
                    o();
                    this.A = true;
                    w(1);
                    this.G = c.a(getContext(), 7.0f);
                    getParent().requestDisallowInterceptTouchEvent(true);
                    s(true);
                    this.P.x = motionEvent.getRawX();
                    this.P.y = motionEvent.getRawY();
                }
            }
        } else if (actionMasked == 1) {
            if (motionEvent.getPointerId(motionEvent.getActionIndex()) == 0 && this.A) {
                this.A = false;
                q();
            }
        } else if (actionMasked != 2) {
            if (actionMasked == 3) {
                if (motionEvent.getPointerId(motionEvent.getActionIndex()) == 0) {
                    this.A = false;
                    q();
                }
            } else if (actionMasked == 5) {
                x = motionEvent.getX();
                float y4 = motionEvent.getY();
                if (this.z) {
                    rectF = this.L;
                    if (x > rectF.left) {
                        o();
                        this.A = true;
                        w(1);
                        this.G = c.a(getContext(), 7.0f);
                        getParent().requestDisallowInterceptTouchEvent(true);
                        s(true);
                        this.P.x = motionEvent.getRawX();
                        this.P.y = motionEvent.getRawY();
                    }
                }
            } else if (actionMasked == 6) {
                if (motionEvent.getPointerId(motionEvent.getActionIndex()) == 0) {
                    this.A = false;
                    q();
                }
            }
        } else if (this.A) {
            this.P.x = motionEvent.getRawX();
            this.P.y = motionEvent.getRawY();
            invalidate();
        }
        return this.A || super.onTouchEvent(motionEvent);
    }

    public final void p() {
        RectF rectF = this.K;
        rectF.left = 0.0f;
        rectF.top = 0.0f;
        if (TextUtils.isEmpty(this.y)) {
            RectF rectF2 = this.K;
            rectF2.right = 0.0f;
            rectF2.bottom = 0.0f;
        } else {
            this.W.setTextSize(this.v);
            this.K.right = this.W.measureText(this.y);
            Paint.FontMetrics fontMetrics = this.W.getFontMetrics();
            this.N = fontMetrics;
            this.K.bottom = fontMetrics.descent - fontMetrics.ascent;
        }
        f();
    }

    public final void q() {
        if (this.J) {
            d(this.P);
            w(5);
        } else {
            r();
            w(4);
        }
    }

    public void r() {
        PointF pointF = this.P;
        pointF.x = -1000.0f;
        pointF.y = -1000.0f;
        this.I = 4;
        s(false);
        getParent().requestDisallowInterceptTouchEvent(false);
        invalidate();
    }

    public void s(boolean z) {
        if (getParent() != null) {
            ((ViewGroup) getParent()).removeView(this);
        }
        if (z) {
            this.e0.addView(this, new FrameLayout.LayoutParams(-1, -1));
        } else {
            a(this.T);
        }
    }

    public mm.a t(int i) {
        if (i != 8388659 && i != 8388661 && i != 8388691 && i != 8388693 && i != 17 && i != 49 && i != 81 && i != 8388627 && i != 8388629) {
            throw new IllegalStateException("only support Gravity.START | Gravity.TOP , Gravity.END | Gravity.TOP , Gravity.START | Gravity.BOTTOM , Gravity.END | Gravity.BOTTOM , Gravity.CENTER , Gravity.CENTER | Gravity.TOP , Gravity.CENTER | Gravity.BOTTOM ,Gravity.CENTER | Gravity.START , Gravity.CENTER | Gravity.END");
        }
        this.D = i;
        invalidate();
        return this;
    }

    public mm.a u(int i) {
        this.x = i;
        if (i < 0) {
            this.y = BuildConfig.FLAVOR;
        } else if (i > 99) {
            this.y = this.B ? String.valueOf(i) : "99+";
        } else if (i > 0 && i <= 99) {
            this.y = String.valueOf(i);
        } else if (i == 0) {
            this.y = null;
        }
        p();
        invalidate();
        return this;
    }

    public final void v(boolean z) {
        int iA = c.a(getContext(), 1.0f);
        int iA2 = c.a(getContext(), 1.5f);
        int i = this.I;
        if (i == 1) {
            iA = c.a(getContext(), 1.0f);
            iA2 = c.a(getContext(), -1.5f);
        } else if (i == 2) {
            iA = c.a(getContext(), -1.0f);
            iA2 = c.a(getContext(), -1.5f);
        } else if (i == 3) {
            iA = c.a(getContext(), -1.0f);
            iA2 = c.a(getContext(), 1.5f);
        } else if (i == 4) {
            iA = c.a(getContext(), 1.0f);
            iA2 = c.a(getContext(), 1.5f);
        }
        this.a0.setShadowLayer(z ? c.a(getContext(), 2.0f) : 0.0f, iA, iA2, 855638016);
    }

    public final void w(int i) {
        mm.a.InterfaceC0065a interfaceC0065a = this.d0;
        if (interfaceC0065a != null) {
            interfaceC0065a.a(i, this, this.T);
        }
    }

    public e(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, 0);
    }

    public e(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        m();
    }
}
