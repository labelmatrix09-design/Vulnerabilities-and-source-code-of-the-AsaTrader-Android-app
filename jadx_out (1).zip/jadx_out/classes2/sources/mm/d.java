package mm;

import android.graphics.PointF;
import java.util.List;

/* JADX INFO: compiled from: MathUtil.java */
/* JADX INFO: loaded from: /home/kali/Desktop/bunt/agah/dex_files/classes2.dex */
public class d {
    public static void a(PointF pointF, float f, Double d, List<PointF> list) {
        float f2;
        if (d != null) {
            double dAtan = (float) Math.atan(d.doubleValue());
            double dCos = Math.cos(dAtan);
            double d2 = f;
            Double.isNaN(d2);
            double dSin = Math.sin(dAtan);
            Double.isNaN(d2);
            f2 = (float) (dSin * d2);
            f = (float) (dCos * d2);
        } else {
            f2 = 0.0f;
        }
        list.add(new PointF(pointF.x + f, pointF.y + f2));
        list.add(new PointF(pointF.x - f, pointF.y - f2));
    }

    public static float b(PointF pointF, PointF pointF2) {
        return (float) Math.sqrt(Math.pow(pointF.x - pointF2.x, 2.0d) + Math.pow(pointF.y - pointF2.y, 2.0d));
    }

    public static int c(PointF pointF, PointF pointF2) {
        float f = pointF.x;
        float f2 = pointF2.x;
        if (f > f2) {
            float f5 = pointF.y;
            float f6 = pointF2.y;
            if (f5 > f6) {
                return 4;
            }
            return f5 < f6 ? 1 : -1;
        }
        if (f >= f2) {
            return -1;
        }
        float f7 = pointF.y;
        float f8 = pointF2.y;
        if (f7 > f8) {
            return 3;
        }
        return f7 < f8 ? 2 : -1;
    }

    public static double d(double d, int i) {
        if (d < 0.0d) {
            d += 1.5707963267948966d;
        }
        double d2 = i - 1;
        Double.isNaN(d2);
        return d + (d2 * 1.5707963267948966d);
    }

    public static double e(double d) {
        return (d / 6.283185307179586d) * 360.0d;
    }
}
