package mm;

import android.view.View;

/* JADX INFO: compiled from: Badge.java */
/* JADX INFO: loaded from: /home/kali/Desktop/bunt/agah/dex_files/classes2.dex */
public interface a {

    /* JADX INFO: renamed from: mm.a$a, reason: collision with other inner class name */
    /* JADX INFO: compiled from: Badge.java */
    public interface InterfaceC0065a {
        void a(int i, a aVar, View view);
    }

    a a(View view);

    a b(String str);

    a c(float f, float f2, boolean z);
}
