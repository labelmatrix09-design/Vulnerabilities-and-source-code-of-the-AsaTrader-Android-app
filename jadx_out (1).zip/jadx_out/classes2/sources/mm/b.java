package mm;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.animation.ValueAnimator;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.PointF;
import java.lang.ref.WeakReference;
import java.lang.reflect.Array;
import java.util.Random;

/* JADX INFO: compiled from: BadgeAnimator.java */
/* JADX INFO: loaded from: /home/kali/Desktop/bunt/agah/dex_files/classes2.dex */
public class b extends ValueAnimator {
    public c[][] o;
    public WeakReference<e> p;

    /* JADX INFO: compiled from: BadgeAnimator.java */
    public class a implements ValueAnimator.AnimatorUpdateListener {
        public a() {
        }

        @Override // android.animation.ValueAnimator.AnimatorUpdateListener
        public void onAnimationUpdate(ValueAnimator valueAnimator) {
            e eVar = (e) b.this.p.get();
            if (eVar == null || !eVar.isShown()) {
                b.this.cancel();
            } else {
                eVar.invalidate();
            }
        }
    }

    /* JADX INFO: renamed from: mm.b$b, reason: collision with other inner class name */
    /* JADX INFO: compiled from: BadgeAnimator.java */
    public class C0066b extends AnimatorListenerAdapter {
        public C0066b() {
        }

        @Override // android.animation.AnimatorListenerAdapter, android.animation.Animator.AnimatorListener
        public void onAnimationEnd(Animator animator) {
            e eVar = (e) b.this.p.get();
            if (eVar != null) {
                eVar.r();
            }
        }
    }

    /* JADX INFO: compiled from: BadgeAnimator.java */
    public class c {
        public Random a;
        public float b;
        public float c;
        public float d;
        public int e;
        public int f;
        public Paint g;

        public c() {
            Paint paint = new Paint();
            this.g = paint;
            paint.setAntiAlias(true);
            this.g.setStyle(Paint.Style.FILL);
            this.a = new Random();
        }

        public void a(float f, Canvas canvas) {
            this.g.setColor(this.e);
            this.b += this.a.nextInt(this.f) * 0.1f * (this.a.nextFloat() - 0.5f);
            float fNextInt = this.c + (this.a.nextInt(this.f) * 0.1f * (this.a.nextFloat() - 0.5f));
            this.c = fNextInt;
            float f2 = this.b;
            float f5 = this.d;
            canvas.drawCircle(f2, fNextInt, f5 - (f * f5), this.g);
        }
    }

    public b(Bitmap bitmap, PointF pointF, e eVar) {
        this.p = new WeakReference<>(eVar);
        setFloatValues(0.0f, 1.0f);
        setDuration(500L);
        this.o = c(bitmap, pointF);
        addUpdateListener(new a());
        addListener(new C0066b());
    }

    public void b(Canvas canvas) {
        for (int i = 0; i < this.o.length; i++) {
            int i3 = 0;
            while (true) {
                c[][] cVarArr = this.o;
                if (i3 < cVarArr[i].length) {
                    cVarArr[i][i3].a(Float.parseFloat(getAnimatedValue().toString()), canvas);
                    i3++;
                }
            }
        }
    }

    public final c[][] c(Bitmap bitmap, PointF pointF) {
        int width = bitmap.getWidth();
        int height = bitmap.getHeight();
        float fMin = Math.min(width, height) / 6.0f;
        float width2 = pointF.x - (bitmap.getWidth() / 2.0f);
        float height2 = pointF.y - (bitmap.getHeight() / 2.0f);
        c[][] cVarArr = (c[][]) Array.newInstance((Class<?>) c.class, (int) (height / fMin), (int) (width / fMin));
        for (int i = 0; i < cVarArr.length; i++) {
            for (int i3 = 0; i3 < cVarArr[i].length; i3++) {
                c cVar = new c();
                float f = i3 * fMin;
                float f2 = i * fMin;
                cVar.e = bitmap.getPixel((int) f, (int) f2);
                cVar.b = f + width2;
                cVar.c = f2 + height2;
                cVar.d = fMin;
                cVar.f = Math.max(width, height);
                cVarArr[i][i3] = cVar;
            }
        }
        bitmap.recycle();
        return cVarArr;
    }
}
